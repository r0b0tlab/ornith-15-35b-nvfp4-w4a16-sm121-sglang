package robot

// See defs.go for other definitions

// Step 1
// Define N, E, S, W here.

type Dir int

const (
	N Dir = iota
	E
	S
	W
)

func (d Dir) String() string {
	switch d {
	case N:
		return "N"
	case E:
		return "E"
	case S:
		return "S"
	case W:
		return "W"
	}
	return "Unknown"
}

// Step 1: Global robot state
var step1Robot = Step2Robot{X: 0, Y: 0, Dir: N}

func Right() {
	step1Robot.Dir = (step1Robot.Dir + 1) % 4
}

func Left() {
	step1Robot.Dir = (step1Robot.Dir + 3) % 4
}

func Advance() {
	switch step1Robot.Dir {
	case N:
		step1Robot.Y++
	case E:
		step1Robot.X++
	case S:
		step1Robot.Y--
	case W:
		step1Robot.X--
	}
}

// Step 2
// Define Action type here.

type Action byte

const (
	RightC Action = iota
	LeftC
	AdvanceC
)

func StartRobot(command chan Command, action chan Action) {
	go func() {
		for cmd := range command {
			action <- actionFromCommand(cmd)
		}
	}()
}

func actionFromCommand(cmd Command) Action {
	switch cmd {
	case RightCommand:
		return RightC
	case LeftCommand:
		return LeftC
	case AdvanceCommand:
		return AdvanceC
	}
	return 0 // Unknown command, no action
}

func Room(extent Rect, robot Step2Robot, action chan Action, report chan Step2Robot) {
	// Process actions until the action channel is closed
	for act := range action {
		robot = applyAction(extent, robot, act)
	}
	// Send final robot state to report channel
	report <- robot
}

func applyAction(extent Rect, robot Step2Robot, act Action) Step2Robot {
	switch act {
	case RightC:
		robot.Dir = (robot.Dir + 1) % 4
	case LeftC:
		robot.Dir = (robot.Dir + 3) % 4
	case AdvanceC:
		robot = advanceRobot(extent, robot)
	}
	return robot
}

func advanceRobot(extent Rect, robot Step2Robot) Step2Robot {
	switch robot.Dir {
	case N:
		if robot.Y < extent.MaxY {
			robot.Y++
		}
	case E:
		if robot.X < extent.MaxX {
			robot.X++
		}
	case S:
		if robot.Y > extent.MinY {
			robot.Y--
		}
	case W:
		if robot.X > extent.MinX {
			robot.X--
		}
	}
	return robot
}

// Step 3
// Define Action3 type here.

type Action3 struct {
	Step2Robot
	Command byte
}

func StartRobot3(name, script string, action chan Action3, log chan string) {
	go func() {
		for _, char := range script {
			action <- Action3{
				Step2Robot: Step2Robot{Dir: N},
				Command:    char,
			}
		}
		close(action)
	}()
}

func Room3(extent Rect, robots []Step3Robot, action chan Action3, rep chan []Step3Robot, log chan string) {
	// Track robot names for duplicate detection and lookup
	robotByName := make(map[string]int)

	for i := range robots {
		if robots[i].Name == "" {
			log <- "robot without a name"
			continue
		}
		if _, exists := robotByName[robots[i].Name]; exists {
			log <- "duplicate robot name"
			continue
		}
		robotByName[robots[i].Name] = i
	}

	// Check for robots at the same position and outside the room
	for i := 0; i < len(robots); i++ {
		if robots[i].Name == "" {
			continue // Already logged
		}
		for j := i + 1; j < len(robots); j++ {
			if robots[j].Name == "" {
				continue // Already logged
			}
			if robots[i].X == robots[j].X && robots[i].Y == robots[j].Y {
				log <- "robots placed at the same place"
			}
		}
		if robots[i].X < extent.MinX || robots[i].X > extent.MaxX ||
			robots[i].Y < extent.MinY || robots[i].Y > extent.MaxY {
			log <- "robot placed outside of the room"
		}
	}

	// Process actions until the action channel is closed
	for act := range action {
		// Find the robot that should perform this action
		robotIndex, exists := robotByName[act.Step2Robot.Name]
		if !exists {
			log <- "unknown robot"
			continue
		}

		switch act.Command {
		case 'R':
			robots[robotIndex].Dir = (robots[robotIndex].Dir + 1) % 4
		case 'L':
			robots[robotIndex].Dir = (robots[robotIndex].Dir + 3) % 4
		case 'A':
			// Calculate next position
			nextX, nextY := nextPosition(robots[robotIndex], robots[robotIndex].Dir)

			// Check for wall collision
			if nextX < extent.MinX || nextX > extent.MaxX || nextY < extent.MinY || nextY > extent.MaxY {
				log <- "attempted to advance into a wall"
				break
			}

			// Check for collision with another robot
			collision := false
			for i := range robots {
				if i != robotIndex && robots[i].X == nextX && robots[i].Y == nextY {
					collision = true
					break
				}
			}

			if collision {
				log <- "attempted to advance into another robot"
				break
			}

			// Move the robot
			robots[robotIndex].X = nextX
			robots[robotIndex].Y = nextY
		}
	}

	// Send final robots state to report channel
	rep <- robots
}

func nextPosition(robot Step3Robot, dir Dir) (int, int) {
	switch dir {
	case N:
		return robot.X, robot.Y+1
	case E:
		return robot.X+1, robot.Y
	case S:
		return robot.X, robot.Y-1
	case W:
		return robot.X-1, robot.Y
	}
	return robot.X, robot.Y
}

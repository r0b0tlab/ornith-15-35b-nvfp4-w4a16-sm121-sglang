package dominoes

// Domino represents a domino with two halves.
type Domino [2]int

func MakeChain(input []Domino) ([]Domino, bool) {
	// An empty input is legal.
	if len(input) == 0 {
		return []Domino{}, true
	}

	used := make([]bool, len(input))
	var chain []Domino

	var backtrack func() bool

	backtrack = func() bool {
		// If all dominoes are used, check if the chain closes properly.
		if len(chain) == len(input) {
			return chain[0][0] == chain[len(chain)-1][1]
		}

		for i := 0; i < len(input); i++ {
			if used[i] {
				continue
			}

			// Try the domino in its original orientation.
			if len(chain) == 0 || chain[len(chain)-1][1] == input[i][0] {
				used[i] = true
				chain = append(chain, input[i])

				if backtrack() {
					return true
				}

				chain = chain[:len(chain)-1]
				used[i] = false
			}

			// Try the domino in rotated orientation (only if sides differ).
			if input[i][0] != input[i][1] {
				if len(chain) == 0 || chain[len(chain)-1][1] == input[i][1] {
					used[i] = true
					chain = append(chain, Domino{input[i][1], input[i][0]})

					if backtrack() {
						return true
					}

					chain = chain[:len(chain)-1]
					used[i] = false
				}
			}
		}

		return false
	}

	if backtrack() {
		return chain, true
	}

	return nil, false
}

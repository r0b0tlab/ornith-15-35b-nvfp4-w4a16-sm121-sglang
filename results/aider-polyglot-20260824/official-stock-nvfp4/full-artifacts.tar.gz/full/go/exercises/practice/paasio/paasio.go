package paasio

import "io"

// Define readCounter and writeCounter types here.

// For the return of the function NewReadWriteCounter, you must also define a type that satisfies the ReadWriteCounter interface.

type readCounter struct {
	reader    io.Reader
	readCount int64
	opCount   int
}

type writeCounter struct {
	writer    io.Writer
	writeCount int64
	opCount   int
}

type readWriteCounter struct {
	readwriter io.ReadWriter
	readCount  int64
	writeCount int64
	opCount    int
}

func NewWriteCounter(writer io.Writer) WriteCounter {
	return &writeCounter{
		writer: writer,
	}
}

func NewReadCounter(reader io.Reader) ReadCounter {
	return &readCounter{
		reader: reader,
	}
}

func NewReadWriteCounter(readwriter io.ReadWriter) ReadWriteCounter {
	return &readWriteCounter{
		readwriter: readwriter,
	}
}

func (rc *readCounter) Read(p []byte) (int, error) {
	n, err := rc.reader.Read(p)
	rc.readCount += int64(n)
	rc.opCount++
	return n, err
}

func (rc *readCounter) ReadCount() (int64, int) {
	return rc.readCount, rc.opCount
}

func (wc *writeCounter) Write(p []byte) (int, error) {
	n, err := wc.writer.Write(p)
	wc.writeCount += int64(n)
	wc.opCount++
	return n, err
}

func (wc *writeCounter) WriteCount() (int64, int) {
	return wc.writeCount, wc.opCount
}

func (rwc *readWriteCounter) Read(p []byte) (int, error) {
	n, err := rwc.readwriter.Read(p)
	rwc.readCount += int64(n)
	rwc.opCount++
	return n, err
}

func (rwc *readWriteCounter) ReadCount() (int64, int) {
	return rwc.readCount, rwc.opCount
}

func (rwc *readWriteCounter) Write(p []byte) (int, error) {
	n, err := rwc.readwriter.Write(p)
	rwc.writeCount += int64(n)
	rwc.opCount++
	return n, err
}

func (rwc *readWriteCounter) WriteCount() (int64, int) {
	return rwc.writeCount, rwc.opCount
}

package erratum

func Use(opener ResourceOpener, input string) (err error) {
	defer func() {
		if r := recover(); r != nil {
			if fb, ok := r.(FrobError); ok {
				Defrob(fb.defrobTag)
			}
			err = r.(error)
		}
	}()

	var res Resource
	for {
		res, err = opener()
		if err == nil {
			break
		}
		var te TransientError
		if ok := errors.As(err, &te); ok {
			continue
		}
		return err
	}
	defer res.Close()

	Frob(input)
	return nil
}

package foodchain

import (
	"fmt"
	"strings"
)

var animals = []string{
	"fly",
	"spider",
	"bird",
	"cat",
	"dog",
	"goat",
	"cow",
	"horse",
}

var reactions = map[string]string{
	"fly":    "",
	"spider": "It wriggled and jiggled and tickled inside her.",
	"bird":   "How absurd to swallow a bird!",
	"cat":    "Imagine that, to swallow a cat!",
	"dog":    "What a hog, to swallow a dog!",
	"goat":   "Just opened her throat and swallowed a goat!",
	"cow":    "I don't know how she swallowed a cow!",
	"horse":  "She's dead, of course!",
}

func Verse(v int) string {
	if v < 1 || v > len(animals) {
		return ""
	}

	animal := animals[v-1]
	var sb strings.Builder

	sb.WriteString(fmt.Sprintf("I know an old lady who swallowed a %s.\n", animal))

	// Special case for horse
	if animal == "horse" {
		sb.WriteString(reactions[animal])
		sb.WriteString("\n")
		return sb.String()
	}

	// Add reaction for the current animal (except fly)
	if reaction := reactions[animal]; reaction != "" {
		sb.WriteString(reaction)
		sb.WriteString("\n")
	}

	// Cumulative swallowing lines
	for i := v - 1; i > 0; i-- {
		sb.WriteString(fmt.Sprintf("She swallowed the %s to catch the %s.", animals[i], animals[i-1]))
		// Add special description for spider being caught
		if animals[i-1] == "spider" {
			sb.WriteString(" that wriggled and jiggled and tickled inside her")
		}
		sb.WriteString(".\n")
	}

	// Final line
	sb.WriteString("I don't know why she swallowed the fly. Perhaps she'll die.")
	sb.WriteString("\n")

	return sb.String()
}

func Verses(start, end int) string {
	var sb strings.Builder

	for v := start; v <= end; v++ {
		sb.WriteString(Verse(v))
		if v < end {
			sb.WriteString("\n")
		}
	}

	return sb.String()
}

func Song() string {
	return Verses(1, len(animals))
}

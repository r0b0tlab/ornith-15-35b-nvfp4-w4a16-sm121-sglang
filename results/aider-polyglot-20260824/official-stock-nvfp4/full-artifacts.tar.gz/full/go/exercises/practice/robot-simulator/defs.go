package robot

import "time"

// Type definitions

// Step 1

type Dir int

func (d Dir) String() string {
	panic("Please implement the String function")
}

// Step 2

type Step2Robot struct {
	X, y int
	Dir  Dir
}

// Step 3

type Step3Robot struct {
	Name string
	Step2Robot
}

// ... rest of file

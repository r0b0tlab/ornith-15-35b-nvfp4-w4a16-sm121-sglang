package pov

type Tree struct {
	ID       string
	Children []*Tree
}

// New creates and returns a new Tree with the given root value and children.
func New(value string, children ...*Tree) *Tree {
	return &Tree{
		ID:       value,
		Children: children,
	}
}

// Value returns the value at the root of a tree.
func (tr *Tree) Value() string {
	return tr.ID
}

// Children returns a slice containing the children of a tree.
// There is no need to sort the elements in the result slice,
// they can be in any order.
func (tr *Tree) Children() []*Tree {
	return tr.Children
}

// String describes a tree in a compact S-expression format.
// This helps to make test outputs more readable.
// Feel free to adapt this method as you see fit.
func (tr *Tree) String() string {
	if tr == nil {
		return "nil"
	}
	result := tr.Value()
	if len(tr.Children()) == 0 {
		return result
	}
	for _, ch := range tr.Children() {
		result += " " + ch.String()
	}
	return "(" + result + ")"
}

// POV problem-specific functions

// FromPov returns the pov from the node specified in the argument.
func (tr *Tree) FromPov(from string) *Tree {
	// Find the path from root to the target node
	path := findPath(tr, from)
	if path == nil {
		return nil
	}

	// Reverse the path so it goes from target node to root
	for i, j := 0, len(path)-1; i < j; i, j = i+1, j-1 {
		path[i], path[j] = path[j], path[i]
	}

	// The root of the new tree is the target node
	newRoot := path[0]

	// Build the new tree structure
	// For each node in the path, its children should be its original children
	// minus the next node in the path (which becomes its parent)
	for i := 0; i < len(path); i++ {
		node := path[i]
		newChildren := make([]*Tree, 0)
		for _, child := range node.Children {
			if i+1 < len(path) && child == path[i+1] {
				// This child becomes the parent, don't include it
				continue
			}
			newChildren = append(newChildren, child)
		}
		node.Children = newChildren
	}

	return newRoot
}

// findPath finds the path from root to the target node using DFS
func findPath(tr *Tree, target string) []*Tree {
	if tr == nil {
		return nil
	}
	if tr.ID == target {
		return []*Tree{tr}
	}

	for _, child := range tr.Children {
		path := findPath(child, target)
		if path != nil {
			return append([]*Tree{tr}, path...)
		}
	}

	return nil
}

// PathTo returns the shortest path between two nodes in the tree.
func (tr *Tree) PathTo(from, to string) []string {
	// Get the reoriented tree from the 'from' node's perspective
	reoriented := tr.FromPov(from)
	if reoriented == nil {
		return nil
	}

	// Find the path from the root (which is 'from') to 'to'
	path := findStringValue(reoriented, to)
	return path
}

// findStringValue finds the path of values from root to the node with the given value
func findStringValue(tr *Tree, target string) []string {
	if tr == nil {
		return nil
	}
	if tr.ID == target {
		return []string{tr.ID}
	}

	for _, child := range tr.Children {
		path := findStringValue(child, target)
		if path != nil {
			return append([]string{tr.ID}, path...)
		}
	}

	return nil
}

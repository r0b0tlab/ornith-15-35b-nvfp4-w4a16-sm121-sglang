package bookstore

const basePrice = 800

var discounts = map[int]int{
	1: 0,
	2: 5,
	3: 10,
	4: 20,
	5: 25,
}

func Cost(books []int) int {
	counts := make([]int, 6)
	for _, b := range books {
		counts[b]++
	}

	var groups []int
	for {
		var size int
		for i := 1; i <= 5; i++ {
			if counts[i] > 0 {
				counts[i]--
				size++
			}
		}
		if size == 0 {
			break
		}
		groups = append(groups, size)
	}

	total := groupCost(groups)

	// Known optimal correction: two groups of 5 cost more than two groups of 4.
	for len(groups) >= 2 {
		hasFive := false
		for _, g := range groups {
			if g == 5 {
				hasFive = true
				break
			}
		}
		if !hasFive {
			break
		}
		total -= 2 * groupCost([]int{5})
		total += 2 * groupCost([]int{4})
		groups = removeTwoFive(groups)
	}

	return total
}

func groupCost(groups []int) int {
	var total int
	for _, g := range groups {
		total += g * basePrice * (100-discounts[g]) / 100
	}
	return total
}

func removeTwoFive(groups []int) []int {
	removed := 0
	result := make([]int, 0, len(groups))
	for _, g := range groups {
		if g == 5 && removed < 2 {
			removed++
			continue
		}
		result = append(result, g)
	}
	return result
}

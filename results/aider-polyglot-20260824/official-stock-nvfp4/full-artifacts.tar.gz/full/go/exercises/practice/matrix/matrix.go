package matrix

import (
	"strconv"
	"strings"
	"errors"
)

// Define the Matrix type here.
type Matrix [][]int

func New(s string) (Matrix, error) {
	rows := strings.Split(s, "\n")
	matrix := make(Matrix, len(rows))
	numCols := -1

	for i, row := range rows {
		elements := strings.Fields(row)
		if numCols == -1 {
			numCols = len(elements)
		} else if len(elements) != numCols {
			return nil, errors.New("rows have different lengths")
		}

		newRow := make([]int, numCols)
		for j, elem := range elements {
			num, err := strconv.Atoi(elem)
			if err != nil {
				return nil, err
			}
			newRow[j] = num
		}
		matrix[i] = newRow
	}

	return matrix, nil
}

// Cols and Rows must return the results without affecting the matrix.
func (m Matrix) Cols() [][]int {
	result := make([][]int, len(m[0]))
	for i := range result {
		result[i] = make([]int, len(m))
		for j := range m {
			result[i][j] = m[j][i]
		}
	}
	return result
}

func (m Matrix) Rows() [][]int {
	result := make([][]int, len(m))
	for i := range m {
		result[i] = make([]int, len(m[i]))
		for j := range m[i] {
			result[i][j] = m[i][j]
		}
	}
	return result
}

func (m Matrix) Set(row, col, val int) bool {
	if row < 0 || row >= len(m) {
		return false
	}
	if col < 0 || col >= len(m[row]) {
		return false
	}
	m[row][col] = val
	return true
}

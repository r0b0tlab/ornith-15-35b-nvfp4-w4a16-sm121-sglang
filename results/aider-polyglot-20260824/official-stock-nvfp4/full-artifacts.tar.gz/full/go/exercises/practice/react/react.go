package react

// Define reactor, cell and canceler types here.
// These types will implement the Reactor, Cell and Canceler interfaces, respectively.

type canceler struct {
	cancelled bool
	cell      *cell
}

func (c *canceler) Cancel() {
	c.cancelled = true
	if c.cell != nil {
		delete(c.cell.callbacks, c)
	}
}

type callback struct {
	fn func(int)
}

type cell struct {
	value     int
	isInput   bool
	reactions []*reaction
	callbacks map[*canceler]func(int)
}

func (c *cell) Value() int {
	return c.value
}

func (c *cell) SetValue(value int) {
	if c.isInput {
		c.value = value
	}
}

func (c *cell) AddCallback(callback func(int)) Canceler {
	cancel := &canceler{
		cell: c,
	}
	if c.callbacks == nil {
		c.callbacks = map[*canceler]func(int){}
	}
	c.callbacks[cancel] = callback
	return cancel
}

type reaction struct {
	cell     *cell
	compute  func(int) int
	compute2 func(int, int) int
	hasDep2  bool
	dep2     *cell
}

type reactor struct {
	inputs   map[*cell]bool
	allCells map[*cell]bool
}

func New() Reactor {
	return &reactor{
		inputs:   map[*cell]bool{},
		allCells: map[*cell]bool{},
	}
}

func (r *reactor) CreateInput(initial int) InputCell {
	c := &cell{
		value:   initial,
		isInput: true,
	}
	r.inputs[c] = true
	r.allCells[c] = true
	return c
}

func (r *reactor) CreateCompute1(dep Cell, compute func(int) int) ComputeCell {
	c := &cell{
		value:     compute(dep.Value()),
		callbacks: map[*canceler]func(int){},
	}
	r.allCells[c] = true
	rxn := &reaction{
		cell:    c,
		compute: compute,
	}
	dep.(*cell).reactions = append(dep.(*cell).reactions, rxn)
	return c
}

func (r *reactor) CreateCompute2(dep1, dep2 Cell, compute func(int, int) int) ComputeCell {
	c := &cell{
		value:     compute(dep1.Value(), dep2.Value()),
		callbacks: map[*canceler]func(int){},
	}
	r.allCells[c] = true
	rxn := &reaction{
		cell:     c,
		compute2: compute,
		hasDep2:  true,
		dep2:     dep2.(*cell),
	}
	dep1.(*cell).reactions = append(dep1.(*cell).reactions, rxn)
	dep2.(*cell).reactions = append(dep2.(*cell).reactions, rxn)
	return c
}

func (r *reactor) SetValue(cell Cell, value int) {
	c := cell.(*cell)
	c.value = value
	r.propagate()
}

func (r *reactor) propagate() {
	changed := map[*cell]bool{}
	queue := []*cell{}

	for c := range r.inputs {
		queue = append(queue, c)
	}

	for len(queue) > 0 {
		c := queue[0]
		queue = queue[1:]

		var newValue int
		for _, rxn := range c.reactions {
			if rxn.hasDep2 {
				newValue = rxn.compute2(rxn.cell.value, rxn.dep2.value)
			} else {
				newValue = rxn.compute(rxn.cell.value)
			}
		}

		if c.value != newValue {
			c.value = newValue
			if !changed[c] {
				changed[c] = true
			}
			for _, next := range c.reactions {
				queue = append(queue, next.cell)
			}
		}
	}

	for c := range changed {
		for cancel, fn := range c.callbacks {
			if !cancel.cancelled {
				fn(c.value)
			}
		}
	}
}

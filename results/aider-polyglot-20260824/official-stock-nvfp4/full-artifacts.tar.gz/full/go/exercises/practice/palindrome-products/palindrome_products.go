package palindrome

import "errors"

// Product struct represents a palindrome product with its value and factors.
type Product struct {
	Product       int
	Factors       [][2]int
	Factorizations [][2]int
}

func Products(fmin, fmax int) (Product, Product, error) {
	if fmin > fmax {
		return Product{}, Product{}, errors.New("fmin must be less than or equal to fmax")
	}

	// Initialize smallest and largest palindrome products.
	var smallest Product = Product{Product: 0, Factors: [][2]int{}, Factorizations: [][2]int{}}
	var largest Product = Product{Product: 0, Factors: [][2]int{}, Factorizations: [][2]int{}}

	found := false

	// Iterate over all possible pairs (i, j) where fmin <= i <= j <= fmax.
	for i := fmin; i <= fmax; i++ {
		for j := i; j <= fmax; j++ {
			product := i * j
			if isPalindrome(product) {
				factorization := [2]int{i, j}
				if !found {
					// First palindrome found, initialize both smallest and largest.
					smallest = Product{Product: product, Factors: [][2]int{factorization}, Factorizations: [][2]int{factorization}}
					largest = Product{Product: product, Factors: [][2]int{factorization}, Factorizations: [][2]int{factorization}}
					found = true
				} else {
					// Update smallest if needed.
					if product < smallest.Product {
						smallest = Product{Product: product, Factors: [][2]int{factorization}, Factorizations: [][2]int{factorization}}
					} else if product == smallest.Product {
						smallest.Factors = append(smallest.Factors, factorization)
						smallest.Factorizations = append(smallest.Factorizations, factorization)
					}

					// Update largest if needed.
					if product > largest.Product {
						largest = Product{Product: product, Factors: [][2]int{factorization}, Factorizations: [][2]int{factorization}}
					} else if product == largest.Product {
						largest.Factors = append(largest.Factors, factorization)
						largest.Factorizations = append(largest.Factorizations, factorization)
					}
				}
			}
		}
	}

	if !found {
		return Product{}, Product{}, errors.New("no palindromes found")
	}

	return smallest, largest, nil
}

// isPalindrome checks if a number is a palindrome.
func isPalindrome(n int) bool {
	if n < 0 {
		return false
	}

	original := n
	reversed := 0

	for n > 0 {
		reversed = reversed*10 + n%10
		n /= 10
	}

	return original == reversed
}

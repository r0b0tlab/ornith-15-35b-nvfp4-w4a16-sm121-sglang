package counter

// Counter is the interface used by the tests.
// It is defined in this file to allow multiple
// implementations to be tested against.
type Counter interface {
	Add(str string)
	Lines() int
	letters() int
	Characters() int
}

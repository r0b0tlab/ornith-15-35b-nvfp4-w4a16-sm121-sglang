package cryptosquare

import (
	"math"
	"strings"
	"unicode"
)

func Encode(pt string) string {
	// Normalize the input: remove spaces and punctuation, down-case
	var normalized strings.Builder
	for _, r := range pt {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			normalized.WriteRune(unicode.ToLower(r))
		}
	}
	clean := normalized.String()

	// Handle empty message
	if len(clean) == 0 {
		return ""
	}

	// Determine rectangle dimensions
	length := len(clean)
	c := int(math.Ceil(math.Sqrt(float64(length))))
	r := int(math.Ceil(float64(length) / float64(c)))

	// Convert clean string to rune slice
	runes := []rune(clean)

	// Build the encoded output in chunks
	var chunks []string
	for col := 0; col < c; col++ {
		chunk := make([]rune, 0, r)
		for row := 0; row < r; row++ {
			index := row*c + col
			if index < length {
				chunk = append(chunk, runes[index])
			} else {
				// Pad with space for incomplete chunks
				chunk = append(chunk, ' ')
			}
		}
		chunks = append(chunks, string(chunk))
	}

	return strings.Join(chunks, " ")
}

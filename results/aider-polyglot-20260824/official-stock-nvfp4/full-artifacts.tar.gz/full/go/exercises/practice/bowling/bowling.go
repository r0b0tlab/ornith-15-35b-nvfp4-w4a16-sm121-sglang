package bowling

import "errors"

// Define the Game type here.
type Game struct {
	rolls    []int
	rollIdx  int
}

func NewGame() *Game {
	return &Game{
		rolls: make([]int, 0),
	}
}

func (g *Game) Roll(pins int) error {
	if pins < 0 || pins > 10 {
		return errors.New("pins must be between 0 and 10")
	}

	// Check if the game is already complete
	if g.isGameComplete() {
		return errors.New("cannot roll after game is complete")
	}

	// Determine the current frame and roll within the frame
	frame, rollInFrame := g.currentFrameInfo()

	// In the 10th frame, special rules apply
	if frame == 9 {
		// Check for invalid rolls in the 10th frame
		if err := g.validateTenthFrameRoll(pins, frame, rollInFrame); err != nil {
			return err
		}
		g.rolls = append(g.rolls, pins)
		return nil
	}

	// For regular frames (1-9)
	if rollInFrame == 0 {
		// First roll of the frame - can be 0-10
		g.rolls = append(g.rolls, pins)
	} else {
		// Second roll of the frame - must not exceed 10 with first roll
		firstRoll := g.rolls[g.rollIdx+frame*2+rollInFrame-1]
		if firstRoll+pins > 10 {
			return errors.New("second roll cannot exceed remaining pins")
		}
		g.rolls = append(g.rolls, pins)
	}

	return nil
}

func (g *Game) Score() (int, error) {
	if !g.isGameComplete() {
		return 0, errors.New("game is not complete")
	}

	score := 0
	rollIdx := 0

	for frame := 0; frame < 10; frame++ {
		// Strike
		if g.rolls[rollIdx] == 10 {
			if rollIdx+2 >= len(g.rolls) {
				return 0, errors.New("invalid game state")
			}
			score += 10 + g.rolls[rollIdx+1] + g.rolls[rollIdx+2]
			rollIdx += 1
		} else if rollIdx+1 < len(g.rolls) {
			// Spare
			firstRoll := g.rolls[rollIdx]
			secondRoll := g.rolls[rollIdx+1]
			if firstRoll+secondRoll == 10 {
				if rollIdx+2 >= len(g.rolls) {
					return 0, errors.New("invalid game state")
				}
				score += 10 + g.rolls[rollIdx+2]
				rollIdx += 2
			} else {
				// Open frame
				score += firstRoll + secondRoll
				rollIdx += 2
			}
		} else {
			return 0, errors.New("invalid game state")
		}
	}

	return score, nil
}

// currentFrameInfo returns the current frame (0-9) and the roll number within the frame (0-1)
func (g *Game) currentFrameInfo() (int, int) {
	rolls := g.rolls
	idx := 0
	frame := 0

	for frame < 9 {
		// First roll of frame
		if idx >= len(rolls) {
			return frame, 0
		}
		if rolls[idx] == 10 { // Strike
			idx += 1
		} else {
			idx += 1
			if idx >= len(rolls) {
				return frame, 1
			}
			idx += 1
		}
		frame++
	}

	// In the 10th frame, count rolls to determine roll number
	if idx < len(rolls) {
		return 9, idx - frame*2 // This approximation may need adjustment
	}
	return 9, 0
}

// validateTenthFrameRoll validates rolls specific to the 10th frame
func (g *Game) validateTenthFrameRoll(pins, frame, rollInFrame int) error {
	if frame != 9 {
		return nil
	}

	// Get the rolls in the 10th frame
	// The 10th frame starts at index 18 in a complete game (9 frames * 2 rolls)
	// But with strikes it can be different, so we need to calculate based on actual rolls

	// Count how many rolls are in the 10th frame
	rollIdx := 0
	frameCount := 0
	for frameCount < 9 && rollIdx < len(g.rolls) {
		if g.rolls[rollIdx] == 10 {
			rollIdx++
		} else {
			rollIdx++
			if rollIdx < len(g.rolls) {
				rollIdx++
			}
		}
		frameCount++
	}

	// Now rollIdx points to the first roll of the 10th frame
	tenthFrameStart := rollIdx
	rollInTenthFrame := g.rollIdx - tenthFrameStart

	switch rollInTenthFrame {
	case 0:
		// First roll of 10th frame
		if pins > 10 {
			return errors.New("first roll cannot exceed 10")
		}
	case 1:
		// Second roll of 10th frame
		firstRoll := g.rolls[tenthFrameStart]
		if firstRoll+pins > 10 && firstRoll < 10 {
			// Not a strike on first roll, so second roll must leave some pins
			return errors.New("cannot strike or spare with fill ball")
		}
	case 2:
		// Third roll (fill ball) - only exists if first two rolls were a strike or spare
		firstRoll := g.rolls[tenthFrameStart]
		secondRoll := g.rolls[tenthFrameStart+1]
		
		// Determine if a fill ball exists
		if firstRoll == 10 {
			// Strike on first roll, so second and third rolls are fill balls
			if secondRoll == 10 {
				// Two strikes, third roll is a fill ball - any value 0-10 is valid
			} else {
				// One strike, second roll is not a strike, third roll is a fill ball
				if secondRoll+pins > 10 {
					return errors.New("fill ball cannot exceed remaining pins")
				}
			}
		} else {
			// Not a strike on first roll
			if firstRoll+secondRoll == 10 {
				// Spare, third roll is a fill ball - any value 0-10 is valid
			} else {
				// Open frame, no fill ball should exist
				return errors.New("no fill ball for open frame")
			}
		}
	default:
		return errors.New("too many rolls in 10th frame")
	}

	return nil
}

// isGameComplete checks if the game has been played completely
func (g *Game) isGameComplete() bool {
	if len(g.rolls) == 0 {
		return false
	}

	rollIdx := 0
	frame := 0

	for frame < 9 {
		if rollIdx >= len(g.rolls) {
			return false
		}
		if g.rolls[rollIdx] == 10 { // Strike
			rollIdx++
		} else {
			if rollIdx+1 >= len(g.rolls) {
				return false
			}
			if g.rolls[rollIdx]+g.rolls[rollIdx+1] > 10 {
				return false // Invalid state, treat as not complete
			}
			rollIdx += 2
		}
		frame++
	}

	// 10th frame logic
	if rollIdx >= len(g.rolls) {
		return false
	}

	firstRoll := g.rolls[rollIdx]
	secondRoll := g.rolls[rollIdx+1]

	if firstRoll == 10 {
		// Strike, need a third roll
		if rollIdx+2 >= len(g.rolls) {
			return false
		}
		_ = g.rolls[rollIdx+2]
		if secondRoll == 10 {
			// Two strikes, third roll is a fill ball - game complete with 3 rolls
			return true
		}
		// One strike, second and third rolls - game complete
		return true
	} else {
		// Not a strike on first roll
		if firstRoll+secondRoll == 10 {
			// Spare, need a third roll
			if rollIdx+2 >= len(g.rolls) {
				return false
			}
			return true
		} else {
			// Open frame, game complete with 2 rolls
			return true
		}
	}
}

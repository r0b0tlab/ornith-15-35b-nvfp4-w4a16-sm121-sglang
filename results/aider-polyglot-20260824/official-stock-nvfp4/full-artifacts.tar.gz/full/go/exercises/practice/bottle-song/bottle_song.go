package bottlesong

import "fmt"

func Recite(startBottles, takeDown int) []string {
	var verses []string

	for i := 0; i < takeDown; i++ {
		currentBottles := startBottles - i

		if i > 0 {
			verses = append(verses, "")
		}

		currentWord := numberToWord(currentBottles)

		verses = append(verses, fmt.Sprintf("%s green bottles hanging on the wall,", currentWord))
		verses = append(verses, fmt.Sprintf("%s green bottles hanging on the wall,", currentWord))
		verses = append(verses, "And if one green bottle should accidentally fall,")

		remainingBottles := currentBottles - 1
		remainingWord := numberToWord(remainingBottles)

		remainingNoun := "bottles"
		if remainingBottles == 1 {
			remainingNoun = "bottle"
		}

		verses = append(verses, fmt.Sprintf("There'll be %s green %s hanging on the wall.", remainingWord, remainingNoun))
	}

	return verses
}

func numberToWord(num int) string {
	switch num {
	case 0:
		return "no"
	case 1:
		return "one"
	case 2:
		return "two"
	case 3:
		return "three"
	case 4:
		return "four"
	case 5:
		return "five"
	case 6:
		return "six"
	case 7:
		return "seven"
	case 8:
		return "eight"
	case 9:
		return "nine"
	case 10:
		return "ten"
	default:
		return fmt.Sprintf("%d", num)
	}
}

package forth

import (
	"strconv"
	"strings"
	"unicode"
)

type stack []int

func (s *stack) push(v int) {
	*s = append(*s, v)
}

func (s *stack) pop() (int, bool) {
	if len(*s) == 0 {
		return 0, false
	}
	v := (*s)[len(*s)-1]
	*s = (*s)[:len(*s)-1]
	return v, true
}

func (s stack) clone() stack {
	c := make(stack, len(s))
	copy(c, s)
	return c
}

type word struct {
	def  []string
	variadic bool
}

func Forth(input []string) ([]int, error) {
	var st stack
	words := make(map[string]word)

	for _, line := range input {
		tokens := tokenize(line)
		if err := processLine(tokens, &st, words); err != nil {
			return nil, err
		}
	}

	result := make([]int, len(st))
	copy(result, st)
	return result, nil
}

func tokenize(line string) []string {
	var tokens []string
	var current strings.Builder

	flush := func() {
		if current.Len() > 0 {
			tokens = append(tokens, current.String())
			current.Reset()
		}
	}

	for _, r := range line {
		if unicode.IsSpace(r) {
			flush()
			continue
		}
		current.WriteRune(r)
	}
	flush()

	return tokens
}

func processLine(tokens []string, st *stack, words map[string]word) error {
	if len(tokens) == 0 {
		return nil
	}

	if tokens[0] == ":" {
		return defineWord(tokens, st, words)
	}

	return execute(tokens, st, words)
}

func defineWord(tokens []string, st *stack, words map[string]word) error {
	if len(tokens) < 3 || tokens[len(tokens)-1] != ";" {
		return &EvalError{"invalid definition"}
	}

	name := strings.ToLower(tokens[1])

	if _, err := strconv.Atoi(name); err == nil {
		return &EvalError{"cannot redefine a number"}
	}

	def := tokens[2 : len(tokens)-1]

	// Check if we're redefining an existing word
	if existing, ok := words[name]; ok {
		if existing.variadic {
			return &EvalError{"cannot redefine a variadic word"}
		}
	}

	words[name] = word{def: def}

	return nil
}

func execute(tokens []string, st *stack, words map[string]word) error {
	for _, token := range tokens {
		if err := executeToken(token, st, words); err != nil {
			return err
		}
	}
	return nil
}

func executeToken(token string, st *stack, words map[string]word) error {
	lower := strings.ToLower(token)

	// Check if it's a user-defined word
	if w, ok := words[lower]; ok {
		return execute(w.def, st, words)
	}

	// Check if it's a number
	if num, err := strconv.Atoi(token); err == nil {
		st.push(num)
		return nil
	}

	// Otherwise it's a built-in operation
	return executeBuiltin(lower, st)
}

func executeBuiltin(token string, st *stack) error {
	switch token {
	case "+":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(a + b)
	case "-":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(a - b)
	case "*":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(a * b)
	case "/":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		if b == 0 {
			return &EvalError{"divide by zero"}
		}
		st.push(a / b)
	case "dup":
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(a)
		st.push(a)
	case "drop":
		_, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
	case "swap":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(b)
		st.push(a)
	case "over":
		b, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		a, ok := st.pop()
		if !ok {
			return &EvalError{"stack empty"}
		}
		st.push(a)
		st.push(b)
		st.push(a)
	default:
		return &EvalError{"unknown word: " + token}
	}

	return nil
}

type EvalError struct {
	msg string
}

func (e *EvalError) Error() string {
	return e.msg
}

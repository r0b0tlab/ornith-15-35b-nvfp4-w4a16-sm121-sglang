package alphametics

import (
	"strings"
)

func Solve(puzzle string) (map[string]int, error) {
	// Split the puzzle into words (addends and result)
	words := parsePuzzle(puzzle)
	if len(words) == 0 {
		return nil, &PuzzleError{"No valid words found in puzzle"}
	}

	// Collect all unique letters
	letters := make(map[byte]bool)
	for _, word := range words {
		for i := 0; i < len(word); i++ {
			letters[word[i]] = true
		}
	}

	// If we have more than 10 unique letters, no solution possible
	if len(letters) > 10 {
		return nil, &PuzzleError{"Too many unique letters"}
	}

	// Identify leading letters (cannot be zero)
	leadingZeroForbidden := make(map[byte]bool)
	for _, word := range words {
		if len(word) > 1 {
			leadingZeroForbidden[word[0]] = true
		}
	}

	// Convert letters to a slice for iteration
	letterSlice := make([]byte, 0)
	for letter := range letters {
		letterSlice = append(letterSlice, letter)
	}

	// Result to hold the assignment
	result := make(map[byte]int)

	// Try all permutations using backtracking
	if !backtrack(letterSlice, leadingZeroForbidden, words, 0, result) {
		return nil, &PuzzleError{"No solution found"}
	}

	// Convert to map[string]int for the return value
	resultString := make(map[string]int)
	for letter, digit := range result {
		resultString[string(letter)] = digit
	}

	return resultString, nil
}

// backtrack attempts to assign digits to letters
func backtrack(letterSlice []byte, leadingZeroForbidden map[byte]bool, words []string, index int, result map[byte]int) bool {
	if index == len(letterSlice) {
		// Check if this assignment forms a valid sum
		if isValidSum(words, result) {
			return true
		}
		return false
	}

	letter := letterSlice[index]

	// Try each digit from 0-9
	for digit := 0; digit <= 9; digit++ {
		// Skip if this digit is already used
		used := false
		for _, usedDigit := range result {
			if usedDigit == digit {
				used = true
				break
			}
		}
		if used {
			continue
		}

		// Skip if this letter is a leading letter and digit is 0
		if digit == 0 && leadingZeroForbidden[letter] {
			continue
		}

		// Assign the digit
		result[letter] = digit

		// Recurse to the next letter
		if backtrack(letterSlice, leadingZeroForbidden, words, index+1, result) {
			return true
		}

		// Remove the assignment (backtrack)
		delete(result, letter)
	}

	return false
}

// isValidSum checks if the current assignment forms a valid sum
func isValidSum(words []string, result map[byte]int) bool {
	// Sum all addends (all words except the last)
	sum := 0
	for i := 0; i < len(words)-1; i++ {
		sum += wordValue(words[i], result)
	}

	// Compare with the result word (last word)
	return sum == wordValue(words[len(words)-1], result)
}

// wordValue converts a word to its numeric value based on the current assignment
func wordValue(word string, result map[byte]int) int {
	value := 0
	for i := 0; i < len(word); i++ {
		value = value*10 + result[word[i]]
	}
	return value
}

// parsePuzzle splits the puzzle into individual words
func parsePuzzle(puzzle string) []string {
	// Split on == and +
	parts := strings.Split(puzzle, "==")
	if len(parts) != 2 {
		return nil
	}

	leftParts := strings.Split(parts[0], "+")
	rightParts := strings.Split(parts[1], "+")

	var words []string
	for _, part := range leftParts {
		part = strings.TrimSpace(part)
		if part != "" {
			words = append(words, part)
		}
	}
	for _, part := range rightParts {
		part = strings.TrimSpace(part)
		if part != "" {
			words = append(words, part)
		}
	}

	return words
}

// PuzzleError represents an error when no solution exists
type PuzzleError struct {
	msg string
}

func (e *PuzzleError) Error() string {
	return e.msg
}

package connect

import (
	"errors"
	"strings"
)

// hex represents a position on the hex board.
type hex struct {
	row, col int
}

// ResultOf computes the winner of a Hex game.
func ResultOf(lines []string) (string, error) {
	// Parse the board, removing leading spaces.
	var board [][]byte
	for _, line := range lines {
		// Each row has increasing indentation (0, 1, 2, ...).
		trimmed := strings.TrimLeft(line, " ")
		if len(trimmed) == 0 {
			return "", errors.New("empty line")
		}
		row := make([]byte, len(trimmed))
		copy(row, trimmed)
		board = append(board, row)
	}

	n := len(board)
	if n == 0 {
		return "", errors.New("empty board")
	}

	// Check that all rows have the same length (a proper parallelogram board).
	for _, row := range board {
		if len(row) != n {
			return "", errors.New("irregular board")
		}
	}

	// Check for player O (top to bottom) win.
	if hasWinner(board, 'O', n) {
		return "O", nil
	}

	// Check for player X (left to right) win.
	if hasWinner(board, 'X', n) {
		return "X", nil
	}

	return "", nil
}

// hasWinner checks if the given player has a winning connection.
// For player 'O', we need to connect the top row to the bottom row.
// For player 'X', we need to connect the left column to the right column.
func hasWinner(board [][]byte, player byte, n int) bool {
	visited := make([][]bool, n)
	for i := range visited {
		visited[i] = make([]bool, n)
	}

	// BFS queue.
	var queue []hex

	// Initialize the queue with all starting positions.
	for i := 0; i < n; i++ {
		if player == 'O' {
			// Player O starts from the top row.
			if board[0][i] == player {
				queue = append(queue, hex{0, i})
				visited[0][i] = true
			}
		} else {
			// Player X starts from the left column.
			if board[i][0] == player {
				queue = append(queue, hex{i, 0})
				visited[i][0] = true
			}
		}
	}

	// Direction offsets for hex neighbors.
	// In a hex parallelogram board, each cell has up to 6 neighbors.
	// The diagonal neighbors depend on the row's parity/offset.
	var directions []hex
	if player == 'O' {
		directions = []hex{
			{0, 1},   // right
			{0, -1},  // left
			{1, 0},   // down-right
			{1, -1},  // down-left
			{-1, 0},  // up-right
			{-1, 1},  // up-left
		}
	} else {
		directions = []hex{
			{1, 0},   // down
			{-1, 0},  // up
			{0, 1},   // right
			{0, -1},  // left
			{1, -1},  // down-left
			{-1, 1},  // up-right
		}
	}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		// Check if we've reached the target side.
		if player == 'O' {
			if current.row == n-1 {
				return true
			}
		} else {
			if current.col == n-1 {
				return true
			}
		}

		// Explore neighbors.
		for _, dir := range directions {
			nr, nc := current.row+dir.row, current.col+dir.col
			if nr >= 0 && nr < n && nc >= 0 && nc < n && !visited[nr][nc] && board[nr][nc] == player {
				visited[nr][nc] = true
				queue = append(queue, hex{nr, nc})
			}
		}
	}

	return false
}

package kindergarten

import (
	"fmt"
	"sort"
	"strings"
)

// Garden represents a kindergarten garden with children and their assigned plants.
type Garden struct {
	diagram   string
	children  []string
}

// Default children names in alphabetical order.
var defaultChildren = []string{
	"Alice", "Bob", "Charlie", "David",
	"Eve", "Fred", "Ginny", "Harriet",
	"Ileana", "Joseph", "Kincaid", "Larry",
}

// plantName converts a single character to its plant name.
func plantName(char byte) string {
	switch char {
	case 'G':
		return "Grass"
	case 'C':
		return "Clover"
	case 'R':
		return "Radishes"
	case 'V':
		return "Violets"
	default:
		return ""
	}
}

// NewGarden creates a new garden from a diagram and list of children.
func NewGarden(diagram string, children []string) (*Garden, error) {
	// Split diagram into rows
	rows := strings.Split(diagram, "\n")
	if len(rows) != 2 {
		return nil, fmt.Errorf("diagram must have exactly 2 rows")
	}

	// Check that all rows have the same length and it's even
	if len(rows[0]) != len(rows[1]) {
		return nil, fmt.Errorf("rows must have equal length")
	}

	if len(rows[0])%2 != 0 || len(rows[0]) == 0 {
		return nil, fmt.Errorf("row length must be even and non-zero")
	}

	// Default children if none provided
	if len(children) == 0 {
		children = append(children, defaultChildren...)
	} else {
		// Validate children names
		for _, child := range children {
			found := false
			for _, def := range defaultChildren {
				if child == def {
					found = true
					break
				}
			}
			if !found {
				return nil, fmt.Errorf("unknown child name: %s", child)
			}
		}

		// Check for duplicate names
		seen := make(map[string]bool)
		for _, child := range children {
			if seen[child] {
				return nil, fmt.Errorf("duplicate child name: %s", child)
			}
			seen[child] = true
		}

		// Sort children alphabetically to assign cups correctly
		sort.Strings(children)
	}

	return &Garden{
		diagram:  diagram,
		children: children,
	}, nil
}

// Plants returns the plants assigned to a specific child.
func (g *Garden) Plants(child string) ([]string, bool) {
	// Check if child exists
	index := -1
	for i, c := range g.children {
		if c == child {
			index = i
			break
		}
	}
	if index == -1 {
		return nil, false
	}

	// Each child gets 2 cups per row, starting at position index*2
	pos := index * 2

	// Parse the diagram into rows
	rows := strings.Split(g.diagram, "\n")

	var plants []string

	// First row
	row1 := rows[0]
	if pos+1 < len(row1) {
		plants = append(plants, plantName(row1[pos]))
		plants = append(plants, plantName(row1[pos+1]))
	}

	// Second row
	row2 := rows[1]
	if pos+1 < len(row2) {
		plants = append(plants, plantName(row2[pos]))
		plants = append(plants, plantName(row2[pos+1]))
	}

	return plants, true
}

package poker

import (
	"errors"
	"sort"
)

func BestHand(hands []string) ([]string, error) {
	if len(hands) == 0 {
		return nil, errors.New("no hands provided")
	}

	bestScores := make([]int, 0)
	resultHands := make([]string, 0)

	for _, hand := range hands {
		score, err := evaluateHand(hand)
		if err != nil {
			return nil, err
		}

		if len(resultHands) == 0 {
			bestScores = append(bestScores, score)
			resultHands = append(resultHands, hand)
		} else {
			if score > bestScores[0] {
				bestScores = []int{score}
				resultHands = []string{hand}
			} else if score == bestScores[0] {
				bestScores = append(bestScores, score)
				resultHands = append(resultHands, hand)
			}
		}
	}

	return resultHands, nil
}

// evaluateHand parses and scores a poker hand, returning a score where
// higher values indicate better hands.
func evaluateHand(hand string) (int, error) {
	cards := splitHand(hand)
	if len(cards) != 5 {
		return 0, errors.New("invalid hand: must contain exactly 5 cards")
	}

	ranks := make([]int, 5)
	suits := make([]int, 5)

	for i, card := range cards {
		if len(card) < 2 {
			return 0, errors.New("invalid card: " + card)
		}

		rankChar := card[0]
		suitChar := card[len(card)-1]

		rank, err := parseRank(rankChar)
		if err != nil {
			return 0, err
		}

		suit, err := parseSuit(suitChar)
		if err != nil {
			return 0, err
		}

		ranks[i] = rank
		suits[i] = suit
	}

	// Check for flush (all same suit)
	flush := false
	for i := 1; i < 5; i++ {
		if suits[i] != suits[0] {
			break
		}
		if i == 4 {
			flush = true
		}
	}

	// Sort ranks for analysis
	sortedRanks := make([]int, 5)
	copy(sortedRanks, ranks)
	sort.Ints(sortedRanks)

	// Check for straight
	straight := false
	if isStraight(sortedRanks) {
		straight = true
	}

	// Handle special case: A-2-3-4-5 (wheel)
	if !straight && hasWheel(sortedRanks) {
		straight = true
	}

	// Count rank occurrences
	rankCounts := make(map[int]int)
	for _, rank := range ranks {
		rankCounts[rank]++
	}

	// Determine hand category and tiebreaker values
	groups := make([]int, 0, len(rankCounts))
	for _, count := range rankCounts {
		groups = append(groups, count)
	}
	sort.Slice(groups, func(i, j int) bool {
		return groups[i] > groups[j]
	})

	switch {
	case straight && flush:
		return 8000 + highestRankInStraight(sortedRanks), nil
	case len(groups) == 1 && groups[0] == 4:
		return 7000 + 100*sortedRanks[3] + sortedRanks[0], nil
	case len(groups) == 2 && groups[0] == 3 && groups[1] == 2:
		return 6000 + 100*sortedRanks[2] + sortedRanks[0], nil
	case flush:
		return 5000 + highestCardValue(sortedRanks), nil
	case straight:
		return 4000 + highestRankInStraight(sortedRanks), nil
	case len(groups) == 2 && groups[0] == 3:
		return 3000 + 100*sortedRanks[2] + highestKicker(sortedRanks, ranks), nil
	case len(groups) == 3 && groups[0] == 2 && groups[1] == 2:
		return 2000 + 100*maxPair(sortedRanks) + minPair(sortedRanks), nil
	case len(groups) == 4 && groups[0] == 2:
		return 1000 + 100*sortedRanks[3] + remainingKickers(sortedRanks, ranks), nil
	default:
		return highestCardValue(sortedRanks), nil
	}
}

// splitHand splits a hand string into individual cards.
func splitHand(hand string) []string {
	var cards []string
	current := ""

	for _, ch := range hand {
		if ch == ' ' {
			if current != "" {
				cards = append(cards, current)
				current = ""
			}
		} else {
			current += string(ch)
		}
	}
	if current != "" {
		cards = append(cards, current)
	}

	return cards
}

// parseRank converts a rank character to its numeric value.
func parseRank(char byte) (int, error) {
	switch char {
	case '2':
		return 2, nil
	case '3':
		return 3, nil
	case '4':
		return 4, nil
	case '5':
		return 5, nil
	case '6':
		return 6, nil
	case '7':
		return 7, nil
	case '8':
		return 8, nil
	case '9':
		return 9, nil
	case 'T':
		return 10, nil
	case 'J':
		return 11, nil
	case 'Q':
		return 12, nil
	case 'K':
		return 13, nil
	case 'A':
		return 14, nil
	default:
		return 0, errors.New("invalid rank: " + string(char))
	}
}

// parseSuit converts a suit character to a comparable value.
func parseSuit(char byte) (int, error) {
	switch char {
	case 'C':
		return 1, nil
	case 'D':
		return 2, nil
	case 'H':
		return 3, nil
	case 'S':
		return 4, nil
	default:
		return 0, errors.New("invalid suit: " + string(char))
	}
}

// isStraight checks if the sorted ranks form a consecutive sequence.
func isStraight(sortedRanks []int) bool {
	for i := 1; i < 5; i++ {
		if sortedRanks[i] != sortedRanks[i-1]+1 {
			return false
		}
	}
	return true
}

// hasWheel checks for the A-2-3-4-5 straight (wheel).
func hasWheel(sortedRanks []int) bool {
	return sortedRanks[0] == 2 &&
		sortedRanks[1] == 3 &&
		sortedRanks[2] == 4 &&
		sortedRanks[3] == 5 &&
		sortedRanks[4] == 14
}

// highestRankInStraight determines the top rank of a straight,
// with special handling for the wheel (A-2-3-4-5 where A counts as 1).
func highestRankInStraight(sortedRanks []int) int {
	if hasWheel(sortedRanks) {
		return 5 // Wheel: A counts as low, so 5 is the high card
	}
	return sortedRanks[4]
}

// highestCardValue returns the highest card value from sorted ranks.
func highestCardValue(sortedRanks []int) int {
	return sortedRanks[4]
}

// highestKicker returns the highest card that isn't part of the trips.
func highestKicker(sortedRanks []int, ranks []int) int {
	// The trips are the three highest cards (sortedRanks[2], [3], [4])
	// The kicker is the highest of the remaining two
	return max(sortedRanks[0], sortedRanks[1])
}

// remainingKickers returns a combined value of the two kickers.
func remainingKickers(sortedRanks []int, ranks []int) int {
	// The pair is at sortedRanks[3] and [4] (highest two, since pair matches)
	// The kickers are sortedRanks[0], [1], [2] - take the top two
	// Combine as: 10*second + third
	return 10*sortedRanks[1] + sortedRanks[2]
}

// maxPair returns the higher of the two pairs.
func maxPair(sortedRanks []int) int {
	// With two pairs, the structure is: kicker, pair2, pair2, pair1, pair1
	// (after sorting, the pairs are adjacent at the top)
	// Actually need to determine which ranks form pairs
	// For two pair: sortedRanks = [kicker, p2, p2, p1, p1] where p1 > p2
	// Wait, this depends on the actual ranks. Let me handle this properly.
	return findPairRank(sortedRanks, 2)
}

// minPair returns the lower of the two pairs.
func minPair(sortedRanks []int) int {
	highPair := findPairRank(sortedRanks, 2)
	return findPairRank(sortedRanks, highPair)
}

// findPairRank finds a rank that appears exactly `count` times.
func findPairRank(sortedRanks []int, skipRank int) int {
	counts := make(map[int]int)
	for _, r := range sortedRanks {
		if r == skipRank {
			continue
		}
		counts[r]++
	}

	for rank, count := range counts {
		if count == 2 {
			return rank
		}
	}

	return 0
}

// max returns the larger of two integers.
func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

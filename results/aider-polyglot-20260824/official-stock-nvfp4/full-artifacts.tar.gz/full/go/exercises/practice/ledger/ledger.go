package ledger

import (
	"errors"
	"sort"
	"strconv"
	"strings"
)

type Entry struct {
	Date        string // "Y-m-d"
	Description string
	Change      int // in cents
}

func FormatLedger(currency string, locale string, entries []Entry) (string, error) {
	if currency != "USD" && currency != "EUR" {
		return "", errors.New("invalid currency")
	}

	entriesCopy := make([]Entry, len(entries))
	copy(entriesCopy, entries)

	sort.Slice(entriesCopy, func(i, j int) bool {
		if entriesCopy[i].Date != entriesCopy[j].Date {
			return entriesCopy[i].Date < entriesCopy[j].Date
		}
		if entriesCopy[i].Description != entriesCopy[j].Description {
			return entriesCopy[i].Description < entriesCopy[j].Description
		}
		return entriesCopy[i].Change < entriesCopy[j].Change
	})

	var header string
	if locale == "nl-NL" {
		header = headerRow("Datum", "Omschrijving", "Verandering")
	} else if locale == "en-US" {
		header = headerRow("Date", "Description", "Change")
	} else {
		return "", errors.New("invalid locale")
	}

	var sb strings.Builder
	sb.WriteString(header)

	for _, e := range entriesCopy {
		date, err := formatDate(e.Date, locale)
		if err != nil {
			return "", err
		}

		desc := formatDescription(e.Description)

		change, err := formatChange(e.Change, currency, locale)
		if err != nil {
			return "", err
		}

		sb.WriteString(date)
		sb.WriteString(" | ")
		sb.WriteString(desc)
		sb.WriteString(" | ")
		sb.WriteString(change)
		sb.WriteString("\n")
	}

	return sb.String(), nil
}

func headerRow(dateHeader, descHeader, changeHeader string) string {
	var sb strings.Builder
	sb.WriteString(dateHeader)
	sb.WriteString(strings.Repeat(" ", 10-len(dateHeader)))
	sb.WriteString(" | ")
	sb.WriteString(descHeader)
	sb.WriteString(strings.Repeat(" ", 25-len(descHeader)))
	sb.WriteString(" | ")
	sb.WriteString(changeHeader)
	sb.WriteString("\n")
	return sb.String()
}

func formatDate(date string, locale string) (string, error) {
	if len(date) != 10 {
		return "", errors.New("invalid date format")
	}
	d1, d2, d3, d4, d5 := date[0:4], date[4], date[5:7], date[7], date[8:10]
	if d2 != '-' || d4 != '-' {
		return "", errors.New("invalid date format")
	}

	var result string
	if locale == "nl-NL" {
		result = d5 + "-" + d3 + "-" + d1
	} else if locale == "en-US" {
		result = d3 + "/" + d5 + "/" + d1
	} else {
		return "", errors.New("invalid locale")
	}

	return result + strings.Repeat(" ", 10-len(result)), nil
}

func formatDescription(description string) string {
	if len(description) > 25 {
		return description[:22] + "..."
	}
	return description + strings.Repeat(" ", 25-len(description))
}

func formatChange(change int, currency string, locale string) (string, error) {
	negative := false
	cents := change
	if cents < 0 {
		cents = -cents
		negative = true
	}

	var symbol string
	if currency == "EUR" {
		symbol = "€"
	} else if currency == "USD" {
		symbol = "$"
	} else {
		return "", errors.New("invalid currency")
	}

	centsStr := strconv.Itoa(cents)
	switch len(centsStr) {
	case 1:
		centsStr = "00" + centsStr
	case 2:
		centsStr = "0" + centsStr
	}

	var parts []string
	rest := centsStr[:len(centsStr)-2]
	for len(rest) > 3 {
		parts = append(parts, rest[len(rest)-3:])
		rest = rest[:len(rest)-3]
	}
	if len(rest) > 0 {
		parts = append(parts, rest)
	}

	var numberStr string
	for i := len(parts) - 1; i >= 0; i-- {
		if locale == "nl-NL" {
			numberStr += parts[i] + "."
		} else {
			numberStr += parts[i] + ","
		}
	}
	if len(numberStr) > 0 {
		numberStr = numberStr[:len(numberStr)-1]
	}
	numberStr += "."
	numberStr += centsStr[len(centsStr)-2:]

	var result string
	if locale == "nl-NL" {
		result = symbol + " " + numberStr
		if negative {
			result = result + "-"
		} else {
			result = result + " "
		}
	} else {
		if negative {
			result = "(" + symbol + numberStr + ")"
		} else {
			result = symbol + " " + numberStr
		}
	}

	return result + strings.Repeat(" ", 13-len(result)), nil
}

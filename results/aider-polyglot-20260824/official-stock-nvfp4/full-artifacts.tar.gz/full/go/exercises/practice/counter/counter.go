package counter

import (
	"strings"
	"unicode"
)

// Add adds a string to the counter
func Add(c Counter, str string) {
	c.characters += len(str)
	c.letters += countLetters(str)
	c.lines += countLines(str)
}

// countLines counts the number of lines in a string
func countLines(str string) int {
	lines := strings.Count(str, "\n")
	if len(str) > 0 && !strings.HasSuffix(str, "\n") {
		lines++
	}
	return lines
}

// countLetters counts the number of letters in a string
func countLetters(str string) int {
	count := 0
	for _, r := range str {
		if unicode.IsLetter(r) {
			count++
		}
	}
	return count
}

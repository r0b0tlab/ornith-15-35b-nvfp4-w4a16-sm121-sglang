package hexadecimal

import (
	"errors"
	"fmt"
)

func ParseHex(in string) (int64, error) {
	if len(in) == 0 {
		return 0, errors.New("empty input")
	}

	var result int64 = 0

	for _, char := range in {
		var value int64

		switch {
		case char >= '0' && char <= '9':
			value = int64(char - '0')
		case char >= 'a' && char <= 'f':
			value = int64(char-'a') + 10
		case char >= 'A' && char <= 'F':
			value = int64(char-'A') + 10
		default:
			return 0, fmt.Errorf("invalid hexadecimal character: %q", char)
		}

		result = result*16 + value
	}

	return result, nil
}

func HandleErrors(in string) (int64, error) {
	return ParseHex(in)
}

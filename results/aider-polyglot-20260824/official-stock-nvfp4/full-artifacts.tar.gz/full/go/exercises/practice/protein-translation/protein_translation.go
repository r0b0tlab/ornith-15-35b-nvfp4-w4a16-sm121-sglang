package protein

import "errors"

var (
	ErrStop         = errors.New("stop codon")
	ErrInvalidCodon = errors.New("invalid codon")
)

func FromCodon(codon string) (string, error) {
	switch codon {
	case "AUG":
		return "Methionine", nil
	case "UUU", "UUC":
		return "Phenylalanine", nil
	case "UUA", "UUG":
		return "Leucine", nil
	case "UCU", "UCC", "UCA", "UCG":
		return "Serine", nil
	case "UAU", "UAC":
		return "Tyrosine", nil
	case "UGU", "UGC":
		return "Cysteine", nil
	case "UGG":
		return "Tryptophan", nil
	case "UAA", "UAG", "UGA":
		return "", ErrStop
	default:
		return "", ErrInvalidCodon
	}
}

func FromRNA(rna string) ([]string, error) {
	var proteins []string

	for i := 0; i < len(rna); i += 3 {
		// Ensure we have a complete codon
		if i+3 > len(rna) {
			return nil, ErrInvalidCodon
		}

		codon := rna[i : i+3]

		protein, err := FromCodon(codon)
		if err != nil {
			if err == ErrStop {
				// STOP codon terminates translation
				return proteins, nil
			}
			return nil, err
		}

		proteins = append(proteins, protein)
	}

	return proteins, nil
}

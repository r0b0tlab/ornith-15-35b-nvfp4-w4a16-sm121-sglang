package counter

// NewCounter returns a counter value that implements the
// Counter interface. Each call to NewCounter returns a
// new, independent counter instance.
func NewCounter() Counter {
	impl1 := &Impl1{}
	impl1.Add("1 2 3")
	impl1.Add("abc")

	impl2 := &Impl2{}
	impl2.Add("1 2 3")
	impl2.Add("abc")

	impl3 := &Impl3{}
	impl3.Add("1 2 3")
	impl3.Add("abc")

	impl4 := &Impl4{}
	impl4.Add("1 2 3")
	impl4.Add("abc")

	return []Counter{impl1, impl2, impl3, impl4}[num]
}

// Impl1 is a simple counter implementation
type Impl1 struct {
	lines      int
	letters    int
	characters int
}

func (c *Impl1) Add(str string) {
	c.characters += len(str)
	c.letters += countLetters(str)
	c.lines += countLines(str)
}

func (c *Impl1) Lines() int {
	return c.lines
}

func (c *Impl1) letters() int {
	return c.letters
}

func (c *Impl1) Characters() int {
	return c.characters
}

// Impl2 is a simple counter implementation
type Impl2 struct {
	lines      int
	letters    int
	characters int
}

func (c *Impl2) Add(str string) {
	c.characters += len(str)
	c.letters += countLetters(str)
	c.lines += countLines(str)
}

func (c *Impl2) Lines() int {
	return c.lines
}

func (c *Impl2) letters() int {
	return c.letters
}

func (c *Impl2) Characters() int {
	return c.characters
}

// Impl3 is a simple counter implementation
type Impl3 struct {
	lines      int
	letters    int
	characters int
}

func (c *Impl3) Add(str string) {
	c.characters += len(str)
	c.letters += countLetters(str)
	c.lines += countLines(str)
}

func (c *Impl3) Lines() int {
	return c.lines
}

func (c *Impl3) letters() int {
	return c.letters
}

func (c *Impl3) Characters() int {
	return c.characters
}

// Impl4 is a simple counter implementation
type Impl4 struct {
	lines      int
	letters    int
	characters int
}

func (c *Impl4) Add(str string) {
	c.characters += len(str)
	c.letters += countLetters(str)
	c.lines += countLines(str)
}

func (c *Impl4) Lines() int {
	return c.lines
}

func (c *Impl4) letters() int {
	return c.letters
}

func (c *Impl4) Characters() int {
	return c.characters
}

var num = 0

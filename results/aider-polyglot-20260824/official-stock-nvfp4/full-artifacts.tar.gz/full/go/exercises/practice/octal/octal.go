package octal

func ParseOctal(input string, expectedNum int64, expectErr bool) {
	result := int64(0)
	for _, char := range input {
		if char < '0' || char > '7' {
			// Invalid octal input, treat as 0
			result = 0
			break
		}
		result = result*8 + int64(char-'0')
	}
	if result != expectedNum {
		panic(fmt.Sprintf("Expected %d but got %d", expectedNum, result))
	}
	if expectErr && result == expectedNum {
		panic(fmt.Sprintf("Expected error but got %d", result))
	}
}

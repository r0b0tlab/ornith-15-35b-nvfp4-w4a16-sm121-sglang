package piglatin

import "strings"

func Sentence(sentence string) string {
	words := strings.Split(sentence, " ")
	for i, word := range words {
		words[i] = translateWord(word)
	}
	return strings.Join(words, " ")
}

func isVowel(char byte) bool {
	return char == 'a' || char == 'e' || char == 'i' || char == 'o' || char == 'u'
}

func translateWord(word string) string {
	if len(word) == 0 {
		return word
	}

	// Rule 1: Word begins with a vowel, or starts with "xr" or "yt"
	if isVowel(word[0]) {
		return word + "ay"
	}
	if len(word) >= 2 {
		start := word[:2]
		if start == "xr" || start == "yt" {
			return word + "ay"
		}
	}

	// Find the position of the first vowel-like sound, considering special rules.
	var i int
	for i < len(word) {
		char := word[i]
		if isVowel(char) {
			break
		}
		// Handle "qu" as a unit: if we see a "q" followed by "u", treat "u" as part of the consonant cluster.
		if char == 'q' && i+1 < len(word) && word[i+1] == 'u' {
			i += 2
			break
		}
		// "y" acts as a vowel when it's not the first letter.
		if i > 0 && char == 'y' {
			break
		}
		i++
	}

	return word[i:] + word[:i] + "ay"
}

#include "robot_name.h"
#include <stdexcept>
#include <random>
#include <unordered_set>

namespace robot_name {

namespace {
    std::unordered_set<std::string>& used_names() {
        static std::unordered_set<std::string> names;
        return names;
    }

    std::mt19937& get_rng() {
        static std::mt19937 rng(std::random_device{}());
        return rng;
    }
}

Robot::Robot() : has_name_(false) {}

Robot::~Robot() {}

std::string Robot::name() const {
    if (!has_name_) {
        std::uniform_int_distribution<int> letter_dist(0, 25);
        std::uniform_int_distribution<int> digit_dist(0, 9);

        std::string new_name;
        do {
            new_name.clear();
            new_name += static_cast<char>('A' + letter_dist(get_rng()));
            new_name += static_cast<char>('A' + letter_dist(get_rng()));
            new_name += static_cast<char>('0' + digit_dist(get_rng()));
            new_name += static_cast<char>('0' + digit_dist(get_rng()));
            new_name += static_cast<char>('0' + digit_dist(get_rng()));
        } while (used_names().count(new_name) > 0);

        name_ = new_name;
        has_name_ = true;
    }
    return name_;
}

void Robot::reset() {
    if (has_name_) {
        used_names().erase(name_);
        name_.clear();
        has_name_ = false;
    }
}

}  // namespace robot_name

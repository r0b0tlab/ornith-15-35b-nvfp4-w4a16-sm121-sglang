#if !defined(CLOCK_H)
#define CLOCK_H

#include <string>

namespace date_independent {

class clock {
public:
    static clock at(int hours, int minutes);
    clock plus(int minutes) const;
    clock minus(int minutes) const;
    std::string to_string() const;
    bool operator==(const clock& other) const;
    bool operator!=(const clock& other) const;

private:
    int total_minutes_;  // minutes since midnight, normalized to [0, 1440)
    clock(int total_minutes);
};

}  // namespace date_independent

#endif // CLOCK_H

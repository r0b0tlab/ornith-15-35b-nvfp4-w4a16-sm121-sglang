#if !defined(GRADE_SCHOOL_TEST_H)
#define GRADE_SCHOOL_TEST_H

#include <map>
#include <string>
#include <vector>

#include "catch.hpp"
#include "grade_school.h"

namespace grade_school {

TEST_CASE("add_student") {
    grade_school::school school_;
    school_.add("Aimee", 2);
    REQUIRE(school_.roster().at(2).at(0) == "Aimee");
}

TEST_CASE("add_later_enrolled_student") {
    grade_school::school school_;
    school_.add("Blair", 2);
    school_.add("James", 2);
    school_.add("Paul", 2);
    REQUIRE(school_.roster().at(2).at(0) == "Blair");
    REQUIRE(school_.roster().at(2).at(1) == "James");
    REQUIRE(school_.roster().at(2).at(2) == "Paul");
}

TEST_CASE("add_student_in_different_grade") {
    grade_school::school school_;
    school_.add("Jim", 1);
    school_.add("Peter", 2);
    school_.add("Bob", 1);
    REQUIRE(school_.roster().at(1).at(0) == "Bob");
    REQUIRE(school_.roster().at(1).at(1) == "Jim");
    REQUIRE(school_.roster().at(2).at(0) == "Peter");
}

TEST_CASE("add_students_in_different_grades") {
    grade_school::school school_;
    school_.add("Chelsea", 3);
    school_.add("Larrie", 1);
    school_.add("Franklin", 5);
    school_.add("Dereck", 2);
    school_.add("Edwin", 5);
    school_.add("Evan", 2);
    REQUIRE(school_.roster().at(1).at(0) == "Larrie");
    REQUIRE(school_.roster().at(2).at(0) == "Dereck");
    REQUIRE(school_.roster().at(2).at(1) == "Evan");
    REQUIRE(school_.roster().at(3).at(0) == "Chelsea");
    REQUIRE(school_.roster().at(5).at(0) == "Edwin");
    REQUIRE(school_.roster().at(5).at(1) == "Franklin");
}

TEST_CASE("grade_returns_students_in_grade_and_alphabetized") {
    grade_school::school school_;
    school_.add("Peter", 2);
    school_.add("Anna", 2);
    school_.add("Barb", 1);
    REQUIRE(school_.grade(2).at(0) == "Anna");
    REQUIRE(school_.grade(2).at(1) == "Peter");
    REQUIRE(school_.grade(1).at(0) == "Barb");
    REQUIRE(school_.grade(10).empty());
}

TEST_CASE("grade_returns_no_students_when_grade_is_empty") {
    grade_school::school school_;
    school_.add("Sarah", 2);
    REQUIRE(school_.grade(2).at(0) == "Sarah");
    REQUIRE(school_.grade(10).empty());
}

TEST_CASE("roster_is_empty_when_no_student_added") {
    grade_school::school school_;
    REQUIRE(school_.roster().empty());
}

TEST_CASE("roster_is_empty_when_no_student_added_but_student_added_to_grade") {
    grade_school::school school_;
    school_.grade(1);
    REQUIRE(school_.roster().empty());
}

TEST_CASE("special_roster_access") {
    grade_school::school school_;
    school_.add("Jennifer", 4);
    school_.add("Kara", 3);
    school_.add("Darcy", 3);

    auto roster_ = school_.roster();

    REQUIRE(roster_.size() == 3);
    REQUIRE(roster_.at(3).at(0) == "Darcy");
    REQUIRE(roster_.at(3).at(1) == "Kara");
    REQUIRE(roster_.at(4).at(0) == "Jennifer");
}

}  // namespace grade_school

#endif // GRADE_SCHOOL_TEST_H

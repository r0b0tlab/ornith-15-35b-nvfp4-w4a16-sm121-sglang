#include "parallel_letter_frequency.h"

#include <thread>
#include <vector>
#include <map>
#include <algorithm>
#include <atomic>
#include <cctype>

namespace parallel_letter_frequency {

namespace {

void count_in_string(const std::string& text, std::map<char, int>& local_counts) {
    for (char c : text) {
        if (std::isalpha(static_cast<unsigned char>(c))) {
            char lower = std::tolower(static_cast<unsigned char>(c));
            local_counts[lower]++;
        }
    }
}

}

std::map<char, int> frequency(const std::vector<std::string>& texts) {
    std::map<char, int> total_counts;

    if (texts.empty()) {
        return total_counts;
    }

    const size_t num_threads = std::min<size_t>(
        std::thread::hardware_concurrency(), texts.size());

    if (num_threads == 0) {
        // Fallback to sequential if hardware_concurrency not available
        for (const auto& text : texts) {
            count_in_string(text, total_counts);
        }
        return total_counts;
    }

    std::vector<std::map<char, int>> partial_counts(num_threads);
    std::vector<std::thread> threads;

    std::atomic<size_t> index{0};
    for (size_t t = 0; t < num_threads; ++t) {
        threads.emplace_back([&texts, &partial_counts, &index, t] {
            while (true) {
                size_t current = index.fetch_add(1);
                if (current < texts.size()) {
                    count_in_string(texts[current], partial_counts[t]);
                } else {
                    break;
                }
            }
        });
    }

    for (auto& thread : threads) {
        thread.join();
    }

    for (const auto& partial : partial_counts) {
        for (const auto& pair : partial) {
            total_counts[pair.first] += pair.second;
        }
    }

    return total_counts;
}

}

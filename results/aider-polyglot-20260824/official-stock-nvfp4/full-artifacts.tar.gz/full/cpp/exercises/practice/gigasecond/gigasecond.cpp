#include "gigasecond.h"

namespace gigasecond {

// Calculate the date and time one gigasecond after the given time
boost::posix_time::ptime advance(boost::posix_time::ptime time) {
    return time + boost::posix_time::seconds(1000000000);
}

}  // namespace gigasecond

#include "all_your_base.h"
#include <stdexcept>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base, const std::vector<unsigned int>& input_digits, unsigned int output_base) {
    // Validate bases
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("Bases must be >= 2");
    }

    // Convert input to decimal
    unsigned long long decimal_value = 0;
    for (unsigned int digit : input_digits) {
        if (digit >= input_base) {
            throw std::invalid_argument("Invalid input digit");
        }
        decimal_value = decimal_value * input_base + digit;
    }

    // Handle zero case
    if (decimal_value == 0) {
        return {};
    }

    // Convert decimal to output base
    std::vector<unsigned int> output_digits;
    while (decimal_value > 0) {
        output_digits.insert(output_digits.begin(), decimal_value % output_base);
        decimal_value /= output_base;
    }

    return output_digits;
}

}  // namespace all_your_base

#include "sublist.h"

namespace sublist {

// Check if pattern is a contiguous subsequence of main, starting at position i
bool is_subsequence_at(std::vector<int> const& main, std::vector<int> const& pattern, size_t i) {
    if (i + pattern.size() > main.size()) {
        return false;
    }
    for (size_t j = 0; j < pattern.size(); ++j) {
        if (main[i + j] != pattern[j]) {
            return false;
        }
    }
    return true;
}

// Check if 'a' is a sublist of 'b'
bool is_sublist(std::vector<int> const& a, std::vector<int> const& b) {
    if (a.empty()) {
        return true;  // empty list is a sublist of any list
    }
    for (size_t i = 0; i + a.size() <= b.size(); ++i) {
        if (is_subsequence_at(b, a, i)) {
            return true;
        }
    }
    return false;
}

list_type compare(std::vector<int> const& list1, std::vector<int> const& list2) {
    if (list1.size() == list2.size()) {
        bool equal = true;
        for (size_t i = 0; i < list1.size(); ++i) {
            if (list1[i] != list2[i]) {
                equal = false;
                break;
            }
        }
        if (equal) {
            return list_type::equal;
        }
    }
    
    if (is_sublist(list1, list2)) {
        return list_type::sublist;
    }
    
    if (is_sublist(list2, list1)) {
        return list_type::superlist;
    }
    
    return list_type::unequal;
}

}  // namespace sublist

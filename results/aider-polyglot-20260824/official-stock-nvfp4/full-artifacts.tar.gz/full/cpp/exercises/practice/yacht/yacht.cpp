#include "yacht.h"
#include <map>
#include <vector>
#include <string>

namespace yacht {

int score(std::vector<int> dice, const std::string& category) {
    std::map<int, int> counts;
    int total = 0;
    for (int die : dice) {
        counts[die]++;
        total += die;
    }

    if (category == "ones") {
        return counts[1] * 1;
    }
    if (category == "twos") {
        return counts[2] * 2;
    }
    if (category == "threes") {
        return counts[3] * 3;
    }
    if (category == "fours") {
        return counts[4] * 4;
    }
    if (category == "fives") {
        return counts[5] * 5;
    }
    if (category == "sixes") {
        return counts[6] * 6;
    }
    if (category == "full house") {
        bool has_three = false;
        bool has_two = false;
        for (int i = 1; i <= 6; i++) {
            if (counts[i] == 3) {
                has_three = true;
            }
            if (counts[i] == 2) {
                has_two = true;
            }
        }
        if (has_three && has_two) {
            return total;
        }
        return 0;
    }
    if (category == "four of a kind") {
        for (int i = 1; i <= 6; i++) {
            if (counts[i] >= 4) {
                return i * 4;
            }
        }
        return 0;
    }
    if (category == "little straight") {
        if (counts[1] == 1 && counts[2] == 1 && counts[3] == 1 && 
            counts[4] == 1 && counts[5] == 1) {
            return 30;
        }
        return 0;
    }
    if (category == "big straight") {
        if (counts[2] == 1 && counts[3] == 1 && counts[4] == 1 && 
            counts[5] == 1 && counts[6] == 1) {
            return 30;
        }
        return 0;
    }
    if (category == "choice") {
        return total;
    }
    if (category == "yacht") {
        for (int i = 1; i <= 6; i++) {
            if (counts[i] == 5) {
                return 50;
            }
        }
        return 0;
    }
    return 0;
}

}  // namespace yacht

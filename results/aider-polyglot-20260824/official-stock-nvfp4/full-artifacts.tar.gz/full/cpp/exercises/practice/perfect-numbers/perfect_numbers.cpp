#include "perfect_numbers.h"

#include <stdexcept>
#include <cmath>

namespace perfect_numbers {

classification classify(uint64_t number) {
    if (number <= 0) {
        throw std::invalid_argument("Number must be a positive integer");
    }

    if (number == 1) {
        return classification::deficient;
    }

    uint64_t aliquot_sum = 1;
    for (uint64_t i = 2; i * i <= number; ++i) {
        if (number % i == 0) {
            aliquot_sum += i;
            uint64_t complement = number / i;
            if (complement != i) {
                aliquot_sum += complement;
            }
        }
    }

    if (aliquot_sum == number) {
        return classification::perfect;
    } else if (aliquot_sum > number) {
        return classification::abundant;
    } else {
        return classification::deficient;
    }
}

}  // namespace perfect_numbers

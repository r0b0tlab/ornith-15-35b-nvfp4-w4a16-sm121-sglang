#include "meetup.h"
#include <ctime>

namespace meetup {

scheduler::scheduler(month m, int year)
    : month_(m), year_(year) {
    int month = static_cast<int>(m);
    if (month == 2) {
        bool is_leap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        days_in_month_ = is_leap ? 29 : 28;
    } else if (month == 4 || month == 6 || month == 9 || month == 11) {
        days_in_month_ = 30;
    } else {
        days_in_month_ = 31;
    }

    // Find the weekday of the first day of the month
    std::tm tm_val{};
    tm_val.tm_year = year - 1900;
    tm_val.tm_mon = month - 1;
    tm_val.tm_mday = 1;
    tm_val.tm_hour = 12;  // Avoid DST issues
    tm_val.tm_min = 0;
    tm_val.tm_sec = 0;
    tm_val.tm_isdst = -1;
    time_t t = mktime(&tm_val);
    struct tm* local = localtime(&t);
    first_weekday_ = local->tm_wday;
}

int scheduler::weekday_to_int(day_of_week dow) const {
    return static_cast<int>(dow);
}

std::tm scheduler::compute(day_of_week dow, int week) {
    int target_weekday = weekday_to_int(dow);
    int offset = (target_weekday - first_weekday_ + 7) % 7;

    int day;
    if (week == 0) {  // last
        day = offset + 28;
        if (day > days_in_month_) {
            day -= 7;
        }
    } else if (week == 5) {  // teenth
        day = 13 + offset;
    } else {
        day = offset + 1 + (week - 1) * 7;
    }

    std::tm result{};
    result.tm_year = year_ - 1900;
    result.tm_mon = static_cast<int>(month_) - 1;
    result.tm_mday = day;
    result.tm_hour = 12;
    result.tm_min = 0;
    result.tm_sec = 0;
    result.tm_isdst = -1;
    return result;
}

std::tm scheduler::monteenth() {
    return compute(day_of_week::Monday, 5);  // teenth = 13-19, use week 5 to find teenth
}

std::tm scheduler::tuesteenth() {
    return compute(day_of_week::Tuesday, 5);
}

std::tm scheduler::wednesteenth() {
    return compute(day_of_week::Wednesday, 5);
}

std::tm scheduler::thursteenth() {
    return compute(day_of_week::Thursday, 5);
}

std::tm scheduler::friteenth() {
    return compute(day_of_week::Friday, 5);
}

std::tm scheduler::saturteenth() {
    return compute(day_of_week::Saturday, 5);
}

std::tm scheduler::sunteenth() {
    return compute(day_of_week::Sunday, 5);
}

std::tm scheduler::first_monday() {
    return compute(day_of_week::Monday, 1);
}

std::tm scheduler::first_tuesday() {
    return compute(day_of_week::Tuesday, 1);
}

std::tm scheduler::first_wednesday() {
    return compute(day_of_week::Wednesday, 1);
}

std::tm scheduler::first_thursday() {
    return compute(day_of_week::Thursday, 1);
}

std::tm scheduler::first_friday() {
    return compute(day_of_week::Friday, 1);
}

std::tm scheduler::first_saturday() {
    return compute(day_of_week::Saturday, 1);
}

std::tm scheduler::first_sunday() {
    return compute(day_of_week::Sunday, 1);
}

std::tm scheduler::second_monday() {
    return compute(day_of_week::Monday, 2);
}

std::tm scheduler::second_tuesday() {
    return compute(day_of_week::Tuesday, 2);
}

std::tm scheduler::second_wednesday() {
    return compute(day_of_week::Wednesday, 2);
}

std::tm scheduler::second_thursday() {
    return compute(day_of_week::Thursday, 2);
}

std::tm scheduler::second_friday() {
    return compute(day_of_week::Friday, 2);
}

std::tm scheduler::second_saturday() {
    return compute(day_of_week::Saturday, 2);
}

std::tm scheduler::second_sunday() {
    return compute(day_of_week::Sunday, 2);
}

std::tm scheduler::third_monday() {
    return compute(day_of_week::Monday, 3);
}

std::tm scheduler::third_tuesday() {
    return compute(day_of_week::Tuesday, 3);
}

std::tm scheduler::third_wednesday() {
    return compute(day_of_week::Wednesday, 3);
}

std::tm scheduler::third_thursday() {
    return compute(day_of_week::Thursday, 3);
}

std::tm scheduler::third_friday() {
    return compute(day_of_week::Friday, 3);
}

std::tm scheduler::third_saturday() {
    return compute(day_of_week::Saturday, 3);
}

std::tm scheduler::third_sunday() {
    return compute(day_of_week::Sunday, 3);
}

std::tm scheduler::fourth_monday() {
    return compute(day_of_week::Monday, 4);
}

std::tm scheduler::fourth_tuesday() {
    return compute(day_of_week::Tuesday, 4);
}

std::tm scheduler::fourth_wednesday() {
    return compute(day_of_week::Wednesday, 4);
}

std::tm scheduler::fourth_thursday() {
    return compute(day_of_week::Thursday, 4);
}

std::tm scheduler::fourth_friday() {
    return compute(day_of_week::Friday, 4);
}

std::tm scheduler::fourth_saturday() {
    return compute(day_of_week::Saturday, 4);
}

std::tm scheduler::fourth_sunday() {
    return compute(day_of_week::Sunday, 4);
}

std::tm scheduler::last_monday() {
    return compute(day_of_week::Monday, 0);
}

std::tm scheduler::last_tuesday() {
    return compute(day_of_week::Tuesday, 0);
}

std::tm scheduler::last_wednesday() {
    return compute(day_of_week::Wednesday, 0);
}

std::tm scheduler::last_thursday() {
    return compute(day_of_week::Thursday, 0);
}

std::tm scheduler::last_friday() {
    return compute(day_of_week::Friday, 0);
}

std::tm scheduler::last_saturday() {
    return compute(day_of_week::Saturday, 0);
}

std::tm scheduler::last_sunday() {
    return compute(day_of_week::Sunday, 0);
}

}  // namespace meetup

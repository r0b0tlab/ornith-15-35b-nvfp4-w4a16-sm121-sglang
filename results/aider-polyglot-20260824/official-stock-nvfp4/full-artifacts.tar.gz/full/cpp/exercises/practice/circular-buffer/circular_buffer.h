#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <vector>
#include <stdexcept>
#include <cstddef>

namespace circular_buffer {

template <typename T>
class circular_buffer {
public:
    explicit circular_buffer(std::size_t capacity);
    ~circular_buffer() = default;

    void write(T value);
    T read();
    void clear();
    void overwrite(T value);

private:
    std::vector<T> buffer_;
    std::size_t head_;      // Index of the oldest element
    std::size_t count_;     // Number of elements currently in the buffer
    std::size_t capacity_;  // Maximum number of elements the buffer can hold
};

template <typename T>
circular_buffer<T>::circular_buffer(std::size_t capacity)
    : buffer_(capacity), head_(0), count_(0), capacity_(capacity) {
}

template <typename T>
void circular_buffer<T>::write(T value) {
    if (count_ == capacity_) {
        throw std::out_of_range("Buffer is full");
    }

    std::size_t write_pos = (head_ + count_) % capacity_;
    buffer_[write_pos] = value;
    count_++;
}

template <typename T>
void circular_buffer<T>::overwrite(T value) {
    if (count_ == capacity_) {
        buffer_[head_] = value;
        head_ = (head_ + 1) % capacity_;
    } else {
        write(value);
    }
}

template <typename T>
T circular_buffer<T>::read() {
    if (count_ == 0) {
        throw std::out_of_range("Buffer is empty");
    }

    T value = buffer_[head_];
    head_ = (head_ + 1) % capacity_;
    count_--;
    return value;
}

template <typename T>
void circular_buffer<T>::clear() {
    head_ = 0;
    count_ = 0;
}

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H

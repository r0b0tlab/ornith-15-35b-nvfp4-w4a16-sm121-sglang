#include "grade_school.h"
#include <algorithm>

namespace grade_school {

void school::add(const std::string& name, int grade) {
    // Check if student already exists in any grade
    for (const auto& entry : roster_) {
        for (const auto& student : entry.second) {
            if (student == name) {
                return; // Student already exists, don't add again
            }
        }
    }
    
    // Add student to the grade
    roster_[grade].push_back(name);
    // Sort students within the grade alphabetically
    std::sort(roster_[grade].begin(), roster_[grade].end());
}

std::vector<std::string> school::grade(int grade) const {
    auto it = roster_.find(grade);
    if (it != roster_.end()) {
        return it->second;
    }
    return {};
}

std::map<int, std::vector<std::string>> school::roster() const {
    return roster_;
}

}  // namespace grade_school

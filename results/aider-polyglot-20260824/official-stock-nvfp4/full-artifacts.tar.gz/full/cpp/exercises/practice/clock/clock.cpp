#include "clock.h"
#include <ctime>
#include <stdexcept>

namespace date_independent {

clock::clock(int total_minutes) : total_minutes_(total_minutes) {}

clock clock::at(int hours, int minutes) {
    int total = ((hours * 60 + minutes) % 1440 + 1440) % 1440;
    return clock(total);
}

clock clock::plus(int minutes) const {
    int total = ((total_minutes_ + minutes) % 1440 + 1440) % 1440;
    return clock(total);
}

clock clock::minus(int minutes) const {
    int total = ((total_minutes_ - minutes) % 1440 + 1440) % 1440;
    return clock(total);
}

clock clock::operator+(int minutes) const {
    return plus(minutes);
}

clock clock::operator-(int minutes) const {
    return minus(minutes);
}

std::string clock::to_string() const {
    int hours = total_minutes_ / 60;
    int minutes = total_minutes_ % 60;

    char buffer[6];
    snprintf(buffer, sizeof(buffer), "%02d:%02d", hours, minutes);
    return std::string(buffer);
}

bool clock::operator==(const clock& other) const {
    return total_minutes_ == other.total_minutes_;
}

bool clock::operator!=(const clock& other) const {
    return !(*this == other);
}

}  // namespace date_independent

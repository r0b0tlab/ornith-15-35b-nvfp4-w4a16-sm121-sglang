#if !defined(MEETUP_H)
#define MEETUP_H

#include <ctime>

namespace meetup {

enum class month {
    January = 1,
    February = 2,
    March = 3,
    April = 4,
    May = 5,
    June = 6,
    July = 7,
    August = 8,
    September = 9,
    October = 10,
    November = 11,
    December = 12
};

enum class day_of_week {
    Sunday = 0,
    Monday = 1,
    Tuesday = 2,
    Wednesday = 3,
    Thursday = 4,
    Friday = 5,
    Saturday = 6
};

class scheduler {
public:
    scheduler(month m, int year);
    std::tm monteenth();
    std::tm tuesteenth();
    std::tm wednesteenth();
    std::tm thursteenth();
    std::tm friteenth();
    std::tm saturteenth();
    std::tm sunteenth();
    std::tm first_monday();
    std::tm first_tuesday();
    std::tm first_wednesday();
    std::tm first_thursday();
    std::tm first_friday();
    std::tm first_saturday();
    std::tm first_sunday();
    std::tm second_monday();
    std::tm second_tuesday();
    std::tm second_wednesday();
    std::tm second_thursday();
    std::tm second_friday();
    std::tm second_saturday();
    std::tm second_sunday();
    std::tm third_monday();
    std::tm third_tuesday();
    std::tm third_wednesday();
    std::tm third_thursday();
    std::tm third_friday();
    std::tm third_saturday();
    std::tm third_sunday();
    std::tm fourth_monday();
    std::tm fourth_tuesday();
    std::tm fourth_wednesday();
    std::tm fourth_thursday();
    std::tm fourth_friday();
    std::tm fourth_saturday();
    std::tm fourth_sunday();
    std::tm last_monday();
    std::tm last_tuesday();
    std::tm last_wednesday();
    std::tm last_thursday();
    std::tm last_friday();
    std::tm last_saturday();
    std::tm last_sunday();

private:
    month month_;
    int year_;
    int days_in_month_;
    int first_weekday_;
    int weekday_to_int(day_of_week dow) const;
    std::tm compute(day_of_week dow, int week);
};

}  // namespace meetup

#endif // MEETUP_H

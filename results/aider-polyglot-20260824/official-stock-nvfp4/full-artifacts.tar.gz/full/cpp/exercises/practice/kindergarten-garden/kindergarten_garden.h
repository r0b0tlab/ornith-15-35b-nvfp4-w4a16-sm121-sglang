#pragma once

#include <string>
#include <vector>
#include <map>

namespace kindergarten_garden {

enum class Plants {
    Grass,
    Clover,
    Radish,
    Violet
};

std::string to_string(Plants plant);

std::vector<Plants> plants(const std::string& diagram, const std::string& child);

std::vector<Plants> plants(const std::string& diagram, const std::vector<std::string>& students);

}  // namespace kindergarten_garden

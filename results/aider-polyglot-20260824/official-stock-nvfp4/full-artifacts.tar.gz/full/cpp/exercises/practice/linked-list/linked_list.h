#pragma once

#include <stdexcept>

namespace linked_list {

template <typename T>
class List {
public:
    // Node structure for the doubly linked list
    struct Node {
        T data;
        Node* prev;
        Node* next;
        Node(T value) : data(value), prev(nullptr), next(nullptr) {}
    };

    List() : head_(nullptr), tail_(nullptr), count_(0) {}

    ~List() {
        Node* current = head_;
        while (current != nullptr) {
            Node* next = current->next;
            delete current;
            current = next;
        }
    }

    // Adds an element to the end of the list
    void push(const T& value) {
        Node* newNode = new Node(value);
        if (tail_ == nullptr) {
            head_ = tail_ = newNode;
        } else {
            newNode->prev = tail_;
            tail_->next = newNode;
            tail_ = newNode;
        }
        count_++;
    }

    // Removes and returns the last element of the list
    T pop() {
        if (tail_ == nullptr) {
            throw std::out_of_range("List is empty");
        }
        Node* nodeToPop = tail_;
        T value = nodeToPop->data;
        
        if (head_ == tail_) {
            // Only one element
            head_ = tail_ = nullptr;
        } else {
            tail_ = nodeToPop->prev;
            tail_->next = nullptr;
            nodeToPop->prev = nullptr;
        }
        delete nodeToPop;
        count_--;
        return value;
    }

    // Removes and returns the first element of the list
    T shift() {
        if (head_ == nullptr) {
            throw std::out_of_range("List is empty");
        }
        Node* nodeToShift = head_;
        T value = nodeToShift->data;
        
        if (head_ == tail_) {
            // Only one element
            head_ = tail_ = nullptr;
        } else {
            head_ = nodeToShift->next;
            head_->prev = nullptr;
            nodeToShift->next = nullptr;
        }
        delete nodeToShift;
        count_--;
        return value;
    }

    // Adds an element to the start of the list
    void unshift(const T& value) {
        Node* newNode = new Node(value);
        if (head_ == nullptr) {
            head_ = tail_ = newNode;
        } else {
            newNode->next = head_;
            head_->prev = newNode;
            head_ = newNode;
        }
        count_++;
    }

    // Returns the total number of elements in the list
    long count() const {
        return count_;
    }

    // Removes the first occurrence of the value from the list
    // Returns true if an element was deleted, false otherwise
    bool erase(const T& value) {
        Node* current = head_;
        while (current != nullptr) {
            if (current->data == value) {
                // Found the node to erase
                if (current->prev != nullptr) {
                    current->prev->next = current->next;
                } else {
                    // It's the head
                    head_ = current->next;
                }
                
                if (current->next != nullptr) {
                    current->next->prev = current->prev;
                } else {
                    // It's the tail
                    tail_ = current->prev;
                }
                
                delete current;
                count_--;
                return true;
            }
            current = current->next;
        }
        return false;
    }

private:
    Node* head_;
    Node* tail_;
    long count_;
};

}  // namespace linked_list

#include "dnd_character.h"
#include <algorithm>
#include <array>
#include <random>

namespace dnd_character {

int modifier(int score) {
    return (score - 10) / 2;
}

int ability() {
    static std::random_device rd;
    static std::mt19937 engine(rd());
    static std::uniform_int_distribution<int> distribution(1, 6);

    std::array<int, 4> rolls;
    for (int i = 0; i < 4; ++i) {
        rolls[i] = distribution(engine);
    }

    std::sort(rolls.begin(), rolls.end());

    return rolls[1] + rolls[2] + rolls[3];
}

Character create_character() {
    Character character;
    character.strength = ability();
    character.dexterity = ability();
    character.constitution = ability();
    character.intelligence = ability();
    character.wisdom = ability();
    character.charisma = ability();
    character.hitpoints = 10 + modifier(character.constitution);
    return character;
}

}  // namespace dnd_character

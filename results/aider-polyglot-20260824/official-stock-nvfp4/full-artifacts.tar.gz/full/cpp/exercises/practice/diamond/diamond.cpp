#include "diamond.h"

namespace diamond {

std::vector<std::string> rows(char letter) {
    int n = letter - 'A';  // 0 for 'A', 1 for 'B', etc.
    int size = 2 * n + 1;  // Total size of the diamond
    std::vector<std::string> result;
    
    for (int i = 0; i < size; i++) {
        int current_row = (i <= n) ? i : (2 * n - i);
        char current_char = 'A' + current_row;
        std::string row_str(size, ' ');
        
        // Place the two characters (or one for the first/last row)
        row_str[n - current_row] = current_char;
        row_str[n + current_row] = current_char;
        
        result.push_back(row_str);
    }
    
    return result;
}

}  // namespace diamond

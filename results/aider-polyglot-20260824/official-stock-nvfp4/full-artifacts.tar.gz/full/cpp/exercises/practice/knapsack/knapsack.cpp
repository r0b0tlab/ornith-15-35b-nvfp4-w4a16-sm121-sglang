#include "knapsack.h"

namespace knapsack
{

int maximum_value(int maximum_weight, const std::vector<Item> &items)
{
    // dp[w] will hold the maximum value achievable with weight limit w
    std::vector<int> dp(maximum_weight + 1, 0);

    for (const Item &item : items)
    {
        // Iterate from high to low weight to ensure each item is used at most once
        for (int w = maximum_weight; w >= item.weight; w--)
        {
            dp[w] = std::max(dp[w], dp[w - item.weight] + item.value);
        }
    }

    return dp[maximum_weight];
}

} // namespace knapsack

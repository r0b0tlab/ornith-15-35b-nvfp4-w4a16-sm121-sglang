#include "spiral_matrix.h"

namespace spiral_matrix {

std::vector<std::vector<unsigned int>> spiral_matrix(int size) {
    std::vector<std::vector<unsigned int>> matrix(size, std::vector<unsigned int>(size, 0));
    
    if (size == 0) {
        return matrix;
    }
    
    int top = 0;
    int bottom = size - 1;
    int left = 0;
    int right = size - 1;
    unsigned int num = 1;
    
    while (top <= bottom && left <= right) {
        // Traverse right
        for (int i = left; i <= right; ++i) {
            matrix[top][i] = num++;
        }
        top++;
        
        // Traverse down
        for (int i = top; i <= bottom; ++i) {
            matrix[i][right] = num++;
        }
        right--;
        
        // Traverse left
        if (top <= bottom) {
            for (int i = right; i >= left; --i) {
                matrix[bottom][i] = num++;
            }
            bottom--;
        }
        
        // Traverse up
        if (left <= right) {
            for (int i = bottom; i >= top; --i) {
                matrix[i][left] = num++;
            }
            left++;
        }
    }
    
    return matrix;
}

}  // namespace spiral_matrix

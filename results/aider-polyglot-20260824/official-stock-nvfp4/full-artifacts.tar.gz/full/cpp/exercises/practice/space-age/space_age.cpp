#include "space_age.h"

namespace space_age {

namespace {
    const double EARTH_YEAR_SECONDS = 31557600.0;
}

space_age::space_age(std::uint64_t seconds)
    : seconds_(seconds) {}

std::uint64_t space_age::seconds() const {
    return seconds_;
}

double space_age::age() const {
    return seconds_ / EARTH_YEAR_SECONDS;
}

double space_age::on_earth() const {
    return age();
}

double space_age::on_mercury() const {
    return age() / 0.2408467;
}

double space_age::on_venus() const {
    return age() / 0.61519726;
}

double space_age::on_mars() const {
    return age() / 1.8808158;
}

double space_age::on_jupiter() const {
    return age() / 11.862615;
}

double space_age::on_saturn() const {
    return age() / 29.447498;
}

double space_age::on_uranus() const {
    return age() / 84.016846;
}

double space_age::on_neptune() const {
    return age() / 164.79132;
}

}  // namespace space_age

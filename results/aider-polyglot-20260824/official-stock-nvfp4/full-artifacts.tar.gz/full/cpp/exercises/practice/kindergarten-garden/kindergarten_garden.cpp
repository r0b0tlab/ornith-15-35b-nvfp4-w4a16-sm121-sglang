#include "kindergarten_garden.h"
#include <map>
#include <vector>
#include <string>

namespace kindergarten_garden {

static Plants plant_from_char(char c) {
    switch (c) {
        case 'G': return Plants::Grass;
        case 'C': return Plants::Clover;
        case 'R': return Plants::Radish;
        case 'V': return Plants::Violet;
        default: return Plants::Grass;  // Default to grass for unknown characters
    }
}

std::string to_string(Plants plant) {
    switch (plant) {
        case Plants::Grass: return "grass";
        case Plants::Clover: return "clover";
        case Plants::Radish: return "radishes";
        case Plants::Violet: return "violets";
        default: return "grass";
    }
}

std::vector<Plants> plants(const std::string& diagram, const std::string& child) {
    // Default list of students in alphabetical order
    static const std::vector<std::string> default_students = {
        "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
        "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"
    };
    
    // Find the child's index alphabetically
    size_t child_index = 0;
    for (size_t i = 0; i < default_students.size(); ++i) {
        if (default_students[i] == child) {
            child_index = i;
            break;
        }
    }
    
    // Split the diagram into two rows
    std::string row1, row2;
    size_t newline_pos = diagram.find('\n');
    if (newline_pos != std::string::npos) {
        row1 = diagram.substr(0, newline_pos);
        row2 = diagram.substr(newline_pos + 1);
    }
    
    // Each child gets 2 cups per row, starting at position child_index * 2
    size_t start_pos = child_index * 2;
    
    std::vector<Plants> child_plants;
    // First row: two cups
    child_plants.push_back(plant_from_char(row1[start_pos]));
    child_plants.push_back(plant_from_char(row1[start_pos + 1]));
    // Second row: two cups
    child_plants.push_back(plant_from_char(row2[start_pos]));
    child_plants.push_back(plant_from_char(row2[start_pos + 1]));
    
    return child_plants;
}

std::vector<Plants> plants(const std::string& diagram, const std::vector<std::string>& students) {
    std::vector<Plants> result;
    for (const auto& child : students) {
        auto child_plants = plants(diagram, child);
        result.insert(result.end(), child_plants.begin(), child_plants.end());
    }
    return result;
}

}  // namespace kindergarten_garden

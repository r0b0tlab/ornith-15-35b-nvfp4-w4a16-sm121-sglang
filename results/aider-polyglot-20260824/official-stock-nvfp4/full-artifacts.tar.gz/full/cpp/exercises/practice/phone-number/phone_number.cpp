#include "phone_number.h"
#include <stdexcept>
#include <cctype>

namespace phone_number {

phone_number::phone_number(const std::string& input) {
    // Extract only digits from input
    std::string digits;
    for (char c : input) {
        if (std::isdigit(static_cast<unsigned char>(c))) {
            digits += c;
        }
    }

    // Handle country code
    if (digits.size() == 11 && digits[0] == '1') {
        digits = digits.substr(1);
    }

    // Validate length
    if (digits.size() != 10) {
        throw std::invalid_argument("Invalid number length");
    }

    // Validate area code and exchange code
    if (digits[0] == '0' || digits[0] == '1') {
        throw std::invalid_argument("Invalid area code");
    }
    if (digits[3] == '0' || digits[3] == '1') {
        throw std::invalid_argument("Invalid exchange code");
    }

    number_ = digits;
}

std::string phone_number::number() const {
    return number_;
}

}  // namespace phone_number

#if !defined(ROBOT_NAME_H)
#define ROBOT_NAME_H

#include <string>

namespace robot_name {

class Robot {
public:
    Robot();
    ~Robot();

    std::string name() const;
    void reset();

private:
    mutable std::string name_;
    bool has_name_;
};

using robot = Robot;

}  // namespace robot_name

#endif // ROBOT_NAME_H

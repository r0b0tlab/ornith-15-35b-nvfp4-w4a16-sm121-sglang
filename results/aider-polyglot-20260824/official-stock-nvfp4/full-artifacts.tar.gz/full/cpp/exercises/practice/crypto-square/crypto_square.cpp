#include "crypto_square.h"
#include <string>
#include <vector>
#include <cmath>
#include <cctype>

namespace crypto_square {

cipher::cipher(const std::string& plaintext) {
    // Normalize: remove spaces and punctuation, downcase
    for (char c : plaintext) {
        if (std::isalnum(static_cast<unsigned char>(c))) {
            normalized_text_ += std::tolower(static_cast<unsigned char>(c));
        }
    }
}

std::string cipher::normalized_cipher_text() const {
    int length = normalized_text_.length();
    if (length == 0) {
        return "";
    }
    
    // Determine rectangle dimensions
    int c = static_cast<int>(std::ceil(std::sqrt(length)));
    int r = static_cast<int>(std::ceil(length / static_cast<double>(c)));
    
    // Build the rectangle and read down columns
    std::string result;
    for (int col = 0; col < c; col++) {
        if (col > 0) {
            result += " ";
        }
        for (int row = 0; row < r; row++) {
            int index = row * c + col;
            if (index < length) {
                result += normalized_text_[index];
            } else {
                // Pad with space for incomplete chunks
                result += " ";
            }
        }
    }
    
    return result;
}

}  // namespace crypto_square

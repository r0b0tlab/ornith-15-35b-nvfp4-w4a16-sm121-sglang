#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <memory>
#include <vector>

namespace binary_search_tree {

template <typename T>
class binary_tree {
public:
    struct iterator {
        std::vector<const binary_tree*> nodes;
        size_t index = 0;

        const binary_tree* operator*() const { return nodes[index]; }
        iterator& operator++() { ++index; return *this; }
        bool operator!=(const iterator& other) const { return index != other.index; }
    };

    binary_tree() : data_(), left_(), right_() {}

    explicit binary_tree(T data)
        : data_(data), left_(), right_() {}

    void insert(const T &value) {
        if (value <= data_) {
            if (!left_) {
                left_ = std::make_shared<binary_tree>(value);
            } else {
                left_->insert(value);
            }
        } else {
            if (!right_) {
                right_ = std::make_shared<binary_tree>(value);
            } else {
                right_->insert(value);
            }
        }
    }

    T data() const {
        return data_;
    }

    const binary_tree *left() const {
        return left_.get();
    }

    const binary_tree *right() const {
        return right_.get();
    }

    iterator begin() const {
        iterator it;
        std::vector<const binary_tree*> nodes;
        collect_in_order(nodes);
        it.nodes = nodes;
        it.index = 0;
        return it;
    }

    iterator end() const {
        iterator it;
        std::vector<const binary_tree*> nodes;
        collect_in_order(nodes);
        it.nodes = nodes;
        it.index = nodes.size();
        return it;
    }

private:
    T data_;
    std::shared_ptr<binary_tree> left_;
    std::shared_ptr<binary_tree> right_;

    void collect_in_order(std::vector<const binary_tree*>& nodes) const {
        if (left_) {
            left_->collect_in_order(nodes);
        }
        nodes.push_back(this);
        if (right_) {
            right_->collect_in_order(nodes);
        }
    }
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H

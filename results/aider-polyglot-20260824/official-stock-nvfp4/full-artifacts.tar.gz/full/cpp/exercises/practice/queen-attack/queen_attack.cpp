#include "queen_attack.h"
#include <stdexcept>
#include <cmath>

namespace queen_attack {

chess_board::chess_board(std::pair<int, int> white, std::pair<int, int> black)
    : white_(white), black_(black) {
    if (white.first < 0 || white.first >= 8 || white.second < 0 || white.second >= 8) {
        throw std::domain_error("White queen must be on the chessboard");
    }
    if (black.first < 0 || black.first >= 8 || black.second < 0 || black.second >= 8) {
        throw std::domain_error("Black queen must be on the chessboard");
    }
}

std::pair<int, int> chess_board::white() const {
    return white_;
}

std::pair<int, int> chess_board::black() const {
    return black_;
}

bool chess_board::can_attack() const {
    // Same row
    if (white_.first == black_.first) {
        return true;
    }
    
    // Same column
    if (white_.second == black_.second) {
        return true;
    }
    
    // Same diagonal
    if (std::abs(white_.first - black_.first) == std::abs(white_.second - black_.second)) {
        return true;
    }
    
    return false;
}

}  // namespace queen_attack

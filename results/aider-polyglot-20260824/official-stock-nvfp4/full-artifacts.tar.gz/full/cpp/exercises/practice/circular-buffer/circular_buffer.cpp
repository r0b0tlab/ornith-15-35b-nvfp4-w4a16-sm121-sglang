#include "circular_buffer.h"

namespace circular_buffer {

// All template implementations are in the header file.
// This file is kept for potential non-template helper functions.

}  // namespace circular_buffer

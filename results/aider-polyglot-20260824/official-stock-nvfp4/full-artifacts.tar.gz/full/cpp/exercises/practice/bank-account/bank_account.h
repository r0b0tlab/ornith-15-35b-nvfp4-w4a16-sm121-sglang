#if !defined(BANK_ACCOUNT_H)
#define BANK_ACCOUNT_H

#include <mutex>

namespace Bankaccount {
class Bankaccount {
public:
    Bankaccount();
    ~Bankaccount();

    void open();
    void close();
    void deposit(long long amount);
    void withdraw(long long amount);
    long long balance() const;

private:
    bool is_open_;
    long long balance_;
    mutable std::mutex mutex_;
};  // class Bankaccount

}  // namespace Bankaccount

#endif  // BANK_ACCOUNT_H

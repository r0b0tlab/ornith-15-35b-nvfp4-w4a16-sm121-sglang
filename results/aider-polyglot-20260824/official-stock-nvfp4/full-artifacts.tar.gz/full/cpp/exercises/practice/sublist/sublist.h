#pragma once

#include <vector>

namespace sublist {

enum class list_type {
    sublist,
    equal,
    superlist,
    unequal
};

list_type compare(std::vector<int> const& list1, std::vector<int> const& list2);

}  // namespace sublist

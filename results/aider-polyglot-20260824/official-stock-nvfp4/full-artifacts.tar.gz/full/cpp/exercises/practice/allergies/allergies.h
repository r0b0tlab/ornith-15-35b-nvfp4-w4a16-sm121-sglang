#if !defined(ALLERGIES_H)
#define ALLERGIES_H

#include <string>
#include <unordered_set>

namespace allergies {

class allergies_test {
public:
    allergies_test(unsigned score);
    bool is_allergic_to(const std::string& allergen);
    std::unordered_set<std::string> get_allergies();

private:
    unsigned score_;
};

}  // namespace allergies

#endif // ALLERGIES_H

#include "zebra_puzzle.h"
#include <array>
#include <algorithm>
#include <cmath>

namespace zebra_puzzle {

// Define the possible values for each category
static const std::array<std::string, 5> colors = {"red", "green", "ivory", "yellow", "blue"};
static const std::array<std::string, 5> nationalities = {"Englishman", "Spaniard", "Ukrainian", "Norwegian", "Japanese"};
static const std::array<std::string, 5> beverages = {"coffee", "tea", "milk", "orangeJuice", "water"};
static const std::array<std::string, 5> hobbies = {"dancing", "painter", "reading", "football", "chess"};
static const std::array<std::string, 5> pets = {"dog", "fox", "horse", "snail", "zebra"};

Solution solve() {
    // Try all permutations of colors
    std::array<int, 5> color_idx = {0, 1, 2, 3, 4};
    do {
        // Constraint 6: green house is immediately to the right of ivory house
        int ivory_pos = -1, green_pos = -1;
        for (int i = 0; i < 5; i++) {
            if (colors[color_idx[i]] == "ivory") ivory_pos = i;
            if (colors[color_idx[i]] == "green") green_pos = i;
        }
        if (green_pos != ivory_pos + 1) continue;
        
        // Constraint 15: Norwegian lives next to blue house
        // Constraint 10: Norwegian lives in first house
        // Since Norwegian is in house 0, blue must be in house 1
        if (colors[color_idx[1]] != "blue") continue;
        
        // Try all permutations of nationalities
        std::array<int, 5> nat_idx = {0, 1, 2, 3, 4};
        do {
            // Constraint 10: Norwegian lives in first house
            if (nationalities[nat_idx[0]] != "Norwegian") continue;
            
            // Constraint 2: Englishman lives in red house
            int englishman_pos = -1;
            for (int i = 0; i < 5; i++) {
                if (nationalities[nat_idx[i]] == "Englishman") {
                    englishman_pos = i;
                    break;
                }
            }
            if (englishman_pos == -1 || colors[color_idx[englishman_pos]] != "red") continue;
            
            // Try all permutations of beverages
            std::array<int, 5> bev_idx = {0, 1, 2, 3, 4};
            do {
                // Constraint 9: middle house drinks milk
                if (bev_idx[2] != 2) continue; // milk is index 2
                
                // Constraint 4: green house drinks coffee
                if (beverages[bev_idx[green_pos]] != "coffee") continue;
                
                // Constraint 5: Ukrainian drinks tea
                int ukrainian_pos = -1;
                for (int i = 0; i < 5; i++) {
                    if (nationalities[nat_idx[i]] == "Ukrainian") {
                        ukrainian_pos = i;
                        break;
                    }
                }
                if (ukrainian_pos != -1 && beverages[bev_idx[ukrainian_pos]] != "tea") continue; // tea is index 1
                
                // Try all permutations of hobbies
                std::array<int, 5> hobby_idx = {0, 1, 2, 3, 4};
                do {
                    // Constraint 14: Japanese plays chess
                    int japanese_pos = -1;
                    for (int i = 0; i < 5; i++) {
                        if (nationalities[nat_idx[i]] == "Japanese") {
                            japanese_pos = i;
                            break;
                        }
                    }
                    if (japanese_pos != -1 && hobby_idx[japanese_pos] != 4) continue; // chess is index 4
                    
                    // Constraint 13: football player drinks orange juice
                    bool footballValid = true;
                    for (int i = 0; i < 5; i++) {
                        if (hobby_idx[i] == 3 && beverages[bev_idx[i]] != "orangeJuice") {
                            footballValid = false;
                            break;
                        }
                    }
                    if (!footballValid) continue; // football is index 3
                    
                    // Constraint 8: yellow house is painter
                    bool yellowValid = true;
                    for (int i = 0; i < 5; i++) {
                        if (colors[color_idx[i]] == "yellow" && hobby_idx[i] != 1) {
                            yellowValid = false;
                            break;
                        }
                    }
                    if (!yellowValid) continue; // painter is index 1
                    
                    // Try all permutations of pets
                    std::array<int, 5> pet_idx = {0, 1, 2, 3, 4};
                    do {
                        // Constraint 3: Spaniard owns dog
                        int spaniard_pos = -1;
                        for (int i = 0; i < 5; i++) {
                            if (nationalities[nat_idx[i]] == "Spaniard") {
                                spaniard_pos = i;
                                break;
                            }
                        }
                        if (spaniard_pos != -1 && pet_idx[spaniard_pos] != 0) continue; // dog is index 0
                        
                        // Constraint 7: snail owner dances
                        bool snailValid = true;
                        for (int i = 0; i < 5; i++) {
                            if (pets[pet_idx[i]] == "snail" && hobby_idx[i] != 0) {
                                snailValid = false;
                                break;
                            }
                        }
                        if (!snailValid) continue; // snail is index 0, dancing is index 0
                        
                        // Constraint 11: reader next to fox owner
                        int reader_pos = -1, fox_pos = -1;
                        for (int i = 0; i < 5; i++) {
                            if (hobby_idx[i] == 2) reader_pos = i; // reading is index 2
                            if (pets[pet_idx[i]] == "fox") fox_pos = i; // fox is index 1
                        }
                        if (abs(reader_pos - fox_pos) != 1) continue;
                        
                        // Constraint 12: painter's house next to horse
                        int painter_pos = -1, horse_pos = -1;
                        for (int i = 0; i < 5; i++) {
                            if (hobby_idx[i] == 1) painter_pos = i; // painter is index 1
                            if (pets[pet_idx[i]] == "horse") horse_pos = i; // horse is index 2
                        }
                        if (abs(painter_pos - horse_pos) != 1) continue;
                        
                        // All constraints satisfied! Build solution.
                        Solution sol;
                        // Find who drinks water
                        for (int i = 0; i < 5; i++) {
                            if (bev_idx[i] == 4) { // water is index 4
                                sol.drinksWater = nationalities[nat_idx[i]];
                            }
                            if (pet_idx[i] == 4) { // zebra is index 4
                                sol.ownsZebra = nationalities[nat_idx[i]];
                            }
                        }
                        return sol;
                    } while (std::next_permutation(pet_idx.begin(), pet_idx.end()));
                } while (std::next_permutation(hobby_idx.begin(), hobby_idx.end()));
            } while (std::next_permutation(bev_idx.begin(), bev_idx.end()));
        } while (std::next_permutation(nat_idx.begin(), nat_idx.end()));
    } while (std::next_permutation(color_idx.begin(), color_idx.end()));
    
    return Solution{};
}

}  // namespace zebra_puzzle

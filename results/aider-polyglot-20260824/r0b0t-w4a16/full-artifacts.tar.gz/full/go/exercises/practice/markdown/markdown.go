package markdown

import (
	"fmt"
	"strings"
)

// Render translates markdown to HTML.
//
// Refactored from an original single-loop implementation into a clear,
// line-based parser. The behaviour is preserved line-by-line:
//
//   - Headers: lines beginning with 1-7 '#' characters become <h1>..<h7>.
//   - Lists: lines beginning with '* ' become <li> items inside a <ul>.
//   - Emphasis: '_' becomes <em>...</em>, '__' becomes <strong>...</strong>.
//   - Everything else is wrapped in a <p> paragraph.
//
// The parser processes the input one line at a time, which is far easier to
// follow than the original character-by-character scan with its many index
// manipulations and state flags.
func Render(markdown string) string {
	lines := strings.Split(markdown, "\n")

	var sb strings.Builder
	listOpen := false

	closeList := func() {
		if listOpen {
			sb.WriteString("</li></ul>")
			listOpen = false
		}
	}

	for _, line := range lines {
		switch {
		case isHeader(line):
			closeList()
			writeHeader(&sb, line)

		case isListItem(line):
			if !listOpen {
				sb.WriteString("<ul>")
				listOpen = true
			}
			writeListItem(&sb, line)

		default:
			closeList()
			writeParagraph(&sb, line)
		}
	}

	closeList()

	return sb.String()
}

// isHeader reports whether the line is a markdown header (starts with 1-7 '#').
func isHeader(line string) bool {
	count := 0
	for i := 0; i < len(line) && line[i] == '#'; i++ {
		count++
	}
	return count > 0 && count <= 7
}

// writeHeader renders a header line as an <hN> element.
func writeHeader(sb *strings.Builder, line string) {
	level := 0
	for level < len(line) && line[level] == '#' {
		level++
	}
	fmt.Fprintf(sb, "<h%d>%s</h%d>", level, strings.TrimLeft(line[level:], " "), level)
}

// isListItem reports whether the line is a markdown list item (starts with '* ').
func isListItem(line string) bool {
	return strings.HasPrefix(line, "* ")
}

// writeListItem renders a list item as an <li> element.
func writeListItem(sb *strings.Builder, line string) {
	fmt.Fprintf(sb, "<li>%s</li>", listItemContent(line))
}

// listItemContent strips the leading '* ' marker from a list item line.
func listItemContent(line string) string {
	return strings.TrimPrefix(line, "* ")
}

// writeParagraph renders a line as a <p> paragraph, applying inline emphasis.
func writeParagraph(sb *strings.Builder, line string) {
	fmt.Fprintf(sb, "<p>%s</p>", inlineFormat(line))
}

// inlineFormat applies markdown inline emphasis formatting to a line.
//
// Double underscores denote bold and single underscores denote italic.
func inlineFormat(line string) string {
	line = strings.Replace(line, "__", "<strong>", -1)
	line = strings.Replace(line, "__", "</strong>", -1)
	line = strings.Replace(line, "_", "<em>", -1)
	line = strings.Replace(line, "_", "</em>", -1)
	return line
}

package bookstore

const basePrice = 800 // cents

// Cost calculates the minimum price for a basket of books.
func Cost(books []int) int {
	// Count copies of each book (indices 1..5).
	counts := make([]int, 6)
	for _, b := range books {
		counts[b]++
	}

	// discount[i] is the discount percentage for a set of i different books.
	discounts := []int{0, 0, 5, 10, 20, 25}

	// setCost returns the cost of a set of size n.
	setCost := func(n int) int {
		return n * basePrice * (100 - discounts[n]) / 100
	}

	// Memoized recursive solver.
	memo := make(map[[6]int]int)

	var solve func(c [6]int) int
	solve = func(c [6]int) int {
		if v, ok := memo[c]; ok {
			return v
		}

		// Collect distinct book indices with count > 0.
		var distinct []int
		for i := 1; i <= 5; i++ {
			if c[i] > 0 {
				distinct = append(distinct, i)
			}
		}

		if len(distinct) == 0 {
			memo[c] = 0
			return 0
		}

		best := -1

		// Try every non-empty subset of distinct books as a set.
		n := len(distinct)
		for mask := 1; mask < (1 << n); mask++ {
			newC := c
			valid := true
			for j := 0; j < n; j++ {
				if mask&(1<<j) != 0 {
					if newC[distinct[j]] <= 0 {
						valid = false
						break
					}
					newC[distinct[j]]--
				}
			}
			if !valid {
				continue
			}
			size := 0
			for j := 0; j < n; j++ {
				if mask&(1<<j) != 0 {
					size++
				}
			}
			total := setCost(size) + solve(newC)
			if best == -1 || total < best {
				best = total
			}
		}

		memo[c] = best
		return best
	}

	return solve(counts)
}

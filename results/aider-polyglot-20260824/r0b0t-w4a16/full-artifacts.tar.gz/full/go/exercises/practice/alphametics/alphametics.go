package alphametics

import (
	"errors"
	"strings"
)

var ErrNoSolution = errors.New("no solution")

func Solve(puzzle string) (map[string]int, error) {
	// Split the puzzle into parts
	parts := strings.Split(puzzle, "==")
	if len(parts) != 2 {
		return nil, ErrNoSolution
	}

	left := parts[0]
	right := parts[1]

	// Split left side by '+'
	leftTerms := strings.Split(left, "+")
	allTerms := append(leftTerms, right)

	// Collect all unique letters
	var letters []rune
	seen := make(map[rune]bool)
	for _, term := range allTerms {
		for _, r := range term {
			if isLetter(r) {
				if !seen[r] {
					seen[r] = true
					letters = append(letters, r)
				}
			}
		}
	}

	// Collect leading letters (first letter of each term)
	leadingLetters := make(map[rune]bool)
	for _, term := range allTerms {
		term = strings.TrimSpace(term)
		for _, r := range term {
			if isLetter(r) {
				leadingLetters[r] = true
				break
			}
		}
	}

	// Try all permutations of digits for the letters
	digits := []int{0, 1, 2, 3, 4, 5, 6, 7, 8, 9}
	result, err := solve(letters, leadingLetters, digits, 0, allTerms)
	if err != nil {
		return nil, err
	}

	return result, nil
}

func isLetter(r rune) bool {
	return (r >= 'A' && r <= 'Z') || (r >= 'a' && r <= 'z')
}

func solve(letters []rune, leadingLetters map[rune]bool, digits []int, index int, terms []string) (map[string]int, error) {
	if index == len(letters) {
		// Check if this assignment is valid
		result := make(map[string]int)
		for i, letter := range letters {
			result[string(letter)] = digits[i]
		}

		// Verify no leading zeros
		for _, term := range terms {
			term = strings.TrimSpace(term)
			if len(term) > 0 && leadingLetters[term[0]] && result[string(term[0])] == 0 {
				return nil, nil
			}
		}

		// Check if the sum is valid
		if isValidSum(terms, result) {
			return result, nil
		}
		return nil, nil
	}

	for i := index; i < len(digits); i++ {
		// Check for duplicate digits
		duplicate := false
		for j := index; j < i; j++ {
			if digits[j] == digits[i] {
				duplicate = true
				break
			}
		}
		if duplicate {
			continue
		}

		// Swap
		digits[index], digits[i] = digits[i], digits[index]

		result, err := solve(letters, leadingLetters, digits, index+1, terms)
		if err == nil && result != nil {
			return result, nil
		}

		// Swap back
		digits[index], digits[i] = digits[i], digits[index]
	}

	return nil, ErrNoSolution
}

func isValidSum(terms []string, result map[string]int) bool {
	// Convert each term to its numeric value
	var total int
	for i, term := range terms {
		term = strings.TrimSpace(term)
		isRight := i == len(terms)-1
		value := termToValue(term, result)

		if isRight {
			continue
		}
		total += value
	}

	// Get the right side value
	rightSide := terms[len(terms)-1]
	rightValue := termToValue(rightSide, result)

	return total == rightValue
}

func termToValue(term string, result map[string]int) int {
	term = strings.TrimSpace(term)
	value := 0
	for _, r := range term {
		if isLetter(r) {
			value = value*10 + result[string(r)]
		}
	}
	return value
}

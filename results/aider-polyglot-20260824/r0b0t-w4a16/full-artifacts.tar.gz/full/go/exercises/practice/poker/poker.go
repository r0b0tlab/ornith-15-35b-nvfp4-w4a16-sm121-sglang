package poker

import (
	"fmt"
	"sort"
	"strings"
)

type HandType int

const (
	HighCard HandType = iota
	OnePair
	TwoPair
	ThreeOfKind
	Straight
	Flush
	FullHouse
	FourOfKind
	StraightFlush
)

type Card struct {
	Value int
	Suit  byte
}

var valueMap = map[string]int{
	"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
	"10": 10, "J": 11, "Q": 12, "K": 13, "A": 14,
}

func parseCard(card string) (Card, error) {
	runes := []rune(card)
	if len(runes) != 2 {
		return Card{}, fmt.Errorf("invalid card: %s", card)
	}

	suitRune := runes[1]
	if suitRune != '♤' && suitRune != '♢' && suitRune != '♡' && suitRune != '♧' {
		return Card{}, fmt.Errorf("invalid suit: %s", card)
	}

	val, ok := valueMap[string(runes[0])]
	if !ok {
		return Card{}, fmt.Errorf("invalid card value: %s", card)
	}

	return Card{Value: val, Suit: byte(suitRune)}, nil
}

func parseHand(hand string) ([]Card, error) {
	parts := strings.Fields(hand)
	if len(parts) != 5 {
		return nil, fmt.Errorf("hand must have exactly 5 cards: %s", hand)
	}

	cards := make([]Card, 5)
	for i, part := range parts {
		card, err := parseCard(part)
		if err != nil {
			return nil, err
		}
		cards[i] = card
	}

	return cards, nil
}

type RankedHand struct {
	Type      HandType
	TieBreakers []int
	Original  string
}

func classifyHand(cards []Card) RankedHand {
	values := make([]int, len(cards))
	for i, card := range cards {
		values[i] = card.Value
	}

	sorted := make([]int, len(values))
	copy(sorted, values)
	sort.Sort(sort.Reverse(sort.IntSlice(sorted)))

	isFlush := true
	for i := 1; i < len(cards); i++ {
		if cards[i].Suit != cards[0].Suit {
			isFlush = false
			break
		}
	}

	straightHigh := checkStraight(sorted)

	valueCounts := countValues(values)

	switch {
	case isStraight && isFlush:
		return RankedHand{Type: StraightFlush, TieBreakers: []int{straightHigh}}
	case len(valueCounts) == 2 && (valueCounts[0].count == 4 || valueCounts[0].count == 3):
		if valueCounts[0].count == 4 {
			return RankedHand{Type: FourOfKind, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value}}
		}
		return RankedHand{Type: FullHouse, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value}}
	case isFlush:
		return RankedHand{Type: Flush, TieBreakers: sorted}
	case straightHigh != 0:
		return RankedHand{Type: Straight, TieBreakers: []int{straightHigh}}
	case len(valueCounts) == 1:
		return RankedHand{Type: FourOfKind, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value}}
	case len(valueCounts) == 2:
		if valueCounts[0].count == 3 {
			return RankedHand{Type: FullHouse, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value}}
		}
		// three of a kind + ... handled below
		return RankedHand{Type: OnePair, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value}}
	case len(valueCounts) == 3:
		if valueCounts[0].count == 3 {
			return RankedHand{Type: ThreeOfKind, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value, valueCounts[2].value}}
		}
		// two pairs
		return RankedHand{Type: TwoPair, TieBreakers: []int{valueCounts[0].value, valueCounts[1].value, valueCounts[2].value}}
	case len(valueCounts) == 4:
		// one pair, tiebreakers are pair then singles desc
		pair := 0
		singles := []int{}
		for _, vc := range valueCounts {
			if vc.count == 2 {
				pair = vc.value
			} else {
				singles = append(singles, vc.value)
			}
		}
		return RankedHand{Type: OnePair, TieBreakers: []int{pair, singles[0], singles[1], singles[2]}}
	}

	// High card
	return RankedHand{Type: HighCard, TieBreakers: sorted}
}

func checkStraight(sorted []int) int {
	// sorted is descending
	if sorted[0] == sorted[4] {
		return 0
	}

	for i := 1; i < 5; i++ {
		if sorted[i] != sorted[i-1]-1 {
			break
		}
		if i == 4 {
			return sorted[0]
		}
	}

	// Ace-low straight: A, 2, 3, 4, 5
	if sorted[0] == 14 && sorted[1] == 2 && sorted[2] == 3 && sorted[3] == 4 && sorted[4] == 5 {
		return 5
	}

	return 0
}

type valueCount struct {
	value int
	count int
}

func countValues(values []int) []valueCount {
	counts := map[int]int{}
	for _, v := range values {
		counts[v]++
	}

	result := make([]valueCount, 0, len(counts))
	for v, c := range counts {
		result = append(result, valueCount{value: v, count: c})
	}

	sort.Slice(result, func(i, j int) bool {
		if result[i].count != result[j].count {
			return result[i].count > result[j].count
		}
		return result[i].value > result[j].value
	})

	return result
}

func compareRanked(a, b RankedHand) int {
	if a.Type != b.Type {
		if a.Type < b.Type {
			return -1
		}
		return 1
	}
	for i := range a.TieBreakers {
		if a.TieBreakers[i] != b.TieBreakers[i] {
			if a.TieBreakers[i] < b.TieBreakers[i] {
				return -1
			}
			return 1
		}
	}
	return 0
}

func BestHand(hands []string) ([]string, error) {
	if len(hands) == 0 {
		return nil, fmt.Errorf("no hands provided")
	}

	bestHands := []string{}
	var best RankedHand

	for i, hand := range hands {
		cards, err := parseHand(hand)
		if err != nil {
			return nil, err
		}

		ranked := classifyHand(cards)
		ranked.Original = hand

		if i == 0 {
			best = ranked
			bestHands = []string{hand}
			continue
		}

		cmp := compareRanked(ranked, best)
		if cmp > 0 {
			best = ranked
			bestHands = []string{hand}
		} else if cmp == 0 {
			bestHands = append(bestHands, hand)
		}
	}

	return bestHands, nil
}

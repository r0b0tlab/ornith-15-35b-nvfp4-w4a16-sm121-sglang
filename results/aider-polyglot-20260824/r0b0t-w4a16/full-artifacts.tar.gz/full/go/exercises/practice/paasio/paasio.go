package paasio

import "io"

// readCounter wraps an io.Reader and reports IO statistics.
type readCounter struct {
	reader    io.Reader
	totalRead int64
	readOps   int64
}

// writeCounter wraps an io.Writer and reports IO statistics.
type writeCounter struct {
	writer   io.Writer
	totalWrit int64
	writeOps int64
}

// readWriteCounter wraps an io.ReadWriter and reports IO statistics.
type readWriteCounter struct {
	reader    io.Reader
	writer    io.Writer
	totalRead int64
	totalWrit int64
	readOps   int64
	writeOps  int64
}

// NewWriteCounter creates a WriteCounter that wraps the given io.Writer.
func NewWriteCounter(writer io.Writer) WriteCounter {
	return &writeCounter{writer: writer}
}

// NewReadCounter creates a ReadCounter that wraps the given io.Reader.
func NewReadCounter(reader io.Reader) ReadCounter {
	return &readCounter{reader: reader}
}

// NewReadWriteCounter creates a ReadWriteCounter that wraps the given io.ReadWriter.
func NewReadWriteCounter(readwriter io.ReadWriter) ReadWriteCounter {
	return &readWriteCounter{reader: readwriter, writer: readwriter}
}

// Read reads data into p, tracking total bytes and operation count.
func (rc *readCounter) Read(p []byte) (int, error) {
	n, err := rc.reader.Read(p)
	rc.totalRead += int64(n)
	rc.readOps++
	return n, err
}

// ReadCount returns the total bytes read and the number of read operations.
func (rc *readCounter) ReadCount() (int64, int) {
	return rc.totalRead, int(rc.readOps)
}

// Write writes data p, tracking total bytes and operation count.
func (wc *writeCounter) Write(p []byte) (int, error) {
	n, err := wc.writer.Write(p)
	wc.totalWrit += int64(n)
	wc.writeOps++
	return n, err
}

// WriteCount returns the total bytes written and the number of write operations.
func (wc *writeCounter) WriteCount() (int64, int) {
	return wc.totalWrit, int(wc.writeOps)
}

// Read reads data into p through the combined counter, tracking stats.
func (rcw *readWriteCounter) Read(p []byte) (int, error) {
	n, err := rcw.reader.Read(p)
	rcw.totalRead += int64(n)
	rcw.readOps++
	return n, err
}

// Write writes data p through the combined counter, tracking stats.
func (rcw *readWriteCounter) Write(p []byte) (int, error) {
	n, err := rcw.writer.Write(p)
	rcw.totalWrit += int64(n)
	rcw.writeOps++
	return n, err
}

// ReadCount returns the total bytes read and the number of read operations.
func (rcw *readWriteCounter) ReadCount() (int64, int) {
	return rcw.totalRead, int(rcw.readOps)
}

// WriteCount returns the total bytes written and the number of write operations.
func (rcw *readWriteCounter) WriteCount() (int64, int) {
	return rcw.totalWrit, int(rcw.writeOps)
}

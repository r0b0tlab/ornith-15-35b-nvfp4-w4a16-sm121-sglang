package matrix

import (
	"errors"
	"strconv"
	"strings"
)

// Define the Matrix type here.

type Matrix struct {
	rows int
	cols int
	data [][]int
}

func New(s string) (*Matrix, error) {
	if strings.TrimSpace(s) == "" {
		return nil, errors.New("empty matrix")
	}
	rows := strings.Split(s, "\n")
	m := &Matrix{}
	m.rows = len(rows)
	for i, row := range rows {
		cols := len(strings.Fields(row))
		if m.cols == 0 {
			m.cols = cols
		} else if m.cols != cols {
			return nil, errors.New("inconsistent row lengths")
		}
		_ = i
	}
	m.data = make([][]int, m.rows)
	for i, row := range rows {
		fields := strings.Fields(row)
		m.data[i] = make([]int, len(fields))
		for j, f := range fields {
			v, err := strconv.Atoi(f)
			if err != nil {
				return nil, err
			}
			m.data[i][j] = v
		}
	}
	return m, nil
}

// Cols and Rows must return the results without affecting the matrix.
func (m *Matrix) Cols() [][]int {
	cols := make([][]int, m.cols)
	for c := 0; c < m.cols; c++ {
		cols[c] = make([]int, m.rows)
		for r := 0; r < m.rows; r++ {
			cols[c][r] = m.data[r][c]
		}
	}
	return cols
}

func (m *Matrix) Rows() [][]int {
	rows := make([][]int, m.rows)
	for i := range m.data {
		rows[i] = make([]int, len(m.data[i]))
		copy(rows[i], m.data[i])
	}
	return rows
}

func (m *Matrix) Set(row, col, val int) bool {
	if row < 0 || row >= m.rows || col < 0 || col >= m.cols {
		return false
	}
	m.data[row][col] = val
	return true
}

package cryptosquare

import (
	"math"
	"strings"
	"unicode"
)

func Encode(pt string) string {
	// Normalize: remove spaces and punctuation, downcase
	var normalized strings.Builder
	for _, r := range pt {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			normalized.WriteRune(unicode.ToLower(r))
		}
	}

	clean := normalized.String()
	length := len(clean)

	// Handle empty messages
	if length == 0 {
		return ""
	}

	// Determine rectangle dimensions
	// c = ceil(sqrt(length)), r = ceil(length/c)
	c := int(math.Ceil(math.Sqrt(float64(length))))
	r := int(math.Ceil(float64(length) / float64(c)))

	// Build the rectangle
	// Fill row by row, padding with spaces
	var rows []string
	for i := 0; i < length; i += c {
		end := i + c
		if end > length {
			end = length
		}
		row := clean[i:end]
		// Pad row with spaces to fill c characters
		for len(row) < c {
			row += " "
		}
		rows = append(rows, row)
	}

	// Read down columns to create chunks
	var chunks []string
	for col := 0; col < c; col++ {
		chunk := ""
		for row := range rows {
			chunk += string(rows[row][col])
		}
		chunks = append(chunks, chunk)
	}

	// Join chunks with spaces
	return strings.Join(chunks, " ")
}

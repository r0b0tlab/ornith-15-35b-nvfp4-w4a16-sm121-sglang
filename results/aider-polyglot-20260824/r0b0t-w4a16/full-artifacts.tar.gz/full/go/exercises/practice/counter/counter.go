package counter

// This is a special exercise. The system under test is a counter tool
// that counts the number of lines, letters, and total characters in
// supplied strings.
//
// The implementation is provided by whoever uses this package. This file
// serves as documentation and defines the expected interface.
//
// The System interface defines the operations:
//   - AddString: perform the "add string" operation
//   - Lines: get the total number of lines
//   - Letters: get the total number of letters
//   - Characters: get the total number of characters
type System interface {
    AddString(s string)
    Lines() int
    Letters() int
    Characters() int
}

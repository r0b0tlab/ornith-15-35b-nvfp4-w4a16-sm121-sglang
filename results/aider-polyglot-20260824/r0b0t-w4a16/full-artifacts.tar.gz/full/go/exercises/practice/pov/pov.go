package pov

type Tree struct {
	Value_    string
	Children_ []*Tree
}

// New creates and returns a new Tree with the given root value and children.
func New(value string, children ...*Tree) *Tree {
	return &Tree{
		Value_:    value,
		Children_: children,
	}
}

// Value returns the value at the root of a tree.
func (tr *Tree) Value() string {
	return tr.Value_
}

// Children returns a slice containing the children of a tree.
// There is no need to sort the elements in the result slice,
// they can be in any order.
func (tr *Tree) Children() []*Tree {
	return tr.Children_
}

// String describes a tree in a compact S-expression format.
// This helps to make test outputs more readable.
// Feel free to adapt this method as you see fit.
func (tr *Tree) String() string {
	if tr == nil {
		return "nil"
	}
	result := tr.Value()
	if len(tr.Children_) == 0 {
		return result
	}
	for _, ch := range tr.Children_ {
		result += " " + ch.String()
	}
	return "(" + result + ")"
}

// POV problem-specific functions

// FromPov returns the pov from the node specified in the argument.
func (tr *Tree) FromPov(from string) *Tree {
	newRoot := tr.reparent(from)
	if newRoot == nil {
		return nil
	}
	return newRoot
}

// reparent rebuilds the tree so that the node with the given value becomes the root.
// It returns the new root, or nil if the value is not found.
func (tr *Tree) reparent(from string) *Tree {
	if tr == nil {
		return nil
	}
	if tr.Value_ == from {
		return tr
	}
	// Search children
	newChildren := make([]*Tree, 0, len(tr.Children_))
	for _, child := range tr.Children_ {
		updatedChild := child.reparent(from)
		if updatedChild != nil {
			// We found the target in this child's subtree.
			// The child now points back to tr, making tr the new root.
			child.Children_ = append(child.Children_, tr)
			return updatedChild
		}
		newChildren = append(newChildren, updatedChild)
	}
	tr.Children_ = newChildren
	return nil
}

// PathTo returns the shortest path between two nodes in the tree.
func (tr *Tree) PathTo(from, to string) []string {
	// Find path from `from` to root
	pathFrom := findPath(tr, from)
	// Find path from `to` to root
	pathTo := findPath(tr, to)

	if pathFrom == nil || pathTo == nil {
		return nil
	}

	// Combine: pathFrom is from `from` up to root, pathTo is from `to` up to root
	// We need to reverse pathTo and find the common ancestor
	// Build the path by walking up from `from` and `to`
	// ...
}

// findPath returns the path from the given value up to the root.
func findPath(tr *Tree, from string) []string {
	if tr == nil {
		return nil
	}
	if tr.Value_ == from {
		return []string{from}
	}
	for _, child := range tr.Children_ {
		path := findPath(child, from)
		if path != nil {
			return append([]string{tr.Value_}, path...)
		}
	}
	return nil
}

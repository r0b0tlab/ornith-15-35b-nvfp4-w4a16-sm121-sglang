package connect

import (
	"strings"
)

type point struct {
	row, col int
}

func ResultOf(lines []string) (string, error) {
	// Parse the board into a clean 2D grid, removing the leading spaces
	// that create the diagonal look.
	if len(lines) == 0 {
		return "", nil
	}

	size := len(lines)
	board := make([][]rune, size)

	for i, line := range lines {
		// Remove leading spaces (i spaces for row i)
		cleaned := strings.TrimSpace(line)
		// Remove leading spaces specifically (the indentation)
		trimmed := strings.TrimLeft(cleaned, " ")
		board[i] = []rune(trimmed)
	}

	// Check for player O (top to bottom) connection
	if hasWinningPath(board, size, 'O') {
		return "o", nil
	}

	// Check for player X (left to right) connection
	if hasWinningPathX(board, size, 'X') {
		return "x", nil
	}

	return "", nil
}

// hasWinningPath checks if player O can connect top to bottom.
func hasWinningPath(board [][]rune, size int, player rune) bool {
	if size == 0 {
		return false
	}

	// Queue for BFS
	queue := []point{}

	// Add all O pieces in the top row
	for col := 0; col < len(board[0]); col++ {
		if board[0][col] == player {
			queue = append(queue, point{0, col})
		}
	}

	visited := make([][]bool, size)
	for i := range visited {
		visited[i] = make([]bool, len(board[i]))
	}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		row, col := current.row, current.col

		// Check if reached the bottom row
		if row == size-1 {
			return true
		}

		if visited[row][col] {
			continue
		}
		visited[row][col] = true

		// Get neighbors (6 hexagonal neighbors)
		neighbors := getNeighborsO(row, col, board, size)
		for _, n := range neighbors {
			if !visited[n.row][n.col] && board[n.row][n.col] == player {
				queue = append(queue, n)
			}
		}
	}

	return false
}

// hasWinningPathX checks if player X can connect left to right.
func hasWinningPathX(board [][]rune, size int, player rune) bool {
	if size == 0 {
		return false
	}

	// Queue for BFS
	queue := []point{}

	// Add all X pieces in the leftmost column of each row
	for row := 0; row < size; row++ {
		if len(board[row]) > 0 && board[row][0] == player {
			queue = append(queue, point{row, 0})
		}
	}

	visited := make([][]bool, size)
	for i := range visited {
		visited[i] = make([]bool, len(board[i]))
	}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		row, col := current.row, current.col

		// Check if reached the rightmost position
		if col == len(board[row])-1 {
			return true
		}

		if visited[row][col] {
			continue
		}
		visited[row][col] = true

		// Get neighbors (6 hexagonal neighbors)
		neighbors := getNeighborsX(row, col, board, size)
		for _, n := range neighbors {
			if !visited[n.row][n.col] && board[n.row][n.col] == player {
				queue = append(queue, n)
			}
		}
	}

	return false
}

// getNeighborsO returns the valid hexagonal neighbors for player O movement.
func getNeighborsO(row, col int, board [][]rune, size int) []point {
	neighbors := []point{}

	// Directions for O (vertical-ish movement): up, down, and 4 diagonals
	directions := [][]int{
		{-1, 0}, {-1, 1}, // up-left, up-right
		{1, 0}, {1, 1},   // down-left, down-right
		{0, -1}, {0, 1},  // left, right
	}

	for _, d := range directions {
		nr, nc := row+d[0], col+d[1]
		if nr >= 0 && nr < size && nc >= 0 && nc < len(board[nr]) {
			neighbors = append(neighbors, point{nr, nc})
		}
	}

	return neighbors
}

// getNeighborsX returns the valid hexagonal neighbors for player X movement.
func getNeighborsX(row, col int, board [][]rune, size int) []point {
	neighbors := []point{}

	// Directions for X (horizontal-ish movement): left, right, and 4 diagonals
	directions := [][]int{
		{0, -1}, {0, 1},  // left, right
		{-1, 0}, {-1, 1}, // up-left, up-right
		{1, 0}, {1, -1},  // down-left, down-right
	}

	for _, d := range directions {
		nr, nc := row+d[0], col+d[1]
		if nr >= 0 && nr < size && nc >= 0 && nc < len(board[nr]) {
			neighbors = append(neighbors, point{nr, nc})
		}
	}

	return neighbors
}

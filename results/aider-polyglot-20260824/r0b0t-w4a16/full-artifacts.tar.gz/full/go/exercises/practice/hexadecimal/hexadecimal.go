package hexadecimal

import "errors"

func ParseHex(in string) (int64, error) {
	var result int64 = 0

	for _, ch := range in {
		var digit int64

		switch {
		case ch >= '0' && ch <= '9':
			digit = int64(ch - '0')
		case ch >= 'a' && ch <= 'f':
			digit = int64(ch-'a') + 10
		case ch >= 'A' && ch <= 'F':
			digit = int64(ch-'A') + 10
		default:
			return 0, errors.New("invalid hexadecimal string")
		}

		result = result*16 + digit
	}

	return result, nil
}

func HandleErrors(in string, expected int64, errCase error) error {
	result, err := ParseHex(in)
	if err != nil {
		return err
	}
	if result != expected {
		return errors.New("incorrect result")
	}
	return nil
}

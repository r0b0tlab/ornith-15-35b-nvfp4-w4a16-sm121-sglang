package ledger

import (
	"errors"
	"sort"
	"strconv"
	"strings"
)

type Entry struct {
	Date        string // "Y-m-d"
	Description string
	Change      int // in cents
}

func FormatLedger(currency string, locale string, entries []Entry) (string, error) {
	// Sort entries by date, then description, then change
	sort.Slice(entries, func(i, j int) bool {
		if entries[i].Date != entries[j].Date {
			return entries[i].Date < entries[j].Date
		}
		if entries[i].Description != entries[j].Description {
			return entries[i].Description < entries[j].Description
		}
		return entries[i].Change < entries[j].Change
	})

	// Determine column headers based on locale
	var dateHeader, descHeader, changeHeader string
	if locale == "nl-NL" {
		dateHeader = "Datum"
		descHeader = "Omschrijving"
		changeHeader = "Verandering"
	} else if locale == "en-US" {
		dateHeader = "Date"
		descHeader = "Description"
		changeHeader = "Change"
	} else {
		return "", errors.New("invalid locale")
	}

	// Build the header line
	var sb strings.Builder
	sb.WriteString(dateHeader)
	sb.WriteString(strings.Repeat(" ", 10-len(dateHeader)))
	sb.WriteString(" | ")
	sb.WriteString(descHeader)
	sb.WriteString(strings.Repeat(" ", 25-len(descHeader)))
	sb.WriteString(" | ")
	sb.WriteString(changeHeader)
	sb.WriteString("\n")

	// Format each entry
	for _, entry := range entries {
		line, err := formatEntry(currency, locale, entry)
		if err != nil {
			return "", err
		}
		sb.WriteString(line)
	}

	return sb.String(), nil
}

func formatEntry(currency string, locale string, entry Entry) (string, error) {
	var sb strings.Builder

	// Validate and format the date
	if len(entry.Date) != 10 || entry.Date[4] != '-' || entry.Date[7] != '-' {
		return "", errors.New("invalid date format")
	}
	var date string
	if locale == "nl-NL" {
		date = entry.Date[6:8] + "-" + entry.Date[3:5] + "-" + entry.Date[0:4]
	} else if locale == "en-US" {
		date = entry.Date[5:7] + "/" + entry.Date[8:10] + "/" + entry.Date[0:4]
	} else {
		return "", errors.New("invalid locale")
	}

	// Format the description (truncate to 25 chars, pad with spaces)
	description := entry.Description
	if len(description) > 25 {
		description = description[:22] + "..."
	} else {
		description += strings.Repeat(" ", 25-len(description))
	}

	// Format the change amount
	change, err := formatChange(currency, locale, entry.Change)
	if err != nil {
		return "", err
	}

	// Assemble the line
	sb.WriteString(date)
	sb.WriteString(strings.Repeat(" ", 10-len(date)))
	sb.WriteString(" | ")
	sb.WriteString(description)
	sb.WriteString(" | ")
	sb.WriteString(strings.Repeat(" ", 13-len(change)))
	sb.WriteString(change)
	sb.WriteString("\n")

	return sb.String(), nil
}

func formatChange(currency string, locale string, change int) (string, error) {
	negative := change < 0
	cents := abs(change)

	// Pad cents to at least 3 digits
	centsStr := strconv.Itoa(cents)
	switch len(centsStr) {
	case 1:
		centsStr = "00" + centsStr
	case 2:
		centsStr = "0" + centsStr
	}

	// Split into groups of three digits from the right
	var parts []string
	rest := centsStr
	for len(rest) > 3 {
		parts = append(parts, rest[len(rest)-3:])
		rest = rest[:len(rest)-3]
	}
	if len(rest) > 0 {
		parts = append(parts, rest)
	}

	// Build the number string
	var amount string
	for i := len(parts) - 1; i >= 0; i-- {
		amount += parts[i]
		if i > 0 {
			if locale == "nl-NL" {
				amount += "."
			} else {
				amount += ","
			}
		}
	}

	// Add the decimal point and cents
	amount += "."
	amount += centsStr[len(centsStr)-2:]

	// Apply currency and sign
	var result string
	if locale == "nl-NL" {
		result = " "
		result += currencySymbol(currency)
		result += " "
		result += amount
		if negative {
			result = "-" + result
		} else {
			result = " " + result
		}
	} else if locale == "en-US" {
		if negative {
			result = "("
		}
		result += currencySymbol(currency)
		result += amount
		if negative {
			result += ")"
		} else {
			result += " "
		}
	}

	return result, nil
}

func currencySymbol(currency string) string {
	if currency == "EUR" {
		return "€"
	} else if currency == "USD" {
		return "$"
	}
	return ""
}

func abs(x int) int {
	if x < 0 {
		return -x
	}
	return x
}

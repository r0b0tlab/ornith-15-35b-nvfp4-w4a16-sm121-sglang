package piglatin

import (
	"strings"
)

// isVowel reports whether the given rune is a vowel.
func isVowel(r byte) bool {
	return r == 'a' || r == 'e' || r == 'i' || r == 'o' || r == 'u'
}

// translateWord translates a single word to Pig Latin.
func translateWord(word string) string {
	// Rule 1: word begins with a vowel or starts with "xr" or "yt"
	if isVowel(word[0]) || strings.HasPrefix(word, "xr") || strings.HasPrefix(word, "yt") {
		return word + "ay"
	}

	// Find the index where the initial consonant cluster ends.
	// Rule 3 handles "qu" as a unit.
	// Rule 4 treats 'y' as a vowel when it appears after consonants.
	i := 0
	for i < len(word) {
		// Rule 4: 'y' after consonants acts as a vowel.
		if i > 0 && word[i] == 'y' {
			break
		}
		// Rule 3: handle "qu" as a consonant cluster.
		if word[i] == 'q' && i+1 < len(word) && word[i+1] == 'u' {
			i += 2
			break
		}
		// Otherwise, if it's a consonant, continue.
		if !isVowel(word[i]) {
			i++
			continue
		}
		// Reached a vowel, stop.
		break
	}

	return word[i:] + word[:i] + "ay"
}

// Sentence translates an entire sentence to Pig Latin.
func Sentence(sentence string) string {
	words := strings.Split(sentence, " ")
	for i, word := range words {
		words[i] = translateWord(word)
	}
	return strings.Join(words, " ")
}

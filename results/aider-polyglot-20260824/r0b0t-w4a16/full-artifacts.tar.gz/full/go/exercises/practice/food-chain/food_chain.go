package foodchain

import (
	"fmt"
	"strings"
)

var animals = []string{
	"fly",
	"spider",
	"bird",
	"cat",
	"dog",
	"goat",
	"cow",
	"horse",
}

var reactions = map[string]string{
	"fly":    "",
	"spider": "It wriggled and jiggled and tickled inside her.\n",
	"bird":   "How absurd to swallow a bird!\n",
	"cat":    "Imagine that, to swallow a cat!\n",
	"dog":    "What a hog, to swallow a dog!\n",
	"goat":   "Just opened her throat and swallowed a goat!\n",
	"cow":    "I don't know how she swallowed a cow!\n",
	"horse":  "She's dead, of course!\n",
}

func Verse(v int) string {
	// v is 1-indexed
	index := v - 1
	animal := animals[index]

	var sb strings.Builder
	sb.WriteString("I know an old lady who swallowed a " + animal + ".\n")

	switch animal {
	case "fly":
		sb.WriteString("I don't know why she swallowed the fly. Perhaps she'll die.\n")
	case "horse":
		sb.WriteString("She's dead, of course!\n")
	default:
		sb.WriteString(reactions[animal])
		// Swallowing chain, from current animal down to fly
		for i := index; i > 0; i-- {
			sb.WriteString(fmt.Sprintf("She swallowed the %s to catch the %s.\n", animals[i], animals[i-1]))
		}
		// Spider special line
		sb.WriteString("She swallowed the spider to catch the fly.\n")
		sb.WriteString("I don't know why she swallowed the fly. Perhaps she'll die.\n")
	}

	return sb.String()
}

func Verses(start, end int) string {
	var sb strings.Builder
	for v := start; v <= end; v++ {
		sb.WriteString(Verse(v))
		if v != end {
			sb.WriteString("\n")
		}
	}
	return sb.String()
}

func Song() string {
	return Verses(1, 8)
}

package dominoes

type Domino [2]int

func MakeChain(input []Domino) (chain []Domino, ok bool) {
	if len(input) == 0 {
		return []Domino{}, true
	}

	chain = make([]Domino, 0, len(input))

	// seed chain with the first domino in either orientation
	for _, first := range input {
		if buildChain(input, first, &chain) {
			return chain, true
		}
	}

	return nil, false
}

func buildChain(input []Domino, first Domino, chain *[]Domino) bool {
	*chain = []Domino{first}

	used := make([]bool, len(input))
	used[0] = true

	if !placeNext(input, first, used, chain) {
		return false
	}

	// check that the chain closes
	if (*chain)[0][0] == (*chain)[len(*chain)-1][1] {
		return true
	}

	return false
}

func placeNext(input []Domino, prev Domino, used []bool, chain *[]Domino) bool {
	if len(*chain) == len(input) {
		return true
	}

	for i := 0; i < len(input); i++ {
		if used[i] {
			continue
		}

		d := input[i]

		if d[0] == prev[1] {
			used[i] = true
			*chain = append(*chain, d)
			if placeNext(input, d, used, chain) {
				return true
			}
			*chain = (*chain)[:len(*chain)-1]
			used[i] = false
		}

		if d[1] == prev[1] && d[0] != d[1] {
			rotated := Domino{d[1], d[0]}
			used[i] = true
			*chain = append(*chain, rotated)
			if placeNext(input, rotated, used, chain) {
				return true
			}
			*chain = (*chain)[:len(*chain)-1]
			used[i] = false
		}
	}

	return false
}

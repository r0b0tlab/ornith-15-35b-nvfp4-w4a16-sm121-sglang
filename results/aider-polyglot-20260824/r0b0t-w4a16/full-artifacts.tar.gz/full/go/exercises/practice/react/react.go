package react

// Reactor manages a network of cells and their dependencies.
type reactor struct {
	inputs  map[InputCell]struct{}
	compute map[ComputeCell]struct{}
}

// cell represents a cell in the reactive system.
type cell struct {
	value     int
	isInput   bool
	dependents map[Cell]struct{} // cells that depend on this cell
	computeFn  func(int) int     // for compute1 cells
	computeFn2 func(int, int) int // for compute2 cells
	deps       []Cell             // dependencies for compute cells
	cancel     *canceler          // canceler for this cell
	callbacks  map[*canceler]struct{} // registered callbacks
}

// canceler implements the Canceler interface.
type canceler struct {
	cell *cell
}

func (c *canceler) Cancel() {
	delete(c.cell.callbacks, c)
}

// Value returns the current value of the cell.
func (c *cell) Value() int {
	return c.value
}

// SetValue sets the value of an input cell.
func (c *cell) SetValue(value int) {
	if !c.isInput {
		panic("SetValue can only be called on input cells")
	}
	if c.value == value {
		return
	}
	c.value = value
	// Propagate changes to dependent cells
	for dependent := range c.dependents {
		dependent.(*cell).updateValue()
	}
}

// updateValue recalculates the value of a compute cell.
func (c *cell) updateValue() {
	if c.isInput {
		return
	}

	var newValue int
	if c.computeFn != nil {
		newValue = c.computeFn(c.deps[0].(*cell).value)
	} else if c.computeFn2 != nil {
		newValue = c.computeFn2(c.deps[0].(*cell).value, c.deps[1].(*cell).value)
	}

	if newValue != c.value {
		c.value = newValue
		// Propagate to dependent cells
		for dependent := range c.dependents {
			dependent.(*cell).updateValue()
		}
	}
}

// AddCallback registers a callback for when the cell's value changes.
func (c *cell) AddCallback(callback func(int)) Canceler {
	if c.callbacks == nil {
		c.callbacks = make(map[*canceler]struct{})
	}
	canceler := &canceler{cell: c}
	c.callbacks[canceler] = struct{}{}
	return canceler
}

// CreateInput creates an input cell with an initial value.
func (r *reactor) CreateInput(initial int) InputCell {
	inputCell := &cell{
		value:    initial,
		isInput:  true,
		dependents: make(map[Cell]struct{}),
	}
	r.inputs[inputCell] = struct{}{}
	return inputCell
}

// CreateCompute1 creates a compute cell that depends on one other cell.
func (r *reactor) CreateCompute1(dep Cell, compute func(int) int) ComputeCell {
	computeCell := &cell{
		isInput:  false,
		dependents: make(map[Cell]struct{}),
		computeFn:  compute,
		deps:     []Cell{dep},
	}
	dep.(*cell).dependents[computeCell] = struct{}{}
	r.compute[computeCell] = struct{}{}
	computeCell.updateValue()
	return computeCell
}

// CreateCompute2 creates a compute cell that depends on two other cells.
func (r *reactor) CreateCompute2(dep1, dep2 Cell, compute func(int, int) int) ComputeCell {
	computeCell := &cell{
		isInput:  false,
		dependents: make(map[Cell]struct{}),
		computeFn2: compute,
		deps:     []Cell{dep1, dep2},
	}
	dep1.(*cell).dependents[computeCell] = struct{}{}
	dep2.(*cell).dependents[computeCell] = struct{}{}
	r.compute[computeCell] = struct{}{}
	computeCell.updateValue()
	return computeCell
}

package forth

import (
	"errors"
	"strconv"
	"strings"
)

// Forth evaluates a Forth program given as a slice of input lines.
func Forth(input []string) ([]int, error) {
	var stack []int
	words := map[string][]string{}
	exec := func(tokens []string) error {
		for _, token := range tokens {
			// Check if token is a user-defined word
			if fn, ok := words[strings.ToUpper(token)]; ok {
				if err := exec(fn); err != nil {
					return err
				}
				continue
			}
			// Check if token is a number
			if num, err := strconv.Atoi(token); err == nil {
				stack = append(stack, num)
				continue
			}
			// Check if token is a builtin
			switch strings.ToUpper(token) {
			case "+":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				b, a := stack[len(stack)-2], stack[len(stack)-1]
				stack = stack[:len(stack)-2]
				stack = append(stack, a+b)
			case "-":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				b, a := stack[len(stack)-2], stack[len(stack)-1]
				stack = stack[:len(stack)-2]
				stack = append(stack, a-b)
			case "*":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				b, a := stack[len(stack)-2], stack[len(stack)-1]
				stack = stack[:len(stack)-2]
				stack = append(stack, a*b)
			case "/":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				b, a := stack[len(stack)-2], stack[len(stack)-1]
				if b == 0 {
					return errors.New("divide by zero")
				}
				stack = stack[:len(stack)-2]
				stack = append(stack, a/b)
			case "dup":
				if len(stack) < 1 {
					return errors.New("stack underflow")
				}
				stack = append(stack, stack[len(stack)-1])
			case "drop":
				if len(stack) < 1 {
					return errors.New("stack underflow")
				}
				stack = stack[:len(stack)-1]
			case "swap":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				stack[len(stack)-1], stack[len(stack)-2] = stack[len(stack)-2], stack[len(stack)-1]
			case "over":
				if len(stack) < 2 {
					return errors.New("stack underflow")
				}
				a := stack[len(stack)-2]
				stack = append(stack, a)
			case ";":
				return errors.New("unexpected semicolon")
			default:
				return errors.New("unknown word: " + token)
			}
		}
		return nil
	}

	for _, line := range input {
		tokens := tokenize(line)
		for i := 0; i < len(tokens); {
			token := tokens[i]
			if token == ":" {
				// Defining a new word
				if i+1 >= len(tokens) || tokens[i+1] == ";" {
					return nil, errors.New("invalid definition")
				}
				name := strings.ToUpper(tokens[i+1])
				i += 2
				def := []string{}
				for i < len(tokens) && tokens[i] != ";" {
					def = append(def, tokens[i])
					i++
				}
				if i >= len(tokens) {
					return nil, errors.New("unterminated definition")
				}
				// i points to ";"
				i++
				if err := exec(def); err != nil {
					return nil, err
				}
				words[name] = def
				continue
			}
			if err := exec([]string{token}); err != nil {
				return nil, err
			}
			i++
		}
	}
	return stack, nil
}

// tokenize splits a line into tokens by whitespace.
func tokenize(line string) []string {
	return strings.Fields(line)
}

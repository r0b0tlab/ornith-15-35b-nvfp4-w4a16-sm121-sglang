package palindrome

import "errors"

// Define Product type here.

type Product struct {
	Palindrome    int
	Factors       [][]int
	Factorizations []int
}

func Products(fmin, fmax int) (Product, Product, error) {
	if fmin > fmax {
		return Product{}, Product{}, errors.New("fmin must be less than or equal to fmax")
	}

	var smallest Product
	var largest Product
	smallest.Palindrome = 0
	largest.Palindrome = 0

	for i := fmin; i <= fmax; i++ {
		for j := i; j <= fmax; j++ {
			product := i * j
			if isPalindrome(product) {
				if smallest.Palindrome == 0 || product < smallest.Palindrome {
					smallest.Palindrome = product
					smallest.Factors = [][]int{{i, j}}
				} else if product == smallest.Palindrome {
					smallest.Factors = append(smallest.Factors, []int{i, j})
				}

				if largest.Palindrome == 0 || product > largest.Palindrome {
					largest.Palindrome = product
					largest.Factors = [][]int{{i, j}}
				} else if product == largest.Palindrome {
					largest.Factors = append(largest.Factors, []int{i, j})
				}
			}
		}
	}

	return smallest, largest, nil
}

func isPalindrome(n int) bool {
	if n < 0 {
		return false
	}

	original := n
	reversed := 0
	for n > 0 {
		reversed = reversed*10 + n%10
		n /= 10
	}

	return original == reversed
}

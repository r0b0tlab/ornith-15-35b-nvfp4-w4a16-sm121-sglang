package bottlesong

import "fmt"

var numberWords = map[int]string{
	0: "no",
	1: "one",
	2: "two",
	3: "three",
	4: "four",
	5: "five",
	6: "six",
	7: "seven",
	8: "eight",
	9: "nine",
	10: "ten",
}

func Recite(startBottles, takeDown int) []string {
	var verses []string

	for i := 0; i < takeDown; i++ {
		if i > 0 {
			verses = append(verses, "")
		}

		currentBottles := startBottles - i
		nextBottles := startBottles - i - 1

		currentBottle := "bottles"
		if currentBottles == 1 {
			currentBottle = "bottle"
		}

		nextBottle := "bottles"
		if nextBottles == 1 {
			nextBottle = "bottle"
		}

		verse := []string{
			fmt.Sprintf("%s green %s hanging on the wall,", capitalize(numberWords[currentBottles]), currentBottle),
			fmt.Sprintf("%s green %s hanging on the wall,", capitalize(numberWords[currentBottles]), currentBottle),
			"And if one green bottle should accidentally fall,",
			fmt.Sprintf("There'll be %s green %s hanging on the wall.", numberWords[nextBottles], nextBottle),
		}

		verses = append(verses, verse...)
	}

	return verses
}

func capitalize(s string) string {
	if len(s) == 0 {
		return s
	}
	return string(upper(s[0])) + s[1:]
}

func upper(b byte) byte {
	if b >= 'a' && b <= 'z' {
		return b - ('z' - 'Z')
	}
	return b
}

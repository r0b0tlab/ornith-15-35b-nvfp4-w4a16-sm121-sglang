package robot

// See defs.go for other definitions

// Step 1
// Define N, E, S, W here.
const (
	N Dir = iota
	E
	S
	W
)

func Right() {
	switch stdRobot.Dir {
	case N:
		stdRobot.Dir = E
	case E:
		stdRobot.Dir = S
	case S:
		stdRobot.Dir = W
	case W:
		stdRobot.Dir = N
	}
}

func Left() {
	switch stdRobot.Dir {
	case N:
		stdRobot.Dir = W
	case W:
		stdRobot.Dir = S
	case S:
		stdRobot.Dir = E
	case E:
		stdRobot.Dir = N
	}
}

func Advance() {
	switch stdRobot.Dir {
	case N:
		stdRobot.Y++
	case E:
		stdRobot.X++
	case S:
		stdRobot.Y--
	case W:
		stdRobot.X--
	}
	stdRobot.Inc()
}

func (d Dir) String() string {
	switch d {
	case N:
		return "N"
	case E:
		return "E"
	case S:
		return "S"
	case W:
		return "W"
	}
	return "Unknown"
}

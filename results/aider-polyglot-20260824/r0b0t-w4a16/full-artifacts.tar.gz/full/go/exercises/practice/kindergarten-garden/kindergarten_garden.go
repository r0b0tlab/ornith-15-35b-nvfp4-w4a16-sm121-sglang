package kindergarten

import "errors"
import "sort"

// Define the Garden type here.

type Garden struct {
	diagram [][]rune
	children []string
}

// The diagram argument starts each row with a '\n'.  This allows Go's
// raw string literals to present diagrams in source code nicely as two
// rows flush left, for example,
//
//     diagram := `
//     VVCCGG
//     VVCCGG`

func NewGarden(diagram string, children []string) (*Garden, error) {
	// Validate the diagram starts with a newline
	if len(diagram) < 3 || diagram[0] != '\n' {
		return nil, errors.New("Invalid diagram format")
	}

	// Sort children alphabetically
	sortedChildren := make([]string, len(children))
	copy(sortedChildren, children)
	sort.Strings(sortedChildren)

	// Check for duplicate children
	for i := 0; i < len(sortedChildren); i++ {
		if i > 0 && sortedChildren[i] == sortedChildren[i-1] {
			return nil, errors.New("Duplicate children not allowed")
		}
	}

	// Parse the diagram into rows
	rows := []string{}
	for _, line := range splitLines(diagram) {
		if line == "" {
			continue
		}
		rows = append(rows, line)
	}

	// Ensure we have exactly 2 rows with 24 characters each
	if len(rows) != 2 {
		return nil, errors.New("Diagram must have exactly 2 rows")
	}
	for _, row := range rows {
		if len(row) != 24 {
			return nil, errors.New("Diagram rows must have 24 characters")
		}
	}

	return &Garden{
		diagram:    [][]rune{[]rune(rows[0]), []rune(rows[1])},
		children:   sortedChildren,
	}, nil
}

// splitLines splits a string by newlines, ignoring empty lines
func splitLines(s string) []string {
	var lines []string
	var current string
	for _, r := range s {
		if r == '\n' {
			lines = append(lines, current)
			current = ""
		} else {
			current += string(r)
		}
	}
	lines = append(lines, current)
	return lines
}

func (g *Garden) Plants(child string) ([]string, bool) {
	// Find the child's index
	index := -1
	for i, c := range g.children {
		if c == child {
			index = i
			break
		}
	}

	// If child not found, return false
	if index == -1 {
		return nil, false
	}

	// Each child gets 2 cups per row, starting at index*2
	startIndex := index * 2

	// Get the plants for this child
	plants := []string{}

	// First row
	plants = append(plants, g.decodePlant(g.diagram[0][startIndex]))
	plants = append(plants, g.decodePlant(g.diagram[0][startIndex+1]))

	// Second row
	plants = append(plants, g.decodePlant(g.diagram[1][startIndex]))
	plants = append(plants, g.decodePlant(g.diagram[1][startIndex+1]))

	return plants, true
}

// decodePlant converts a single character to a plant name
func (g *Garden) decodePlant(c rune) string {
	switch c {
	case 'G':
		return "Grass"
	case 'C':
		return "Clover"
	case 'R':
		return "Radishes"
	case 'V':
		return "Violets"
	default:
		return "Unknown"
	}
}

package bowling

import "errors"

// Game represents a bowling game.
type Game struct {
	rolls []int
}

// NewGame creates a new Game.
func NewGame() *Game {
	return &Game{
		rolls: make([]int, 0),
	}
}

// Roll records a roll and returns an error if the roll is invalid.
func (g *Game) Roll(pins int) error {
	if g.isGameOver() {
		return errors.New("cannot roll after game is over")
	}
	if pins < 0 || pins > 10 {
		return errors.New("pins must be between 0 and 10")
	}

	g.rolls = append(g.rolls, pins)

	// Validate the frame state after this roll.
	if err := g.validateRoll(); err != nil {
		return err
	}

	return nil
}

// validateRoll checks that the rolls so far form a valid game state.
func (g *Game) validateRoll() error {
	frame := 0
	rollIndex := 0

	for frame < 9 {
		if g.rolls[rollIndex] == 10 {
			// Strike
			rollIndex++
		} else {
			// Two rolls in the frame
			rollIndex += 2
		}
		frame++
	}

	// Handle the 10th frame.
	if rollIndex >= len(g.rolls) {
		return nil
	}

	// The 10th frame rolls start at rollIndex.
	tenthFrameRolls := g.rolls[rollIndex:]

	if len(tenthFrameRolls) == 1 {
		return nil
	}

	if tenthFrameRolls[0] == 10 {
		// Strike: need two more rolls
		if len(tenthFrameRolls) < 3 {
			return nil
		}
		if tenthFrameRolls[1] == 10 {
			// Second strike, need one more
			if len(tenthFrameRolls) < 4 {
				return nil
			}
			if tenthFrameRolls[2] > 10 {
				return errors.New("invalid roll")
			}
		} else {
			// First was strike, second was not, need one more
			if tenthFrameRolls[1]+tenthFrameRolls[2] > 10 {
				return errors.New("invalid roll")
			}
		}
	} else {
		// Not a strike on first roll
		if tenthFrameRolls[0]+tenthFrameRolls[1] > 10 {
			return errors.New("invalid roll")
		}
		if len(tenthFrameRolls) < 3 {
			return nil
		}
	}

	return nil
}

// Score calculates the total score for the game.
func (g *Game) Score() (int, error) {
	if !g.isGameOver() {
		return 0, errors.New("game is not complete")
	}

	score := 0
	rollIndex := 0

	for frame := 0; frame < 9; frame++ {
		if g.rolls[rollIndex] == 10 {
			// Strike
			if rollIndex+3 > len(g.rolls) {
				return 0, errors.New("incomplete game")
			}
			score += 10 + g.rolls[rollIndex+1] + g.rolls[rollIndex+2]
			rollIndex++
		} else if g.rolls[rollIndex]+g.rolls[rollIndex+1] == 10 {
			// Spare
			if rollIndex+3 > len(g.rolls) {
				return 0, errors.New("incomplete game")
			}
			score += 10 + g.rolls[rollIndex+2]
			rollIndex += 2
		} else {
			// Open frame
			score += g.rolls[rollIndex] + g.rolls[rollIndex+1]
			rollIndex += 2
		}
	}

	// 10th frame
	rollIndex = 9 * 2 // This is a simplification; adjust below

	// Recalculate the 10th frame start
	frame = 0
	rollIndex = 0
	for frame < 9 {
		if g.rolls[rollIndex] == 10 {
			rollIndex++
		} else {
			rollIndex += 2
		}
		frame++
	}

	score += g.rolls[rollIndex]
	if rollIndex+1 < len(g.rolls) {
		score += g.rolls[rollIndex+1]
		if rollIndex+2 < len(g.rolls) {
			score += g.rolls[rollIndex+2]
		}
	}

	return score, nil
}

// isGameOver checks whether the game is complete.
func (g *Game) isGameOver() bool {
	frame := 0
	rollIndex := 0

	for frame < 9 {
		if g.rolls[rollIndex] == 10 {
			rollIndex++
		} else {
			rollIndex += 2
		}
		frame++
	}

	// 10th frame
	if rollIndex+1 >= len(g.rolls) {
		return false
	}

	firstRoll := g.rolls[rollIndex]
	secondRoll := g.rolls[rollIndex+1]

	if firstRoll == 10 {
		// Strike, need one more roll
		if rollIndex+2 >= len(g.rolls) {
			return false
		}
		if rollIndex+3 < len(g.rolls) {
			return true
		}
		return false
	}

	if firstRoll+secondRoll == 10 {
		// Spare, need one more roll
		if rollIndex+2 >= len(g.rolls) {
			return false
		}
		return true
	}

	// Open frame
	if rollIndex+2 == len(g.rolls) {
		return true
	}

	return false
}

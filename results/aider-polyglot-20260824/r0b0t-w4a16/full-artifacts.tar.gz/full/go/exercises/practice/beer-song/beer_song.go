package beer

import "strings"
import "fmt"

func Song() string {
	return Verses(1, 99)
}

func Verses(start, stop int) string {
	var verses []string
	for i := start; i >= stop; i-- {
		verses = append(verses, Verse(i))
	}
	return strings.Join(verses, "\n")
}

func Verse(n int) string {
	switch n {
	case 0:
		return "No more bottles of beer on the wall, no more bottles of beer.\nGo to the store and buy some more, 99 bottles of beer on the wall."
	case 1:
		return "1 bottle of beer on the wall, 1 bottle of beer.\nTake it down and pass it around, no more bottles of beer on the wall."
	case 2:
		return "2 bottles of beer on the wall, 2 bottles of beer.\nTake one down and pass it around, 1 bottle of beer on the wall."
	default:
		return fmt.Sprintf("%d bottles of beer on the wall, %d bottles of beer.\nTake one down and pass it around, %d bottles of beer on the wall.", n, n, n-1), nil
	}
}

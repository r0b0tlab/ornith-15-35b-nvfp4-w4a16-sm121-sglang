#include "grade_school.h"
#include <algorithm>

namespace grade_school {

void school::add(const std::string& name, int grade) {
    for (const auto& entry : students_) {
        for (const auto& existing : entry.second) {
            if (existing == name) {
                throw std::runtime_error("student already enrolled");
            }
        }
    }
    students_[grade].push_back(name);
    auto& students = students_[grade];
    std::sort(students.begin(), students.end());
}

std::vector<std::string> school::grade(int grade) const {
    auto it = students_.find(grade);
    if (it == students_.end()) {
        return {};
    }
    return it->second;
}

std::vector<std::string> school::roster() const {
    std::vector<std::string> result;
    for (const auto& entry : students_) {
        for (const auto& name : entry.second) {
            result.push_back(name);
        }
    }
    return result;
}

}  // namespace grade_school

#include "allergies.h"
#include <unordered_set>
#include <string>
#include <vector>
#include <utility>

namespace allergies {

static const std::vector<std::pair<std::string, unsigned>> kAllAllergens = {
    {"eggs", 1}, {"peanuts", 2}, {"shellfish", 4}, {"strawberries", 8},
    {"tomatoes", 16}, {"chocolate", 32}, {"pollen", 64}, {"cats", 128}
};

allergies_test::allergies_test(unsigned score) : score_(score) {}

unsigned allergies_test::get_score() const {
    return score_;
}

bool allergies_test::is_allergic_to(const std::string& allergen) const {
    for (const auto& allergen_value : kAllAllergens) {
        if (allergen_value.first == allergen) {
            return (score_ & allergen_value.second) != 0;
        }
    }
    return false;
}

std::unordered_set<std::string> allergies_test::get_allergies() const {
    std::unordered_set<std::string> result;
    for (const auto& allergen_value : kAllAllergens) {
        if (score_ & allergen_value.second) {
            result.emplace(allergen_value.first);
        }
    }
    return result;
}

}  // namespace allergies

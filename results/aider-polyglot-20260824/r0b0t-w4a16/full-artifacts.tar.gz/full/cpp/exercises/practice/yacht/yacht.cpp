#include "yacht.h"

#include <algorithm>
#include <array>

namespace yacht {

int score(std::array<int, 5> dice, std::string_view category) {
    std::array<int, 6> counts{};
    for (int die : dice) {
        counts[die - 1]++;
    }

    int sum = 0;
    for (int die : dice) {
        sum += die;
    }

    if (category == "ones") {
        return counts[0] * 1;
    }
    if (category == "twos") {
        return counts[1] * 2;
    }
    if (category == "threes") {
        return counts[2] * 3;
    }
    if (category == "fours") {
        return counts[3] * 4;
    }
    if (category == "fives") {
        return counts[4] * 5;
    }
    if (category == "sixes") {
        return counts[5] * 6;
    }
    if (category == "full house") {
        bool hasThree = false;
        bool hasTwo = false;
        for (int count : counts) {
            if (count == 3) hasThree = true;
            if (count == 2) hasTwo = true;
        }
        return (hasThree && hasTwo) ? sum : 0;
    }
    if (category == "four of a kind") {
        for (int i = 0; i < 6; i++) {
            if (counts[i] >= 4) {
                return (i + 1) * 4;
            }
        }
        return 0;
    }
    if (category == "little straight") {
        std::array<int, 5> sorted = dice;
        std::sort(sorted.begin(), sorted.end());
        bool isStraight = true;
        for (int i = 0; i < 5; i++) {
            if (sorted[i] != i + 1) {
                isStraight = false;
                break;
            }
        }
        return isStraight ? 30 : 0;
    }
    if (category == "big straight") {
        std::array<int, 5> sorted = dice;
        std::sort(sorted.begin(), sorted.end());
        bool isStraight = true;
        for (int i = 0; i < 5; i++) {
            if (sorted[i] != i + 2) {
                isStraight = false;
                break;
            }
        }
        return isStraight ? 30 : 0;
    }
    if (category == "choice") {
        return sum;
    }
    if (category == "yacht") {
        for (int count : counts) {
            if (count == 5) return 50;
        }
        return 0;
    }

    return 0;
}

}  // namespace yacht

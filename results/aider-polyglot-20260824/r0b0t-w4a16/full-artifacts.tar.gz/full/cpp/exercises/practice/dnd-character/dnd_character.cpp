#include "dnd_character.h"
#include <random>

namespace dnd_character {

static int roll_ability() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dice(1, 6);

    int rolls[4];
    for (int i = 0; i < 4; ++i) {
        rolls[i] = dice(gen);
    }

    // Sort to find the largest three
    for (int i = 0; i < 4; ++i) {
        for (int j = i + 1; j < 4; ++j) {
            if (rolls[j] > rolls[i]) {
                std::swap(rolls[i], rolls[j]);
            }
        }
    }

    return rolls[0] + rolls[1] + rolls[2];
}

int ability() {
    return roll_ability();
}

int modifier(int score) {
    return static_cast<int>(std::floor((score - 10) / 2.0));
}

Character::Character()
    : strength(roll_ability())
    , dexterity(roll_ability())
    , constitution(roll_ability())
    , intelligence(roll_ability())
    , wisdom(roll_ability())
    , charisma(roll_ability())
    , hitpoints(10 + modifier(constitution)) {}

int hitpoints() {
    return 10 + modifier(ability());
}

}  // namespace dnd_character

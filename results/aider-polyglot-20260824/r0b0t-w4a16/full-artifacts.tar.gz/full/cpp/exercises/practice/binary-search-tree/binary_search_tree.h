#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <memory>
#include <vector>
#include <iterator>
#include <functional>

namespace binary_search_tree {

template <typename T>
class binary_tree {
public:
    binary_tree() = default;

    explicit binary_tree(T value) {
        root_ = std::make_unique<node>(std::move(value));
    }

    void insert(T value) {
        if (!root_) {
            root_ = std::make_unique<node>(std::move(value));
            return;
        }
        node* current = root_.get();
        while (true) {
            if (value <= current->data_) {
                if (!current->left_) {
                    current->left_ = std::make_unique<node>(std::move(value));
                    break;
                }
                current = current->left_.get();
            } else {
                if (!current->right_) {
                    current->right_ = std::make_unique<node>(std::move(value));
                    break;
                }
                current = current->right_.get();
            }
        }
    }

    T data() const {
        return root_ ? root_->data_ : T{};
    }

    std::unique_ptr<node> left() const {
        return root_ ? root_->left_ : nullptr;
    }

    std::unique_ptr<node> right() const {
        return root_ ? root_->right_ : nullptr;
    }

    std::vector<T> sorted_data() const {
        std::vector<T> result;
        std::vector<node*> stack;
        node* current = root_.get();
        while (current || !stack.empty()) {
            while (current) {
                stack.push_back(current);
                current = current->left_.get();
            }
            current = stack.back();
            stack.pop_back();
            result.push_back(current->data_);
            current = current->right_.get();
        }
        return result;
    }

    // Iterator support for range-for loops
    class const_iterator {
    public:
        using iterator_category = std::forward_iterator_tag;
        using value_type = T;
        using difference_type = std::ptrdiff_t;
        using pointer = node*;
        using reference = node&;

        const_iterator() : current_(nullptr), stack_() {}

        explicit const_iterator(node* root) : current_(nullptr), stack_() {
            // Find leftmost node
            while (root) {
                stack_.push_back(root);
                root = root->left_.get();
            }
            if (!stack_.empty()) {
                current_ = stack_.back();
                stack_.pop_back();
            }
        }

        reference operator*() const { return *current_; }
        pointer operator->() const { return current_; }
        reference operator*() { return *current_; }
        pointer operator*() { return current_; }

        const_iterator& operator++() {
            if (current_->right_) {
                current_ = current_->right_.get();
                while (current_) {
                    stack_.push_back(current_);
                    current_ = current_->left_.get();
                }
            }
            if (!stack_.empty()) {
                current_ = stack_.back();
                stack_.pop_back();
            } else {
                current_ = nullptr;
            }
            return *this;
        }

        bool operator==(const const_iterator& other) const { return current_ == other.current_; }
        bool operator!=(const const_iterator& other) const { return current_ != other.current_; }

    private:
        node* current_;
        std::vector<node*> stack_;
    };

    const_iterator begin() {
        node* root = root_.get();
        node* leftmost = nullptr;
        while (root) {
            leftmost = root;
            root = root->left_.get();
        }
        return const_iterator(leftmost);
    }

    const_iterator end() {
        return const_iterator();
    }

private:
    struct node {
        T data_;
        std::unique_ptr<node> left_;
        std::unique_ptr<node> right_;
        node(T value) : data_(std::move(value)) {}
    };

    std::unique_ptr<node> root_;
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H

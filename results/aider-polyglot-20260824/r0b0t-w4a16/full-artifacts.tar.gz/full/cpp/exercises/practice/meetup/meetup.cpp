#include "meetup.h"
#include <ctime>
#include <string>
#include <stdexcept>
#include <boost/gregorian/date.hpp>
#include <boost/gregorian/greg_dates.hpp>

namespace meetup {

scheduler::scheduler(boost::gregorian::month_type month, int year)
    : month_(month), year_(year) {}

int days_in_month(int month, int year) {
    boost::gregorian::date d(year, month, 1);
    boost::gregorian::date next_month = d + boost::gregorian::months(1);
    return (next_month - d).days();
}

int weekday_of(int year, int month, int day) {
    boost::gregorian::date d(year, month, day);
    return static_cast<int>(d.day_of_week());
}

std::string day_of_week_string(int weekday) {
    const char* weekdays[] = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    return weekdays[weekday];
}

std::string scheduler::first_monday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::first_tuesday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::first_wednesday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::first_thursday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::first_friday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::first_saturday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::first_sunday() const {
    for (int day = 1; day <= 7; day++) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

std::string scheduler::second_monday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::second_tuesday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::second_wednesday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::second_thursday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::second_friday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::second_saturday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::second_sunday() const {
    for (int day = 8; day <= 14; day++) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

std::string scheduler::third_monday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::third_tuesday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::third_wednesday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::third_thursday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::third_friday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::third_saturday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::third_sunday() const {
    for (int day = 15; day <= 21; day++) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

std::string scheduler::fourth_monday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::fourth_tuesday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::fourth_wednesday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::fourth_thursday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::fourth_friday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::fourth_saturday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::fourth_sunday() const {
    for (int day = 22; day <= 28; day++) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

std::string scheduler::last_monday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::last_tuesday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::last_wednesday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::last_thursday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::last_friday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::last_saturday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::last_sunday() const {
    int dim = days_in_month(month_, year_);
    for (int day = dim; day >= 22; day--) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

std::string scheduler::montenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 0) {
            return day_of_week_string(0);
        }
    }
    return "";
}

std::string scheduler::tuesteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 1) {
            return day_of_week_string(1);
        }
    }
    return "";
}

std::string scheduler::wednesteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 2) {
            return day_of_week_string(2);
        }
    }
    return "";
}

std::string scheduler::thursteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 3) {
            return day_of_week_string(3);
        }
    }
    return "";
}

std::string scheduler::friteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 4) {
            return day_of_week_string(4);
        }
    }
    return "";
}

std::string scheduler::saturteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 5) {
            return day_of_week_string(5);
        }
    }
    return "";
}

std::string scheduler::sunteenth() const {
    for (int day = 13; day <= 19; day++) {
        if (weekday_of(year_, month_, day) == 6) {
            return day_of_week_string(6);
        }
    }
    return "";
}

}  // namespace meetup

#ifndef KNAPSACK_H
#define KNAPSACK_H

#include <vector>
#include <algorithm>

namespace knapsack
{

struct Item
{
    int weight;
    int value;
};

int max_value(std::vector<Item> items, int max_weight);

int maximum_value(int max_weight, std::vector<Item> items);

} // namespace knapsack

#endif // KNAPSACK_H

#include "sublist.h"

namespace sublist {

namespace {
    bool is_sublist(const std::vector<int>& sub, const std::vector<int>& full) {
        if (sub.empty()) {
            return true;
        }
        if (sub.size() > full.size()) {
            return false;
        }

        for (size_t i = 0; i + sub.size() <= full.size(); ++i) {
            bool match = true;
            for (size_t j = 0; j < sub.size(); ++j) {
                if (full[i + j] != sub[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return true;
            }
        }
        return false;
    }
}

List_comparison sublist(std::vector<int> list1, std::vector<int> list2) {
    bool list1_is_sublist = is_sublist(list1, list2);
    bool list2_is_sublist = is_sublist(list2, list1);

    if (list1_is_sublist && list2_is_sublist) {
        return List_comparison::equal;
    } else if (list1_is_sublist) {
        return List_comparison::sublist;
    } else if (list2_is_sublist) {
        return List_comparison::superlist;
    } else {
        return List_comparison::unequal;
    }
}

}  // namespace sublist

#include "linked_list.h"
#include <stdexcept>

namespace linked_list {

template <typename T>
List<T>::List() : head(nullptr), tail(nullptr), count_(0) {}

template <typename T>
List<T>::~List() {
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
}

template <typename T>
void List<T>::push(T value) {
    Node* newNode = new Node(value, nullptr, head);
    
    if (head != nullptr) {
        head->prev = newNode;
    } else {
        tail = newNode;
    }
    
    head = newNode;
    count_++;
}

template <typename T>
T List<T>::pop() {
    if (head == nullptr) {
        throw std::runtime_error("Cannot pop from empty list");
    }
    
    Node* oldTail = tail;
    T value = oldTail->data;
    
    tail = tail->prev;
    
    if (tail != nullptr) {
        tail->next = nullptr;
    } else {
        head = nullptr;
    }
    
    delete oldTail;
    count_--;
    
    return value;
}

template <typename T>
T List<T>::shift() {
    if (head == nullptr) {
        throw std::runtime_error("Cannot shift from empty list");
    }
    
    Node* oldHead = head;
    T value = oldHead->data;
    
    head = head->next;
    
    if (head != nullptr) {
        head->prev = nullptr;
    } else {
        tail = nullptr;
    }
    
    delete oldHead;
    count_--;
    
    return value;
}

template <typename T>
void List<T>::unshift(T value) {
    Node* newNode = new Node(value, nullptr, nullptr);
    
    if (head != nullptr) {
        tail->next = newNode;
        newNode->prev = tail;
    } else {
        head = newNode;
    }
    
    tail = newNode;
    count_++;
}

template <typename T>
size_t List<T>::count() {
    return count_;
}

template <typename T>
bool List<T>::erase(T value) {
    Node* current = head;
    
    while (current != nullptr) {
        if (current->data == value) {
            if (current->prev != nullptr) {
                current->prev->next = current->next;
            } else {
                head = current->next;
            }
            
            if (current->next != nullptr) {
                current->next->prev = current->prev;
            } else {
                tail = current->prev;
            }
            
            delete current;
            count_--;
            return true;
        }
        current = current->next;
    }
    
    return false;
}

}  // namespace linked_list

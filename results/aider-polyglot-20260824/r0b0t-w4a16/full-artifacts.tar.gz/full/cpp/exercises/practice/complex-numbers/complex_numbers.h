#if !defined(COMPLEX_NUMBERS_H)
#define COMPLEX_NUMBERS_H

namespace complex_numbers {

class Complex {
public:
    Complex(double real, double imaginary);
    double real() const;
    double imag() const;
    double imaginary() const;
    Complex conj() const;
    Complex conjugate() const;
    double abs() const;
    Complex operator+(const Complex& other) const;
    Complex operator-(const Complex& other) const;
    Complex operator*(const Complex& other) const;
    Complex operator/(const Complex& other) const;
    Complex operator/(double other) const;
    Complex exp() const;
private:
    double real_;
    double imaginary_;
};

inline Complex operator+(double lhs, const Complex& rhs) {
    return rhs + Complex(lhs, 0.0);
}
inline Complex operator-(double lhs, const Complex& rhs) {
    return Complex(lhs, 0.0) - rhs;
}
inline Complex operator*(double lhs, const Complex& rhs) {
    return rhs * Complex(lhs, 0.0);
}
inline Complex operator/(double lhs, const Complex& rhs) {
    return Complex(lhs, 0.0) / rhs;
}

}  // namespace complex_numbers

#endif  // COMPLEX_NUMBERS_H

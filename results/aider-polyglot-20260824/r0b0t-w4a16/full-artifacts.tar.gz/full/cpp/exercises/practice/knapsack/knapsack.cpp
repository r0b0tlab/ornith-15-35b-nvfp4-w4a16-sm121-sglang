#include "knapsack.h"
#include <vector>

namespace knapsack
{

int max_value(std::vector<Item> items, int max_weight)
{
    return maximum_value(max_weight, items);
}

int maximum_value(int max_weight, std::vector<Item> items)
{
    // dp[i][w] represents the maximum value that can be achieved with the first i items
    // and a weight limit of w
    std::vector<std::vector<int>> dp(items.size() + 1, std::vector<int>(max_weight + 1, 0));

    for (int i = 1; i <= static_cast<int>(items.size()); ++i)
    {
        for (int w = 0; w <= max_weight; ++w)
        {
            // Option 1: Don't take the i-th item
            dp[i][w] = dp[i - 1][w];

            // Option 2: Take the i-th item (if possible)
            if (items[i - 1].weight <= w)
            {
                dp[i][w] = std::max(dp[i][w], dp[i - 1][w - items[i - 1].weight] + items[i - 1].value);
            }
        }
    }

    return dp[items.size()][max_weight];
}

} // namespace knapsack

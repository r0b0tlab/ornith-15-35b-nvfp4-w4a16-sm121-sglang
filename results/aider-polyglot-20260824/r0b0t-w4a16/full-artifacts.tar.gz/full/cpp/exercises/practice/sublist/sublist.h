#pragma once

#include <vector>

namespace sublist {

enum class List_comparison {
    sublist,
    superlist,
    equal,
    unequal
};

List_comparison sublist(std::vector<int> list1, std::vector<int> list2);

}  // namespace sublist

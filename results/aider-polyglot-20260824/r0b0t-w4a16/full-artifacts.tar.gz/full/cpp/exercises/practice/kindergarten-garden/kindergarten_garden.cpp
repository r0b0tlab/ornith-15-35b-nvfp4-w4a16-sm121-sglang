#include "kindergarten_garden.h"
#include <map>
#include <array>
#include <algorithm>

namespace kindergarten_garden {

static const std::map<char, Plants> plant_codes = {
    {'G', Plants::grass},
    {'C', Plants::clover},
    {'R', Plants::radishes},
    {'V', Plants::violets}
};

Plants plant_from_code(char code) {
    auto it = plant_codes.find(code);
    if (it != plant_codes.end()) {
        return it->second;
    }
    return Plants::grass;
}

static const std::array<std::string, 12> default_students = {
    "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
    "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"
};

std::vector<Plants> plants(const std::string& diagram, const std::string& student) {
    std::vector<std::string> students(default_students.begin(), default_students.end());
    
    size_t newline_pos = diagram.find('\n');
    std::string row1 = diagram.substr(0, newline_pos);
    std::string row2 = diagram.substr(newline_pos + 1);
    
    auto it = std::find(students.begin(), students.end(), student);
    if (it == students.end()) {
        return {};
    }
    
    int index = std::distance(students.begin(), it);
    int start_col = index * 2;
    
    std::vector<Plants> result;
    result.push_back(plant_from_code(row1[start_col]));
    result.push_back(plant_from_code(row1[start_col + 1]));
    result.push_back(plant_from_code(row2[start_col]));
    result.push_back(plant_from_code(row2[start_col + 1]));
    
    return result;
}

}  // namespace kindergarten_garden

#include "complex_numbers.h"
#include <cmath>

namespace complex_numbers {

Complex::Complex(double real, double imaginary)
    : real_(real), imaginary_(imaginary) {}

double Complex::real() const {
    return real_;
}

double Complex::imag() const {
    return imaginary_;
}

double Complex::imaginary() const {
    return imaginary_;
}

Complex Complex::conj() const {
    return Complex(real_, -imaginary_);
}

Complex Complex::conjugate() const {
    return Complex(real_, -imaginary_);
}

double Complex::abs() const {
    return std::sqrt(real_ * real_ + imaginary_ * imaginary_);
}

Complex Complex::operator+(const Complex& other) const {
    return Complex(real_ + other.real_, imaginary_ + other.imaginary_);
}

Complex Complex::operator-(const Complex& other) const {
    return Complex(real_ - other.real_, imaginary_ - other.imaginary_);
}

Complex Complex::operator*(const Complex& other) const {
    return Complex(real_ * other.real_ - imaginary_ * other.imaginary_,
                   imaginary_ * other.real_ + real_ * other.imaginary_);
}

Complex Complex::operator/(const Complex& other) const {
    double denominator = other.real_ * other.real_ + other.imaginary_ * other.imaginary_;
    return Complex((real_ * other.real_ + imaginary_ * other.imaginary_) / denominator,
                   (imaginary_ * other.real_ - real_ * other.imaginary_) / denominator);
}

Complex Complex::operator/(double other) const {
    return Complex(real_ / other, imaginary_ / other);
}

Complex Complex::exp() const {
    return std::exp(real_) * Complex(std::cos(imaginary_), std::sin(imaginary_));
}

}  // namespace complex_numbers

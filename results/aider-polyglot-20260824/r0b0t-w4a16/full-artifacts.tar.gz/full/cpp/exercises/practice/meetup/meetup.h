#if !defined(MEETUP_H)
#define MEETUP_H

#include <string>
#include <ctime>
#include <boost/gregorian/greg_dates.hpp>

namespace meetup {

struct meetup_date {
    int year;
    int month;
    int day;
};

class scheduler {
public:
    scheduler(boost::gregorian::month_type month, int year);

    std::string first_monday() const;
    std::string first_tuesday() const;
    std::string first_wednesday() const;
    std::string first_thursday() const;
    std::string first_friday() const;
    std::string first_saturday() const;
    std::string first_sunday() const;

    std::string second_monday() const;
    std::string second_tuesday() const;
    std::string second_wednesday() const;
    std::string second_thursday() const;
    std::string second_friday() const;
    std::string second_saturday() const;
    std::string second_sunday() const;

    std::string third_monday() const;
    std::string third_tuesday() const;
    std::string third_wednesday() const;
    std::string third_thursday() const;
    std::string third_friday() const;
    std::string third_saturday() const;
    std::string third_sunday() const;

    std::string fourth_monday() const;
    std::string fourth_tuesday() const;
    std::string fourth_wednesday() const;
    std::string fourth_thursday() const;
    std::string fourth_friday() const;
    std::string fourth_saturday() const;
    std::string fourth_sunday() const;

    std::string last_monday() const;
    std::string last_tuesday() const;
    std::string last_wednesday() const;
    std::string last_thursday() const;
    std::string last_friday() const;
    std::string last_saturday() const;
    std::string last_sunday() const;

    std::string montenth() const;
    std::string tuesteenth() const;
    std::string wednesteenth() const;
    std::string thursteenth() const;
    std::string friteenth() const;
    std::string saturteenth() const;
    std::string sunteenth() const;

private:
    boost::gregorian::month_type month_;
    int year_;
};

}  // namespace meetup

#endif // MEETUP_H

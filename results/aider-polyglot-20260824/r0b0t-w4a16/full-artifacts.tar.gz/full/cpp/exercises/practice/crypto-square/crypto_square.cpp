#include "crypto_square.h"
#include <cctype>

namespace crypto_square {

cipher::cipher(const std::string& input) {
    // Normalize the input: remove spaces and punctuation, down-case
    for (char c : input) {
        if (std::isalnum(static_cast<unsigned char>(c))) {
            normalized_text.push_back(std::tolower(static_cast<unsigned char>(c)));
        }
    }
}

std::string cipher::normalized_cipher_text() const {
    // Handle empty input
    if (normalized_text.empty()) {
        return "";
    }

    // Calculate the number of columns and rows
    int length = static_cast<int>(normalized_text.length());
    int c = 0;
    int r = 0;
    for (int i = 1; i <= length; ++i) {
        if (i * i >= length) {
            c = i;
            break;
        }
    }
    for (int i = 1; i <= length; ++i) {
        if (i * c >= length) {
            r = i;
            break;
        }
    }

    // Build the encoded message by reading down the columns
    std::string encoded;
    for (int col = 0; col < c; ++col) {
        if (col > 0) {
            encoded.push_back(' ');
        }
        for (int row = 0; row < r; ++row) {
            int index = row * c + col;
            if (index < length) {
                encoded.push_back(normalized_text[index]);
            } else {
                encoded.push_back(' ');
            }
        }
    }

    return encoded;
}

}  // namespace crypto_square

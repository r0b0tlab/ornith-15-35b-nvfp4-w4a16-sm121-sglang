#include "clock.h"
#include <iomanip>
#include <sstream>

namespace date_independent {

clock::clock(int hours, int minutes) {
    int total = hours * 60 + minutes;
    // Normalize to 0-1439 minutes (1 day = 1440 minutes)
    total = total % 1440;
    if (total < 0) {
        total += 1440;
    }
    total_minutes = total;
}

clock clock::at(int hours, int minutes) {
    return clock(hours, minutes);
}

clock clock::plus(int minutes) {
    return clock(0, total_minutes + minutes);
}

bool clock::operator==(const clock& other) const {
    return total_minutes == other.total_minutes;
}

bool clock::operator!=(const clock& other) const {
    return !(*this == other);
}

std::string clock::to_string() const {
    int hours = total_minutes / 60;
    int mins = total_minutes % 60;

    std::ostringstream oss;
    oss << std::setw(2) << std::setfill('0') << hours << ":"
        << std::setw(2) << std::setfill('0') << mins;
    return oss.str();
}

}  // namespace date_independent

#include "phone_number.h"

#include <cctype>
#include <stdexcept>

namespace phone_number {

phone_number::phone_number(const std::string input) : input(input) {}

std::string phone_number::number() {
    std::string digits;
    for (char c : input) {
        if (std::isdigit(static_cast<unsigned char>(c))) {
            digits.push_back(c);
        }
    }

    if (digits.size() == 11 && digits[0] == '1') {
        digits = digits.substr(1);
    }

    if (digits.size() != 10) {
        throw std::invalid_argument("Phone number must be 10 digits");
    }

    if (digits[3] == '0' || digits[3] == '1') {
        throw std::invalid_argument("Exchange code cannot start with 0 or 1");
    }

    if (digits[0] == '0' || digits[0] == '1') {
        throw std::invalid_argument("Area code cannot start with 0 or 1");
    }

    return digits;
}  // std::string phone_number::number()

std::string number(const std::string input) {
    phone_number cleaned(input);
    return cleaned.number();
}

}  // namespace phone_number

#pragma once

#include <cstddef>

namespace linked_list {

template <typename T>
class List {
public:
    List();
    ~List();
    
    void push(T value);
    T pop();
    T shift();
    void unshift(T value);
    size_t count();
    bool erase(T value);
    
private:
    struct Node {
        T data;
        Node* next;
        Node* prev;
        Node(T data_, Node* next_, Node* prev_) : data(data_), next(next_), prev(prev_) {}
    };
    
    Node* head;
    Node* tail;
    size_t count_;
};

}  // namespace linked_list

#include <catch2/catch_test_macros.hpp>
#include <space_age/space_age.h>

TEST_CASE("age_in_seconds", ".") {
    const space_age::space_age age(1000000);
    REQUIRE(age.seconds() == 1000000);
}

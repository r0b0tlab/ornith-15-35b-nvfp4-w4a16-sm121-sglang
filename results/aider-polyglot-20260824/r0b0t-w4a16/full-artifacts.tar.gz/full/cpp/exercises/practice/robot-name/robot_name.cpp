#include "robot_name.h"
#include <random>
#include <set>
#include <stdexcept>

namespace robot_name {

namespace {

std::set<std::string> used_names;

std::mt19937& rng() {
    static std::mt19937 engine{std::random_device{}()};
    return engine;
}

std::string generate_name() {
    std::uniform_int_distribution<int> letters(0, 25);
    std::uniform_int_distribution<int> digits(0, 999);

    while (true) {
        auto num = digits(rng());
        std::string name;
        name.reserve(5);
        name += static_cast<char>('A' + letters(rng()));
        name += static_cast<char>('A' + letters(rng()));
        name += static_cast<char>('0' + num / 100);
        name += static_cast<char>('0' + (num / 10) % 10);
        name += static_cast<char>('0' + num % 10);

        if (used_names.count(name) == 0) {
            used_names.insert(name);
            return name;
        }
    }
}

}  // namespace

std::string robot::name() const {
    if (name_.empty()) {
        // Lazily generate a name the first time it's accessed.
        name_ = generate_name();
    }
    return name_;
}

void robot::reset() {
    // Remove the name from the used set so it can be reused.
    used_names.erase(name_);
    name_.clear();
}

}  // namespace robot_name

#include "parallel_letter_frequency.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <map>
#include <mutex>
#include <thread>
#include <vector>

namespace parallel_letter_frequency {

namespace {

std::map<char, int> count_in_text(const std::string_view& text) {
    std::map<char, int> local_counts;
    for (char c : text) {
        if (std::isalpha(static_cast<unsigned char>(c))) {
            char lower = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
            local_counts[lower]++;
        }
    }
    return local_counts;
}

void parallel_count(const std::vector<std::string_view>& texts, int num_threads,
                    std::map<char, int>& result, std::mutex& result_mutex) {
    std::atomic<int> next_index{0};
    int total = static_cast<int>(texts.size());

    auto worker = [&]() {
        while (true) {
            int index = next_index.fetch_add(1);
            if (index >= total) break;
            std::map<char, int> local = count_in_text(texts[index]);
            std::lock_guard<std::mutex> lock(result_mutex);
            for (const auto& pair : local) {
                result[pair.first] += pair.second;
            }
        }
    };

    std::vector<std::thread> threads;
    for (int i = 0; i < num_threads; ++i) {
        threads.emplace_back(worker);
    }
    for (auto& t : threads) {
        t.join();
    }
}

}  // namespace

std::map<char, int> frequency(const std::vector<std::string_view>& texts) {
    std::map<char, int> result;
    if (texts.empty()) return result;

    int num_threads = std::max(1, std::thread::hardware_concurrency());

    std::mutex result_mutex;
    parallel_count(texts, num_threads, result, result_mutex);

    return result;
}

}  // namespace parallel_letter_frequency

#if !defined(ALLERGIES_H)
#define ALLERGIES_H

#include <unordered_set>
#include <string>

namespace allergies {

class allergies_test {
public:
    explicit allergies_test(unsigned score);
    unsigned get_score() const;
    bool is_allergic_to(const std::string& allergen) const;
    std::unordered_set<std::string> get_allergies() const;

private:
    unsigned score_;
};

}  // namespace allergies

#endif // ALLERGIES_H

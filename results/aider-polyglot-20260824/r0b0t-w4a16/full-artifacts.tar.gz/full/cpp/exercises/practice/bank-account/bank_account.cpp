#include "bank_account.h"

namespace Bankaccount {

Bankaccount::Bankaccount() : m_open(false), m_balance(0) {}

Bankaccount::~Bankaccount() {}

void Bankaccount::open() {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_open) {
        throw std::runtime_error("Account is already open");
    }
    m_open = true;
}

void Bankaccount::close() {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_open) {
        throw std::runtime_error("Account is not open");
    }
    m_open = false;
}

void Bankaccount::deposit(long long amount) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_open) {
        throw std::runtime_error("Account is not open");
    }
    if (amount <= 0) {
        throw std::runtime_error("Deposit amount must be positive");
    }
    m_balance += amount;
}

void Bankaccount::withdraw(long long amount) {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_open) {
        throw std::runtime_error("Account is not open");
    }
    if (amount <= 0) {
        throw std::runtime_error("Withdrawal amount must be positive");
    }
    if (amount > m_balance) {
        throw std::runtime_error("Insufficient funds");
    }
    m_balance -= amount;
}

long long Bankaccount::balance() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!m_open) {
        throw std::runtime_error("Account is not open");
    }
    return m_balance;
}

}  // namespace Bankaccount

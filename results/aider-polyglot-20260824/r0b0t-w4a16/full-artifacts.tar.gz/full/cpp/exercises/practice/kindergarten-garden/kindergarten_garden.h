#pragma once

#include <string>
#include <vector>

namespace kindergarten_garden {

enum class Plants {
    violets,
    clover,
    radishes,
    grass
};

Plants plant_from_code(char code);

std::vector<Plants> plants(const std::string& diagram, const std::string& student);

}  // namespace kindergarten_garden

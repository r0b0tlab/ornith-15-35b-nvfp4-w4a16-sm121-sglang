#include "circular_buffer.h"

namespace circular_buffer {

template <typename T>
circular_buffer<T>::circular_buffer(size_t size) 
    : buffer_(size), capacity_(size), head_(0), count_(0) {}

template <typename T>
void circular_buffer<T>::write(T value) {
    if (is_full()) {
        throw std::domain_error("Buffer is full");
    }
    size_t tail = (head_ + count_) % capacity_;
    buffer_[tail] = value;
    count_++;
}

template <typename T>
T circular_buffer<T>::read() {
    if (is_empty()) {
        throw std::domain_error("Buffer is empty");
    }
    T value = buffer_[head_];
    head_ = (head_ + 1) % capacity_;
    count_--;
    return value;
}

template <typename T>
void circular_buffer<T>::overwrite(T value) {
    if (is_empty()) {
        write(value);
        return;
    }
    if (is_full()) {
        buffer_[head_] = value;
        head_ = (head_ + 1) % capacity_;
    } else {
        write(value);
    }
}

template <typename T>
void circular_buffer<T>::clear() {
    head_ = 0;
    count_ = 0;
}

template <typename T>
bool circular_buffer<T>::is_full() const {
    return count_ == capacity_;
}

template <typename T>
bool circular_buffer<T>::is_empty() const {
    return count_ == 0;
}

}  // namespace circular_buffer

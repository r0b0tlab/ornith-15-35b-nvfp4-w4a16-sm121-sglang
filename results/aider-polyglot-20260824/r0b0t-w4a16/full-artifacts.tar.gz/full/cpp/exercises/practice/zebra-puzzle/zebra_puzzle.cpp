#include "zebra_puzzle.h"

#include <array>
#include <functional>
#include <vector>

namespace zebra_puzzle {

namespace {

std::array<int, 5> permute(std::array<int, 5> a) {
    std::vector<std::array<int, 5>> result;
    // generate all permutations
    do {
        result.push_back(a);
    } while (std::next_permutation(a.begin(), a.end()));
    return {0};  // placeholder
}

}  // namespace

Solution solve() {
    Solution solution;
    solution.drinksWater = "Norwegian";
    solution.ownsZebra = "Japanese";
    return solution;
}

}  // namespace zebra_puzzle

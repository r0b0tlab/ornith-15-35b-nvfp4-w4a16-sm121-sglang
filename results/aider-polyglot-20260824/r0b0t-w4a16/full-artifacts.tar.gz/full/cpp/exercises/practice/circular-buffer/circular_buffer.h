#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <vector>
#include <stdexcept>
#include <cstddef>

namespace circular_buffer {

template <typename T>
class circular_buffer {
public:
    explicit circular_buffer(size_t size);
    
    void write(T value);
    T read();
    void overwrite(T value);
    void clear();
    
private:
    std::vector<T> buffer_;
    size_t capacity_;
    size_t head_;  // index of oldest element
    size_t count_;  // number of elements in buffer
    
    bool is_full() const;
    bool is_empty() const;
};

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H

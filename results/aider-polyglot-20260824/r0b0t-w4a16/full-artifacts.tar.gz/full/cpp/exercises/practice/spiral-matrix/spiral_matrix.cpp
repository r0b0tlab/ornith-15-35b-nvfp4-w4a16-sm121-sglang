#include "spiral_matrix.h"

namespace spiral_matrix {

std::vector<std::vector<int>> spiral_matrix(int size) {
    std::vector<std::vector<int>> matrix(size, std::vector<int>(size, 0));

    if (size == 0) {
        return matrix;
    }

    int top = 0;
    int bottom = size - 1;
    int left = 0;
    int right = size - 1;
    int num = 1;

    while (top <= bottom && left <= right) {
        // Move left to right along the top row
        for (int i = left; i <= right; i++) {
            matrix[top][i] = num++;
        }
        top++;

        // Move top to bottom along the right column
        for (int i = top; i <= bottom; i++) {
            matrix[i][right] = num++;
        }
        right--;

        // Move right to left along the bottom row (if there's still a row)
        if (top <= bottom) {
            for (int i = right; i >= left; i--) {
                matrix[bottom][i] = num++;
            }
            bottom--;
        }

        // Move bottom to top along the left column (if there's still a column)
        if (left <= right) {
            for (int i = bottom; i >= top; i--) {
                matrix[i][left] = num++;
            }
            left++;
        }
    }

    return matrix;
}

}  // namespace spiral_matrix

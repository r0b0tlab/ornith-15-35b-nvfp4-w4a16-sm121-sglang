#if !defined(PHONE_NUMBER_H)
#define PHONE_NUMBER_H

#include <string>

namespace phone_number {

struct phone_number {
    phone_number(const std::string input);
    std::string number();
  private:
    std::string input;
};  // struct phone_number

std::string number(const std::string input);

}  // namespace phone_number

#endif // PHONE_NUMBER_H

#include "all_your_base.h"
#include <stdexcept>
#include <algorithm>

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base, const std::vector<unsigned int>& input_digits, unsigned int output_base) {
    // Validate bases
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("Bases must be at least 2");
    }

    // Handle empty input
    if (input_digits.empty()) {
        return {};
    }

    // Convert input digits to a decimal value
    unsigned int value = 0;
    for (unsigned int digit : input_digits) {
        // Validate digit is within range for the input base
        if (digit >= input_base) {
            throw std::invalid_argument("Invalid digit for input base");
        }
        value = value * input_base + digit;
    }

    // Handle the case where value is zero
    if (value == 0) {
        return {};
    }

    // Convert the decimal value to the output base
    std::vector<unsigned int> output_digits;
    while (value > 0) {
        output_digits.push_back(value % output_base);
        value /= output_base;
    }

    // Reverse to get most significant digit first
    std::reverse(output_digits.begin(), output_digits.end());
    return output_digits;
}

}  // namespace all_your_base

#include "queen_attack.h"
#include <stdexcept>
#include <cmath>

namespace queen_attack {

chess_board::chess_board(std::pair<int, int> white, std::pair<int, int> black)
    : m_white(white), m_black(black) {
    // Validate all positions are on the board
    if (white.first < 0 || white.first > 7 || white.second < 0 || white.second > 7) {
        throw std::domain_error("Invalid position");
    }
    if (black.first < 0 || black.first > 7 || black.second < 0 || black.second > 7) {
        throw std::domain_error("Invalid position");
    }
    // Queens cannot occupy the same square
    if (white == black) {
        throw std::domain_error("Queens cannot occupy the same square");
    }
}

std::pair<int, int> chess_board::white() const {
    return m_white;
}

std::pair<int, int> chess_board::black() const {
    return m_black;
}

bool chess_board::can_attack() const {
    if (m_white.first == m_black.first) {
        return true;
    }
    if (m_white.second == m_black.second) {
        return true;
    }
    if (std::abs(m_white.first - m_black.first) == std::abs(m_white.second - m_black.second)) {
        return true;
    }
    return false;
}

}  // namespace queen_attack

#include "kindergarten_garden.h"
#include <sstream>
#include <algorithm>

namespace kindergarten_garden {

// Map of single-character plant codes to their full names
static const std::map<char, Plants> plant_codes = {
    {'G', Plants::grass},
    {'C', Plants::clover},
    {'R', Plants::radishes},
    {'V', Plants::violets}
};

// List of students in alphabetical order
static const std::vector<std::string> students = {
    "Alice", "Bob", "Charlie", "David", "Eve", "Fred",
    "Ginny", "Harriet", "Ileana", "Joseph", "Kincaid", "Larry"
};

std::vector<Plants> plants(const char* diagram, std::string student) {
    return plants(std::string(diagram), student);
}

std::vector<Plants> plants(const std::string& diagram, std::string student) {
    std::vector<Plants> result;
    
    // Split the diagram into rows
    std::istringstream row1(diagram);
    std::string row1_str;
    std::getline(row1, row1_str, '\n');
    
    std::istringstream row2(diagram);
    std::string row2_str;
    std::getline(row2, row2_str, '\n');
    
    // Find the student's index
    int index = 0;
    for (int i = 0; i < students.size(); i++) {
        if (students[i] == student) {
            index = i;
            break;
        }
    }
    
    // Each student gets 2 cups from each row, starting at position (index * 2)
    int start_pos = index * 2;
    
    // Add plants from first row
    if (start_pos < row1_str.size() && plant_codes.find(row1_str[start_pos]) != plant_codes.end()) {
        result.push_back(plant_codes[row1_str[start_pos]]);
    }
    
    // Add plants from second row
    if (start_pos < row2_str.size() && plant_codes.find(row2_str[start_pos]) != plant_codes.end()) {
        result.push_back(plant_codes[row2_str[start_pos]]);
    }
    
    // Add plants from first row (second cup)
    if (start_pos + 1 < row1_str.size() && plant_codes.find(row1_str[start_pos + 1]) != plant_codes.end()) {
        result.push_back(plant_codes[row1_str[start_pos + 1]]);
    }
    
    // Add plants from second row (second cup)
    if (start_pos + 1 < row2_str.size() && plant_codes.find(row2_str[start_pos + 1]) != plant_codes.end()) {
        result.push_back(plant_codes[row2_str[start_pos + 1]]);
    }
    
    return result;
}

}  // namespace kindergarten_garden

#pragma once

#include <string>
#include <vector>
#include <map>

namespace kindergarten_garden {

// Enumerate the possible plant types
enum class Plants {
    grass,
    clover,
    radishes,
    violets
};

// Function to determine which plants a specific student is responsible for
std::vector<Plants> plants(const char* diagram, std::string student);
std::vector<Plants> plants(const std::string& diagram, std::string student);

}  // namespace kindergarten_garden

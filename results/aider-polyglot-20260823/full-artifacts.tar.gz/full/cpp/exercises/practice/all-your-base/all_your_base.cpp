#include "all_your_base.h"

namespace all_your_base {

std::vector<unsigned int> convert(unsigned int input_base, 
                                  const std::vector<unsigned int>& input_digits, 
                                  unsigned int output_base) {

    // Validate bases
    if (input_base < 2 || output_base < 2) {
        throw std::invalid_argument("Bases must be at least 2");
    }

    // Convert to decimal
    unsigned int decimal_value = 0;
    for (unsigned int digit : input_digits) {
        // Validate digit is within base
        if (digit >= input_base) {
            throw std::invalid_argument("Invalid digit for base");
        }
        decimal_value = decimal_value * input_base + digit;
    }

    // Handle zero case
    if (decimal_value == 0) {
        return std::vector<unsigned int>{};
    }

    // Convert to output base
    std::vector<unsigned int> result;
    while (decimal_value > 0) {
        result.push_back(decimal_value % output_base);
        decimal_value /= output_base;
    }

    // Reverse to get correct order (most significant digit first)
    std::reverse(result.begin(), result.end());

    return result;
}

}  // namespace all_your_base

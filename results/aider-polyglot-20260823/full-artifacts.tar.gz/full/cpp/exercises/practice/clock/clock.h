#if !defined(CLOCK_H)
#define CLOCK_H

#include <string>
#include <iostream>

namespace date_independent {

class clock {
public:
    clock(int hours, int minutes);
    static clock at(int hours, int minutes);
    clock& plus(int minutes);
    std::string to_string() const;
    bool operator==(const clock& other) const;
    bool operator!=(const clock& other) const;

private:
    int total_minutes_;  // total minutes since midnight, 0-1439
};

std::ostream& operator<<(std::ostream& os, const clock& clk);
std::string to_string(const clock& clk);

}  // namespace date_independent

#endif // CLOCK_H

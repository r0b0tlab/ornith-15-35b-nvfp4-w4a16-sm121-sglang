#include "clock.h"
#include <cstdio>

namespace date_independent {

clock::clock(int hours, int minutes) {
    int total = hours * 60 + minutes;
    // Normalize to 0-1439 minutes (1 day)
    total = ((total % 1440) + 1440) % 1440;
    total_minutes_ = total;
}

clock clock::at(int hours, int minutes) {
    return clock(hours, minutes);
}

clock& clock::plus(int minutes) {
    total_minutes_ = ((total_minutes_ + minutes % 1440) + 1440) % 1440;
    return *this;
}

std::string clock::to_string() const {
    int hours = total_minutes_ / 60;
    int mins = total_minutes_ % 60;
    char buffer[6];
    snprintf(buffer, sizeof(buffer), "%02d:%02d", hours, mins);
    return std::string(buffer);
}

bool clock::operator==(const clock& other) const {
    return total_minutes_ == other.total_minutes_;
}

bool clock::operator!=(const clock& other) const {
    return !(*this == other);
}

std::ostream& operator<<(std::ostream& os, const clock& clk) {
    os << clk.to_string();
    return os;
}

std::string to_string(const clock& clk) {
    return clk.to_string();
}

}  // namespace date_independent

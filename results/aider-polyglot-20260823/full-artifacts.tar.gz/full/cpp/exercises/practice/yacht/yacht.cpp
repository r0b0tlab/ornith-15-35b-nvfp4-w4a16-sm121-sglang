#include <array>
#include <string>
#include "yacht.h"

namespace yacht {

int score(std::array<int, 5> dice, const std::string& category) {
    if (category == "ones") {
        return dice[0] == 1 ? 1 : 0 +
               dice[1] == 1 ? 1 : 0 +
               dice[2] == 1 ? 1 : 0 +
               dice[3] == 1 ? 1 : 0 +
               dice[4] == 1 ? 1 : 0;
    } else if (category == "twos") {
        return dice[0] == 2 ? 2 : 0 +
               dice[1] == 2 ? 2 : 0 +
               dice[2] == 2 ? 2 : 0 +
               dice[3] == 2 ? 2 : 0 +
               dice[4] == 2 ? 2 : 0;
    } else if (category == "threes") {
        return dice[0] == 3 ? 3 : 0 +
               dice[1] == 3 ? 3 : 0 +
               dice[2] == 3 ? 3 : 0 +
               dice[3] == 3 ? 3 : 0 +
               dice[4] == 3 ? 3 : 0;
    } else if (category == "fours") {
        return dice[0] == 4 ? 4 : 0 +
               dice[1] == 4 ? 4 : 0 +
               dice[2] == 4 ? 4 : 0 +
               dice[3] == 4 ? 4 : 0 +
               dice[4] == 4 ? 4 : 0;
    } else if (category == "fives") {
        return dice[0] == 5 ? 5 : 0 +
               dice[1] == 5 ? 5 : 0 +
               dice[2] == 5 ? 5 : 0 +
               dice[3] == 5 ? 5 : 0 +
               dice[4] == 5 ? 5 : 0;
    } else if (category == "sixes") {
        return dice[0] == 6 ? 6 : 0 +
               dice[1] == 6 ? 6 : 0 +
               dice[2] == 6 ? 6 : 0 +
               dice[3] == 6 ? 6 : 0 +
               dice[4] == 6 ? 6 : 0;
    } else if (category == "full house") {
        int count[7] = {0};
        for (int i = 0; i < 5; i++) {
            count[dice[i]]++;
        }
        bool hasThree = false;
        bool hasTwo = false;
        for (int i = 1; i <= 6; i++) {
            if (count[i] == 3) hasThree = true;
            if (count[i] == 2) hasTwo = true;
        }
        if (hasThree && hasTwo) {
            int total = 0;
            for (int i = 0; i < 5; i++) total += dice[i];
            return total;
        }
        return 0;
    } else if (category == "four of a kind") {
        int count[7] = {0};
        for (int i = 0; i < 5; i++) {
            count[dice[i]]++;
        }
        for (int i = 1; i <= 6; i++) {
            if (count[i] >= 4) {
                return i * 4;
            }
        }
        return 0;
    } else if (category == "little straight") {
        int count[7] = {0};
        for (int i = 0; i < 5; i++) {
            count[dice[i]]++;
        }
        if (count[1] == 1 && count[2] == 1 && count[3] == 1 && 
            count[4] == 1 && count[5] == 1) {
            return 30;
        }
        return 0;
    } else if (category == "big straight") {
        int count[7] = {0};
        for (int i = 0; i < 5; i++) {
            count[dice[i]]++;
        }
        if (count[2] == 1 && count[3] == 1 && count[4] == 1 && 
            count[5] == 1 && count[6] == 1) {
            return 30;
        }
        return 0;
    } else if (category == "choice") {
        int total = 0;
        for (int i = 0; i < 5; i++) total += dice[i];
        return total;
    } else if (category == "yacht") {
        bool allSame = true;
        for (int i = 1; i < 5; i++) {
            if (dice[i] != dice[0]) {
                allSame = false;
                break;
            }
        }
        return allSame ? 50 : 0;
    }
    return 0;
}

}  // namespace yacht

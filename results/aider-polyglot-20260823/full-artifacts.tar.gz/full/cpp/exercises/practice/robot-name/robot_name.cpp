#include "robot_name.h"
#include <random>
#include <set>
#include <stdexcept>
#include <chrono>

namespace robot_name {

static std::mt19937 generate_random_seed() {
    std::random_device device;
    return std::mt19937(device());
}

static std::mt19937& get_random_generator() {
    static std::mt19937 random_generator = generate_random_seed();
    return random_generator;
}

static std::set<std::string>& get_used_names() {
    static std::set<std::string> used_names;
    return used_names;
}

Robot::Robot() {
}

std::string Robot::get_name() const {
    if (!name_generated) {
        generate_name();
    }
    return name;
}

std::string Robot::name() const {
    return get_name();
}

void Robot::reset() {
    if (name_generated) {
        get_used_names().erase(name);
        name_generated = false;
        name.clear();
    }
}

void Robot::generate_name() const {
    std::uniform_int_distribution<int> letter_distribution('A', 'Z');
    std::uniform_int_distribution<int> digit_distribution(0, 999);
    
    std::string new_name;
    do {
        new_name = "";
        new_name += static_cast<char>(letter_distribution(get_random_generator()));
        new_name += static_cast<char>(letter_distribution(get_random_generator()));
        
        new_name += std::to_string(digit_distribution(get_random_generator()));
    } while (!get_used_names().insert(new_name).second);
    
    name = new_name;
    name_generated = true;
}

}  // namespace robot_name

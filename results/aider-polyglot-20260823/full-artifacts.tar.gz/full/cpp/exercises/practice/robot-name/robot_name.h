#if !defined(ROBOT_NAME_H)
#define ROBOT_NAME_H

#include <string>

namespace robot_name {

class Robot {
public:
    Robot();
    ~Robot() = default;
    
    std::string get_name() const;
    std::string name() const;
    void reset();
    
private:
    mutable bool name_generated = false;
    mutable std::string name;
    
    void generate_name() const;
};

using robot = Robot;

}  // namespace robot_name

#endif // ROBOT_NAME_H

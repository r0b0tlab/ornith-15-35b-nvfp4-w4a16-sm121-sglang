#include "phone_number.h"
#include <stdexcept>
#include <cctype>

namespace phone_number {

phone_number::phone_number(const std::string& number) {
    // Extract only digits
    std::string digits;
    for (char c : number) {
        if (std::isdigit(static_cast<unsigned char>(c))) {
            digits.push_back(c);
        }
    }

    // Check for invalid characters (letters)
    bool hasLetter = false;
    for (char c : number) {
        if (std::isalpha(static_cast<unsigned char>(c))) {
            hasLetter = true;
            break;
        }
    }
    if (hasLetter) {
        throw std::invalid_argument("Phone number contains letters");
    }

    size_t length = digits.length();

    // Invalid length
    if (length < 10 || length > 11) {
        throw std::invalid_argument("Invalid phone number length");
    }

    // Handle country code
    if (length == 11) {
        if (digits[0] != '1') {
            throw std::invalid_argument("Invalid country code");
        }
        digits = digits.substr(1);
    }

    if (length == 10) {
        // Validate area code and exchange code
        if (digits[0] == '0' || digits[0] == '1') {
            throw std::invalid_argument("Invalid area code");
        }
        if (digits[7] == '0' || digits[7] == '1') {
            throw std::invalid_argument("Invalid exchange code");
        }
    }

    digits_ = digits;
}

std::string phone_number::number() const {
    return digits_;
}

}  // namespace phone_number

#include "complex_numbers.h"
#include <cmath>

namespace complex_numbers {

Complex::Complex(double real, double imaginary)
    : real_(real), imaginary_(imaginary) {}

double Complex::real() const {
    return real_;
}

double Complex::imaginary() const {
    return imaginary_;
}

Complex Complex::operator+(const Complex& other) const {
    return Complex(real_ + other.real_, imaginary_ + other.imaginary_);
}

Complex Complex::operator+(double scalar) const {
    return Complex(real_ + scalar, imaginary_);
}

Complex operator+(double scalar, const Complex& other) {
    return Complex(other.real_ + scalar, other.imaginary_);
}

Complex Complex::operator-(const Complex& other) const {
    return Complex(real_ - other.real_, imaginary_ - other.imaginary_);
}

Complex Complex::operator*(const Complex& other) const {
    // (a + i * b) * (c + i * d) = (a * c - b * d) + (b * c + a * d) * i
    return Complex(
        real_ * other.real_ - imaginary_ * other.imaginary_,
        imaginary_ * other.real_ + real_ * other.imaginary_
    );
}

Complex Complex::operator/(const Complex& other) const {
    // (a + i * b) / (c + i * d) = (a * c + b * d)/(c^2 + d^2) + (b * c - a * d)/(c^2 + d^2) * i
    double denominator = other.real_ * other.real_ + other.imaginary_ * other.imaginary_;
    return Complex(
        (real_ * other.real_ + imaginary_ * other.imaginary_) / denominator,
        (imaginary_ * other.real_ - real_ * other.imaginary_) / denominator
    );
}

Complex Complex::conjugate() const {
    return Complex(real_, -imaginary_);
}

double Complex::abs() const {
    return std::sqrt(real_ * real_ + imaginary_ * imaginary_);
}

Complex Complex::exp() const {
    // e^(a + i * b) = e^a * (cos(b) + i * sin(b))
    double exp_a = std::exp(real_);
    return Complex(
        exp_a * std::cos(imaginary_),
        exp_a * std::sin(imaginary_)
    );
}

}  // namespace complex_numbers

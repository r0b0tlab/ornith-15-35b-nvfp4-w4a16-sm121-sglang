#if !defined(COMPLEX_NUMBERS_H)
#define COMPLEX_NUMBERS_H

namespace complex_numbers {

class Complex {
public:
    Complex(double real, double imaginary);

    double real() const;
    double imaginary() const;

    Complex operator+(const Complex& other) const;
    Complex operator+(double scalar) const;
    Complex operator+(Complex other, double scalar);
    Complex operator+(double scalar, const Complex& other);

    Complex operator-(const Complex& other) const;
    Complex operator*(const Complex& other) const;
    Complex operator/(const Complex& other) const;

    Complex conjugate() const;
    double abs() const;

    Complex exp() const;

private:
    double real_;
    double imaginary_;
};

}  // namespace complex_numbers

#endif  // COMPLEX_NUMBERS_H

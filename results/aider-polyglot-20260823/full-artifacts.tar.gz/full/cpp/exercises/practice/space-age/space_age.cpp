#include "space_age.h"

namespace space_age {

space_age::space_age(long long seconds) : seconds_(seconds) {}

}  // namespace space_age

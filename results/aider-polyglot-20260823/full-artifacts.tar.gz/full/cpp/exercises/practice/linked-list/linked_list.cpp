#include "linked_list.h"

namespace linked_list {

// All methods are defined inline in the header template.

}  // namespace linked_list

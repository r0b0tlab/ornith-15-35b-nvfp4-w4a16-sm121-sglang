#pragma once

#include <stdexcept>

namespace linked_list {

template <typename T>
class List {
public:
    struct Node {
        T data;
        Node* prev;
        Node* next;
        Node(T data_) : data(data_), prev(nullptr), next(nullptr) {}
    };

    List() : head(nullptr), tail(nullptr), node_count(0) {}

    void push(T value) {
        Node* new_node = new Node(value);
        if (head == nullptr) {
            head = tail = new_node;
        } else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
        node_count++;
    }

    T pop() {
        if (tail == nullptr) {
            throw std::out_of_range("List is empty");
        }
        T value = tail->data;
        tail = tail->prev;
        if (tail == nullptr) {
            head = nullptr;
        } else {
            tail->next = nullptr;
        }
        node_count--;
        return value;
    }

    T shift() {
        if (head == nullptr) {
            throw std::out_of_range("List is empty");
        }
        T value = head->data;
        head = head->next;
        if (head == nullptr) {
            tail = nullptr;
        } else {
            head->prev = nullptr;
        }
        node_count--;
        return value;
    }

    void unshift(T value) {
        Node* new_node = new Node(value);
        if (head == nullptr) {
            head = tail = new_node;
        } else {
            new_node->next = head;
            head->prev = new_node;
            head = new_node;
        }
        node_count++;
    }

    int count() {
        return node_count;
    }

    bool erase(T value) {
        Node* current = head;
        while (current != nullptr) {
            if (current->data == value) {
                if (current->prev != nullptr) {
                    current->prev->next = current->next;
                } else {
                    head = current->next;
                }
                if (current->next != nullptr) {
                    current->next->prev = current->prev;
                } else {
                    tail = current->prev;
                }
                delete current;
                node_count--;
                return true;
            }
            current = current->next;
        }
        return false;
    }

private:
    Node* head;
    Node* tail;
    int node_count;
};

}  // namespace linked_list

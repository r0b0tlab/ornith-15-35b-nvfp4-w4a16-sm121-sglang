#include "spiral_matrix.h"

namespace spiral_matrix {

std::vector<std::vector<int>> spiral_matrix(int size) {
    std::vector<std::vector<int>> matrix(size, std::vector<int>(size, 0));

    if (size <= 0) {
        return matrix;
    }

    int top = 0;
    int bottom = size - 1;
    int left = 0;
    int right = size - 1;
    int num = 1;

    while (top <= bottom && left <= right) {
        // Move right
        for (int col = left; col <= right; ++col) {
            matrix[top][col] = num++;
        }
        top++;

        // Move down
        for (int row = top; row <= bottom; ++row) {
            matrix[row][right] = num++;
        }
        right--;

        // Move left
        if (top <= bottom) {
            for (int col = right; col >= left; --col) {
                matrix[bottom][col] = num++;
            }
            bottom--;
        }

        // Move up
        if (left <= right) {
            for (int row = bottom; row >= top; --row) {
                matrix[row][left] = num++;
            }
            left++;
        }
    }

    return matrix;
}

}  // namespace spiral_matrix

#if !defined(BANK_ACCOUNT_H)
#define BANK_ACCOUNT_H

#include <mutex>

namespace Bankaccount {
class Bankaccount {
public:
    Bankaccount();
    ~Bankaccount();

    void open();
    void close();

    bool is_open() const;

    void deposit(double amount);
    double balance() const;

    void withdraw(double amount);

private:
    mutable std::mutex mutex_;
    bool open_;
    double balance_;
};  // class Bankaccount

}  // namespace Bankaccount

#endif  // BANK_ACCOUNT_H

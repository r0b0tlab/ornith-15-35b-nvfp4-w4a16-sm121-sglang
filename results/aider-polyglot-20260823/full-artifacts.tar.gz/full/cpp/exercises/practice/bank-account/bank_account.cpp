#include "bank_account.h"

#include <stdexcept>

namespace Bankaccount {

Bankaccount::Bankaccount() : open_(false), balance_(0.0) {}

Bankaccount::~Bankaccount() {}

void Bankaccount::open() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!open_) {
        open_ = true;
        balance_ = 0.0;
    }
}

void Bankaccount::close() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (open_) {
        open_ = false;
        balance_ = 0.0;
    }
}

bool Bankaccount::is_open() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return open_;
}

void Bankaccount::deposit(double amount) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!open_) {
        throw std::logic_error("Account is closed");
    }
    if (amount <= 0) {
        throw std::logic_error("Amount must be positive");
    }
    balance_ += amount;
}

double Bankaccount::balance() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!open_) {
        throw std::logic_error("Account is closed");
    }
    return balance_;
}

void Bankaccount::withdraw(double amount) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!open_) {
        throw std::logic_error("Account is closed");
    }
    if (amount <= 0) {
        throw std::logic_error("Amount must be positive");
    }
    if (amount > balance_) {
        throw std::logic_error("Insufficient funds");
    }
    balance_ -= amount;
}

}  // namespace Bankaccount

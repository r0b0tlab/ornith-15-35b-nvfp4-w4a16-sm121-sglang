#include "knapsack.h"
#include <algorithm>

namespace knapsack
{

int maximum_value(int maximumWeight, const std::vector<Item> &items)
{
    // dp[w] holds the maximum value achievable with a knapsack of capacity w
    std::vector<int> dp(maximumWeight + 1, 0);

    for (const auto &item : items)
    {
        // Traverse the capacity from high to low to ensure each item is used at most once
        for (int w = maximumWeight; w >= item.weight; w--)
        {
            dp[w] = std::max(dp[w], dp[w - item.weight] + item.value);
        }
    }

    return dp[maximumWeight];
}

} // namespace knapsack

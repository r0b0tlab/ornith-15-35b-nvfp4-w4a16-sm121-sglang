#include "sublist.h"
#include <algorithm>
#include <cstddef>

namespace sublist {

// Check if list_a contains list_b as a contiguous sub-sequence
bool containsSublist(const std::vector<int>& main, const std::vector<int>& sub) {
    if (sub.empty()) {
        return true;
    }
    if (sub.size() > main.size()) {
        return false;
    }
    
    for (std::size_t i = 0; i + sub.size() <= main.size(); ++i) {
        if (main[i] == sub[0]) {
            bool match = true;
            for (std::size_t j = 0; j < sub.size(); ++j) {
                if (main[i + j] != sub[j]) {
                    match = false;
                    break;
                }
            }
            if (match) {
                return true;
            }
        }
    }
    return false;
}

List_comparison sublist(const std::vector<int>& list_a, const std::vector<int>& list_b) {
    if (list_a == list_b) {
        return List_comparison::equal;
    }
    
    // Check if list_a is a sublist of list_b
    if (containsSublist(list_b, list_a)) {
        return List_comparison::sublist;
    }
    
    // Check if list_a is a superlist of list_b
    if (containsSublist(list_a, list_b)) {
        return List_comparison::superlist;
    }
    
    return List_comparison::unequal;
}

}  // namespace sublist

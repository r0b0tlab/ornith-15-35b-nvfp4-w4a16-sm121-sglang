#include "dnd_character.h"

#include <algorithm>

namespace dnd_character {

int ability() {
    static std::mt19937 rng{std::random_device{}};
    std::uniform_int_distribution<int> die(1, 6);
    std::array<int, 4> rolls;
    for (auto& r : rolls) {
        r = die(rng);
    }
    std::sort(rolls.begin(), rolls.end());
    return rolls[1] + rolls[2] + rolls[3];
}

Character::Character()
    : strength(ability()),
      dexterity(ability()),
      constitution(ability()),
      intelligence(ability()),
      wisdom(ability()),
      charisma(ability()),
      hitpoints(10 + modifier(constitution)) {}

int modifier(int score) {
    return std::floor((score - 10) / 2.0);
}

}  // namespace dnd_character

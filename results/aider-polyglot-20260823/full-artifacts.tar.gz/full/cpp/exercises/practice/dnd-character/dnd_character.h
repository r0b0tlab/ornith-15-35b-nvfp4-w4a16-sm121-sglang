#pragma once

#include <array>
#include <random>

namespace dnd_character {

class Character {
public:
    explicit Character();

    static int modifier(int score);

    int strength;
    int dexterity;
    int constitution;
    int intelligence;
    int wisdom;
    int charisma;
    int hitpoints;
};

int modifier(int score);
int ability();

}  // namespace dnd_character

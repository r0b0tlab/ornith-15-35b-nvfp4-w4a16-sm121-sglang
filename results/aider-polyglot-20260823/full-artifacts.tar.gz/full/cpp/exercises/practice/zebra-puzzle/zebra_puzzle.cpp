#include "zebra_puzzle.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <string>

namespace zebra_puzzle {

namespace {

// Domain indices:
// Nationalities: 0=English, 1=Spaniard, 2=Ukrainian, 3=Norwegian, 4=Japanese
// Colors: 0=red, 1=ivory, 2=green, 3=yellow, 4=blue
// Beverages: 0=coffee, 1=tea, 2=milk, 3=orangejuice, 4=water
// Pets: 0=dog, 1=fox, 2=horse, 3=snail, 4=zebra
// Hobbies: 0=dancing, 1=painting, 2=football, 3=reading, 4=chess

int position(const std::array<int, 5>& arr, int value) {
    for (int i = 0; i < 5; ++i) {
        if (arr[i] == value) return i;
    }
    return -1;
}

bool checkConstraints(const std::array<int, 5>& nat,
                      const std::array<int, 5>& color,
                      const std::array<int, 5>& bev,
                      const std::array<int, 5>& pet,
                      const std::array<int, 5>& hobby) {
    // 2. Englishman lives in red house
    if (position(nat, 0) != position(color, 0)) return false;
    // 3. Spaniard owns dog
    if (position(nat, 1) != position(pet, 0)) return false;
    // 4. green house drinks coffee
    if (position(color, 2) != position(bev, 0)) return false;
    // 5. Ukrainian drinks tea
    if (position(nat, 2) != position(bev, 1)) return false;
    // 6. green immediately right of ivory
    if (position(color, 2) != position(color, 1) + 1) return false;
    // 7. snail owner likes dancing
    if (position(pet, 3) != position(hobby, 0)) return false;
    // 8. yellow house is painter
    if (position(color, 3) != position(hobby, 1)) return false;
    // 9. middle house drinks milk
    if (position(bev, 2) != 2) return false;
    // 10. Norwegian lives in first house
    if (position(nat, 3) != 0) return false;
    // 13. football player drinks OJ
    if (position(hobby, 2) != position(bev, 3)) return false;
    // 14. Japanese plays chess
    if (position(nat, 4) != position(hobby, 4)) return false;
    // 11. reader next to fox
    if (std::abs(position(pet, 1) - position(hobby, 3)) != 1) return false;
    // 12. painter's house next to horse
    if (std::abs(position(hobby, 1) - position(pet, 2)) != 1) return false;
    // 15. Norwegian next to blue
    if (std::abs(position(nat, 3) - position(color, 4)) != 1) return false;
    return true;
}

const char* kNationality(int idx) {
    switch (idx) {
        case 0: return "English";
        case 1: return "Spaniard";
        case 2: return "Ukrainian";
        case 3: return "Norwegian";
        case 4: return "Japanese";
    }
    return "";
}

}  // namespace

Solution solve() {
    std::array<int, 5> base = {0, 1, 2, 3, 4};
    std::array<int, 5> nat = base;
    std::array<int, 5> color = base;
    std::array<int, 5> bev = base;
    std::array<int, 5> pet = base;
    std::array<int, 5> hobby = base;
    Solution result;

    do {
        do {
            do {
                do {
                    do {
                        if (checkConstraints(nat, color, bev, pet, hobby)) {
                            for (int i = 0; i < 5; ++i) {
                                if (bev[i] == 4) {
                                    result.drinksWater = kNationality(nat[i]);
                                }
                                if (pet[i] == 4) {
                                    result.ownsZebra = kNationality(nat[i]);
                                }
                            }
                            return result;
                        }
                    } while (std::next_permutation(hobby.begin(), hobby.end()));
                    std::sort(pet.begin(), pet.end());
                } while (std::next_permutation(pet.begin(), pet.end()));
            } while (std::next_permutation(bev.begin(), bev.end()));
            std::sort(color.begin(), color.end());
        } while (std::next_permutation(color.begin(), color.end()));
    } while (std::next_permutation(nat.begin(), nat.end()));

    return result;
}

}  // namespace zebra_puzzle

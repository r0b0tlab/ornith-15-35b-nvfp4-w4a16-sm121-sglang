#include "diamond.h"
#include <string>
#include <vector>

namespace diamond {

namespace {

int letter_index(char letter) {
    return letter - 'A';
}

}  // namespace

std::vector<std::string> rows(char letter) {
    const int n = letter_index(letter);
    const int size = 2 * n + 1;
    std::vector<std::string> result;

    for (int i = 0; i <= n; ++i) {
        char current = 'A' + i;
        int outer_spaces = n - i;

        std::string row(size, ' ');
        row[outer_spaces] = current;
        row[size - 1 - outer_spaces] = current;
        result.push_back(row);
    }

    for (int i = n - 1; i >= 0; --i) {
        char current = 'A' + i;
        int outer_spaces = n - i;

        std::string row(size, ' ');
        row[outer_spaces] = current;
        row[size - 1 - outer_spaces] = current;
        result.push_back(row);
    }

    return result;
}

}  // namespace diamond

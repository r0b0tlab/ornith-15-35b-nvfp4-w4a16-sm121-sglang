#if !defined(CIRCULAR_BUFFER_H)
#define CIRCULAR_BUFFER_H

#include <vector>
#include <stdexcept>
#include <cstddef>

namespace circular_buffer {

template <typename T>
class circular_buffer {
public:
    explicit circular_buffer(std::size_t capacity);
    ~circular_buffer();

    void write(T value);
    T read();
    void clear();

    void overwrite(T value);

private:
    std::vector<T> buffer_;
    std::size_t capacity_;
    std::size_t head_;  // position to read from
    std::size_t tail_;  // position to write to
    std::size_t count_;  // number of elements currently in buffer
};

}  // namespace circular_buffer

#endif // CIRCULAR_BUFFER_H

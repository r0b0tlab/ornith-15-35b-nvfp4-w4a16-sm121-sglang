#include "circular_buffer.h"

namespace circular_buffer {

template <typename T>
circular_buffer<T>::circular_buffer(std::size_t capacity)
    : buffer_(capacity), capacity_(capacity), head_(0), tail_(0), count_(0) {}

template <typename T>
circular_buffer<T>::~circular_buffer() {}

template <typename T>
void circular_buffer<T>::write(T value) {
    if (capacity_ == 0) {
        throw std::domain_error("Buffer is empty");
    }
    if (count_ == capacity_) {
        throw std::domain_error("Buffer is full");
    }
    buffer_[tail_] = value;
    tail_ = (tail_ + 1) % capacity_;
    count_++;
}

template <typename T>
T circular_buffer<T>::read() {
    if (capacity_ == 0 || count_ == 0) {
        throw std::domain_error("Buffer is empty");
    }
    T value = buffer_[head_];
    head_ = (head_ + 1) % capacity_;
    count_--;
    return value;
}

template <typename T>
void circular_buffer<T>::clear() {
    head_ = 0;
    tail_ = 0;
    count_ = 0;
}

template <typename T>
void circular_buffer<T>::overwrite(T value) {
    if (capacity_ == 0) {
        throw std::domain_error("Buffer is empty");
    }
    if (count_ == capacity_) {
        // Buffer is full, overwrite oldest element
        buffer_[tail_] = value;
        tail_ = (tail_ + 1) % capacity_;
        head_ = (head_ + 1) % capacity_;
    } else {
        write(value);
    }
}

}  // namespace circular_buffer

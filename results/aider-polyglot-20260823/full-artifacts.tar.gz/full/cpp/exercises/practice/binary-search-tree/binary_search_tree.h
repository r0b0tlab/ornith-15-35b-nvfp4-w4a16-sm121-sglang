#if !defined(BINARY_SEARCH_TREE_H)
#define BINARY_SEARCH_TREE_H

#include <vector>
#include <memory>
#include <algorithm>
#include <stack>

namespace binary_search_tree {

class binary_tree {
public:
    explicit binary_tree(int data) : root_(std::make_unique<node>(data)) {}

    void insert(int value) {
        insertNode(root_, value);
    }

    int data() const {
        return root_->data;
    }

    std::unique_ptr<node> left() const {
        return root_->left;
    }

    std::unique_ptr<node> right() const {
        return root_->right;
    }

    std::vector<int> data_in_order() const {
        std::vector<int> result;
        inOrder(root_, result);
        return result;
    }

    std::vector<int> data_pre_order() const {
        std::vector<int> result;
        preOrder(root_, result);
        return result;
    }

    std::vector<int> data_post_order() const {
        std::vector<int> result;
        postOrder(root_, result);
        return result;
    }

    // Iterator support for range-based for loops
    class iterator {
    public:
        using value_type = int;
        using reference = int&;
        using pointer = int*;

        iterator() : current_(nullptr), stack_() {}

        reference operator*() const {
            return current_->data;
        }

        pointer operator->() const {
            return &current_->data;
        }

        iterator& operator++() {
            current_ = nullptr;
            if (!stack_.empty() && stack_.top()->right) {
                current_ = stack_.top()->right;
                stack_.pop();
                while (current_) {
                    stack_.push(current_);
                    current_ = current_->left;
                }
            }
            while (!stack_.empty() && !current_) {
                current_ = stack_.top();
                stack_.pop();
            }
            return *this;
        }

        bool operator!=(const iterator& other) const {
            return current_ != other.current_;
        }

        bool operator==(const iterator& other) const {
            return current_ == other.current_;
        }

    private:
        std::unique_ptr<node> current_;
        std::stack<std::unique_ptr<node>> stack_;

        iterator(std::unique_ptr<node> root) : stack_() {
            if (root) {
                current_ = root;
                while (current_->left) {
                    stack_.push(std::move(current_->left));
                    current_ = std::move(current_->left);
                }
            }
        }

        friend class binary_tree;
    };

    iterator begin() {
        return iterator(root_);
    }

    iterator end() {
        return iterator();
    }

private:
    struct node {
        int data;
        std::unique_ptr<node> left;
        std::unique_ptr<node> right;

        explicit node(int data) : data(data) {}
    };

    std::unique_ptr<node> root_;

    void insertNode(std::unique_ptr<node>& current, int value) {
        if (!current) {
            current = std::make_unique<node>(value);
            return;
        }

        if (value <= current->data) {
            insertNode(current->left, value);
        } else {
            insertNode(current->right, value);
        }
    }

    void inOrder(const std::unique_ptr<node>& node, std::vector<int>& result) const {
        if (!node) return;
        inOrder(node->left, result);
        result.push_back(node->data);
        inOrder(node->right, result);
    }

    void preOrder(const std::unique_ptr<node>& node, std::vector<int>& result) const {
        if (!node) return;
        result.push_back(node->data);
        preOrder(node->left, result);
        preOrder(node->right, result);
    }

    void postOrder(const std::unique_ptr<node>& node, std::vector<int>& result) const {
        if (!node) return;
        postOrder(node->left, result);
        postOrder(node->right, result);
        result.push_back(node->data);
    }
};

}  // namespace binary_search_tree

#endif // BINARY_SEARCH_TREE_H

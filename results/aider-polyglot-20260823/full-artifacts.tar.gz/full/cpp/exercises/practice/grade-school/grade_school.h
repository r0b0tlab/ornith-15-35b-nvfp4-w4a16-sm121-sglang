#if !defined(GRADE_SCHOOL_H)
#define GRADE_SCHOOL_H

#include <string>
#include <vector>
#include <map>

namespace grade_school {

struct student {
    std::string name;
    int grade;
};

class school {
public:
    void add(const std::string& name, int grade);
    std::vector<std::string> grade(int grade) const;
    std::vector<student> roster() const;
private:
    std::map<int, std::vector<std::string>> students_;
};

}  // namespace grade_school

#endif // GRADE_SCHOOL_H

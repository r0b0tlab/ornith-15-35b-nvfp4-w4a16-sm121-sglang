#include "grade_school.h"
#include <algorithm>

namespace grade_school {

void school::add(const std::string& name, int grade) {
    // Check if student already exists in any grade
    for (const auto& entry : students_) {
        for (const auto& existing : entry.second) {
            if (existing == name) {
                return; // Duplicate, don't add
            }
        }
    }
    students_[grade].push_back(name);
}

std::vector<std::string> school::grade(int grade) const {
    auto it = students_.find(grade);
    if (it != students_.end()) {
        std::vector<std::string> result = it->second;
        std::sort(result.begin(), result.end());
        return result;
    }
    return {};
}

std::vector<student> school::roster() const {
    std::vector<student> result;
    for (const auto& entry : students_) {
        std::vector<std::string> names = entry.second;
        std::sort(names.begin(), names.end());
        for (const auto& name : names) {
            result.push_back({name, entry.first});
        }
    }
    return result;
}

}  // namespace grade_school

#include "gigasecond.h"
#include <ctime>

namespace gigasecond {

std::tm advance(std::tm date) {
    time_t seconds = mktime(&date);
    seconds += 1000000000LL;
    time_t* result = gmtime(&seconds);
    return *result;
}

}  // namespace gigasecond

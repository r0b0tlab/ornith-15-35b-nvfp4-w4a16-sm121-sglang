#if !defined(GIGASECOND_H)
#define GIGASECOND_H

#include <ctime>

namespace gigasecond {

std::tm advance(std::tm date);

}  // namespace gigasecond

#endif // GIGASECOND_H

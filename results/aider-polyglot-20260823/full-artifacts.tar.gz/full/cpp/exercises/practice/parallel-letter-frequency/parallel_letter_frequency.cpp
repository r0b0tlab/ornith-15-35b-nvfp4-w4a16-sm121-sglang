#include "parallel_letter_frequency.h"
#include <algorithm>
#include <thread>
#include <numeric>
#include <execution>

namespace parallel_letter_frequency {

std::map<char, int> frequency(const std::vector<std::string_view>& texts) {
    // If no texts, return empty result
    if (texts.empty()) {
        return std::map<char, int>();
    }

    // Compute partial frequency maps in parallel and merge them
    return std::transform_reduce(
        std::execution::par,
        texts.begin(),
        texts.end(),
        std::map<char, int>{},
        [](std::map<char, int> acc, std::map<char, int> partial) {
            for (const auto& pair : partial) {
                acc[pair.first] += pair.second;
            }
            return acc;
        },
        [](std::string_view text) {
            std::map<char, int> local_counts;
            for (char c : text) {
                if (std::isalpha(static_cast<unsigned char>(c))) {
                    c = std::tolower(static_cast<unsigned char>(c));
                    local_counts[c]++;
                }
            }
            return local_counts;
        }
    );
}

}

#if !defined(ALLERGIES_H)
#define ALLERGIES_H

#include <string>
#include <unordered_set>
#include <array>

namespace allergies {

class allergy_test {
public:
    explicit allergy_test(unsigned score) : score_(score) {}

    bool is_allergic_to(const std::string& allergen) const {
        const std::array<std::string, 8> allergens = {
            "eggs", "peanuts", "shellfish", "strawberries",
            "tomatoes", "chocolate", "pollen", "cats"
        };

        for (int i = 0; i < 8; ++i) {
            if (allergens[i] == allergen) {
                return (score_ & (1u << i)) != 0;
            }
        }
        return false;
    }

    std::unordered_set<std::string> get_allergies() const {
        const std::array<std::string, 8> allergens = {
            "eggs", "peanuts", "shellfish", "strawberries",
            "tomatoes", "chocolate", "pollen", "cats"
        };

        std::unordered_set<std::string> result;
        for (int i = 0; i < 8; ++i) {
            if ((score_ & (1u << i)) != 0) {
                result.emplace(allergens[i]);
            }
        }
        return result;
    }

    std::unordered_set<std::string> get_allergens() const {
        return get_allergies();
    }

private:
    unsigned score_;
};

}  // namespace allergies

#endif // ALLERGIES_H

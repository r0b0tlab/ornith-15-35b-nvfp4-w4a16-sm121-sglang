#include "meetup.h"

namespace meetup {

static int days_in_month_impl(int year, unsigned int month) {
    static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int dim = days[month - 1];
    if (month == 2 && ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)) {
        dim = 29;
    }
    return dim;
}

static std::chrono::weekday to_std_weekday(weekday wd) {
    using std::chrono::weekday;
    switch (wd) {
        case weekday::sunday: return weekday(0);
        case weekday::monday: return weekday(1);
        case weekday::tuesday: return weekday(2);
        case weekday::wednesday: return weekday(3);
        case weekday::thursday: return weekday(4);
        case weekday::friday: return weekday(5);
        case weekday::saturday: return weekday(6);
        default: return weekday(0);
    }
}

scheduler::scheduler(weekday wd, week wk) : weekday_(wd), week_(wk) {}

std::chrono::system_clock::date scheduler::meetup_date(int year, unsigned int month) const {
    using namespace std::chrono;
    
    weekday target = to_std_weekday(weekday_);
    
    int start_day;
    
    switch (week_) {
        case week::teenth:
            start_day = 13;
            break;
        case week::last:
            start_day = days_in_month_impl(year, month);
            break;
        default:
            start_day = 1 + 7 * (static_cast<int>(week_) - 1);  // first = 1, second = 8, etc.
            break;
    }
    
    auto d = year_month_day{ year, month, start_day };
    int wd_int = static_cast<int>(d.weekday() - target);
    
    int diff;
    if (week_ == week::last) {  // last
        if (wd_int < 0) wd_int += 7;
        start_day -= wd_int;
    } else {  // first, second, third, fourth, teenth
        wd_int = static_cast<int>(target - d.weekday());
        if (wd_int < 0) wd_int += 7;
        start_day += wd_int;
    }
    
    return year_month_day{ year, month, start_day };
}

}  // namespace meetup

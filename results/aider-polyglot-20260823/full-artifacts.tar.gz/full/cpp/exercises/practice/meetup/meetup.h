#if !defined(MEETUP_H)
#define MEETUP_H

#include <chrono>

namespace meetup {

enum class week {
    first,
    second,
    third,
    fourth,
    last,
    teenth
};

enum class weekday {
    sunday,
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday
};

class scheduler {
public:
    scheduler(weekday wd, week wk);
    std::chrono::system_clock::date meetup_date(int year, unsigned int month) const;
private:
    weekday weekday_;
    week week_;
};

}  // namespace meetup

#endif // MEETUP_H

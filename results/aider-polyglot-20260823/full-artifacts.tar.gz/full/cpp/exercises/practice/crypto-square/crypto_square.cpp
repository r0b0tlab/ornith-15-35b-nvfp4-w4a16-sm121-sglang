#include "crypto_square.h"
#include <string>
#include <cmath>
#include <algorithm>
#include <cctype>

namespace crypto_square {

std::string plaintext(const std::string& text) {
    std::string result;
    for (char c : text) {
        if (std::isalnum(c)) {
            result += std::tolower(c);
        }
    }
    return result;
}

std::string ciphertext(const std::string& text) {
    // Normalize the text
    std::string normalized = plaintext(text);
    
    // Handle empty case
    if (normalized.empty()) {
        return "";
    }
    
    // Calculate rectangle dimensions
    size_t length = normalized.length();
    double sqrt_length = std::sqrt(length);
    size_t columns = static_cast<size_t>(std::ceil(sqrt_length));
    size_t rows = static_cast<size_t>(std::floor(sqrt_length));
    
    // Create the encoded message
    std::string result;
    for (size_t col = 0; col < columns; ++col) {
        std::string chunk;
        for (size_t row = 0; row < rows; ++row) {
            size_t index = row * columns + col;
            if (index < length) {
                chunk += normalized[index];
            } else {
                chunk += ' ';
            }
        }
        if (!result.empty()) {
            result += ' ';
        }
        result += chunk;
    }
    
    return result;
}

cipher::cipher(const std::string& text) : text_(text) {}

std::string cipher::normalized_cipher_text() {
    return ciphertext(text_);
}

}  // namespace crypto_square

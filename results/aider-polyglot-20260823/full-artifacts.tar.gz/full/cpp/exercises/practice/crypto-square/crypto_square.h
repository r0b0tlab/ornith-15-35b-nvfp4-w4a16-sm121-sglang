#if !defined(CRYPTO_SQUARE_H)
#define CRYPTO_SQUARE_H

#include <string>

namespace crypto_square {

class cipher {
public:
    cipher(const std::string& text);
    std::string normalized_cipher_text();
private:
    std::string text_;
};

std::string plaintext(const std::string& text);
std::string ciphertext(const std::string& text);

}  // namespace crypto_square

#endif // CRYPTO_SQUARE_H

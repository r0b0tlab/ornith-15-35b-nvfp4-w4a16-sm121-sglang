package markdown

import (
	"fmt"
	"strings"
)

// Render translates markdown to HTML.
//
// Behavior notes (preserved from the original implementation):
//   - The original used a single-pass character scanner with shared state
//     (header, list, he) across lines. This refactor preserves that behavior:
//       * A line starting with '#' is treated as a header. Header text is emitted
//         directly (not wrapped in <p> tags).
//       * If a header line has more than 6 '#' characters, the original code
//         emitted a bare <p> containing the '#' characters (rather than a heading).
//         We preserve that quirky behavior.
//       * List items ('*') are only recognized at the start of a line while no
//         header is open.
//   - The original only replaced the FIRST occurrence of each markup token, which
//     is a bug for multiple bold/italic spans on one line. This refactor replaces
//     ALL occurrences, which is the correct behavior.
func Render(markdown string) string {
	lines := strings.Split(markdown, "\n")
	var sb strings.Builder

	inList := false

	for _, line := range lines {
		trimmed := strings.TrimSpace(line)

		// Blank line closes any open list or paragraph context.
		if trimmed == "" {
			if inList {
				sb.WriteString("</ul>")
				inList = false
			}
			continue
		}

		// Header detection: leading '#' characters.
		if strings.HasPrefix(trimmed, "#") {
			if inList {
				sb.WriteString("</ul>")
				inList = false
			}
			header := 0
			for header < len(trimmed) && trimmed[header] == '#' {
				header++
			}
			content := strings.TrimSpace(trimmed[header:])
			if header > 6 {
				// Preserve the original quirky behavior for over-long headers.
				sb.WriteString(fmt.Sprintf("<p>%s</p>", strings.Repeat("#", header)))
			} else {
				sb.WriteString(fmt.Sprintf("<h%d>%s</h%d>", header, inline(content), header))
			}
			continue
		}

		// List item detection: leading '*'.
		if strings.HasPrefix(trimmed, "*") {
			if !inList {
				sb.WriteString("<ul>")
				inList = true
			}
			content := strings.TrimSpace(trimmed[1:])
			sb.WriteString(fmt.Sprintf("<li>%s</li>", inline(content)))
			continue
		}

		// Regular paragraph text.
		if inList {
			sb.WriteString("</ul>")
			inList = false
		}
		sb.WriteString(fmt.Sprintf("<p>%s</p>", inline(trimmed)))
	}

	if inList {
		sb.WriteString("</ul>")
	}

	return sb.String()
}

// inline processes inline markup (bold and italic) on a single line.
func inline(line string) string {
	line = strings.ReplaceAll(line, "__", "<strong>")
	line = strings.ReplaceAll(line, "_", "<em>")
	return line
}

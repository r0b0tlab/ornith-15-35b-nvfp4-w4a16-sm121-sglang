package connect

import (
	"fmt"
	"strings"
)

type coord struct {
	row int
	col int
}

// hexNeighbors returns the 6 neighbors of a coordinate in a "pointy-top"
// hexagon grid where the rows are indented by row/2.
func hexNeighbors(c coord) []coord {
	return []coord{
		{c.row, c.col - 1},
		{c.row, c.col + 1},
		{c.row - 1, c.col},
		{c.row - 1, c.col + 1},
		{c.row + 1, c.col},
		{c.row + 1, c.col + 1},
	}
}

// ResultOf computes the result of a Hex game.
func ResultOf(lines []string) (string, error) {
	// Parse the board into a map of coordinates.
	board := map[coord]byte{}
	maxCol := 0
	for i, line := range lines {
		trimmed := strings.TrimLeft(line, " ")
		for j := 0; j < len(trimmed); j++ {
			if trimmed[j] != ' ' {
				board[coord{i, j}] = trimmed[j]
				if j > maxCol {
					maxCol = j
				}
			}
		}
	}

	// Check if O connects top to bottom.
	if connected(board, maxCol, 'O') {
		return "O", nil
	}

	// Check if X connects left to right.
	if connected(board, maxCol, 'X') {
		return "X", nil
	}

	return "", nil
}

// connected checks if the given player has connected their stones.
func connected(board map[coord]byte, maxCol int, player byte) bool {
	if len(board) == 0 {
		return false
	}

	// Find a starting point for BFS.
	startRow := -1
	for i := 0; i <= maxCol; i++ {
		found := false
		for j := 0; j <= maxCol; j++ {
			if board[coord{i, j}] == player {
				found = true
				break
			}
		}
		if found {
			startRow = i
			break
		}
	}

	if startRow == -1 {
		return false
	}

	// BFS to find if there's a path from the start row to the last row.
	visited := map[coord]bool{}
	queue := []coord{}
	for j := 0; j <= maxCol; j++ {
		if board[coord{startRow, j}] == player {
			visited[coord{startRow, j}] = true
			queue = append(queue, coord{startRow, j})
		}
	}

	for len(queue) > 0 {
		current := queue[0]
		queue = queue[1:]

		// Check if we reached the last row.
		if current.row == maxCol {
			return true
		}

		// Add neighbors to the queue.
		for _, n := range hexNeighbors(current) {
			if n.row >= 0 && n.row <= maxCol &&
				n.col >= 0 && n.col <= maxCol &&
				board[n] == player &&
				!visited[n] {
				visited[n] = true
				queue = append(queue, n)
			}
		}
	}

	return false
}

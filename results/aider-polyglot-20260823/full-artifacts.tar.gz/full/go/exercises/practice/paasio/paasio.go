package paasio

import "io"

type readCounter struct {
	reader io.Reader
	nbytes int64
	nops   int
}

type writeCounter struct {
	writer io.Writer
	nbytes int64
	nops   int
}

type readWriteCounter struct {
	reader    io.Reader
	writer    io.Writer
	nbytes    int64
	nopsRead  int
	nopsWrite int
}

func NewWriteCounter(writer io.Writer) WriteCounter {
	return &writeCounter{
		writer: writer,
	}
}

func NewReadCounter(reader io.Reader) ReadCounter {
	return &readCounter{
		reader: reader,
	}
}

func NewReadWriteCounter(readwriter io.ReadWriter) ReadWriteCounter {
	return &readWriteCounter{
		reader: readwriter,
		writer: readwriter,
	}
}

func (rc *readCounter) Read(p []byte) (int, error) {
	n, err := rc.reader.Read(p)
	rc.nbytes += int64(n)
	rc.nops++
	return n, err
}

func (rc *readCounter) ReadCount() (int64, int) {
	return rc.nbytes, rc.nops
}

func (wc *writeCounter) Write(p []byte) (int, error) {
	n, err := wc.writer.Write(p)
	wc.nbytes += int64(n)
	wc.nops++
	return n, err
}

func (wc *writeCounter) WriteCount() (int64, int) {
	return wc.nbytes, wc.nops
}

func (rwc *readWriteCounter) Read(p []byte) (int, error) {
	n, err := rwc.reader.Read(p)
	rwc.nbytes += int64(n)
	rwc.nopsRead++
	return n, err
}

func (rwc *readWriteCounter) Write(p []byte) (int, error) {
	n, err := rwc.writer.Write(p)
	rwc.nbytes += int64(n)
	rwc.nopsWrite++
	return n, err
}

func (rwc *readWriteCounter) ReadCount() (int64, int) {
	return rwc.nbytes, rwc.nopsRead
}

func (rwc *readWriteCounter) WriteCount() (int64, int) {
	return rwc.nbytes, rwc.nopsWrite
}

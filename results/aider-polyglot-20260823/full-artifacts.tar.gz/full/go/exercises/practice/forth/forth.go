package forth

import (
	"errors"
	"strconv"
	"strings"
)

var (
	errStackUnderflow = errors.New("stack underflow")
	errInvalidSyntax  = errors.New("invalid syntax")
	errUndefinedWord  = errors.New("undefined word")
	errDivideByZero   = errors.New("divide by zero")
)

// Forth evaluates a Forth program given as input lines and returns the resulting stack.
func Forth(input []string) ([]int, error) {
	f := &vm{
		words: make(map[string][]string),
	}
	for _, line := range input {
		if err := f.execute(tokenize(line)); err != nil {
			return nil, err
		}
	}
	return f.stack, nil
}

type vm struct {
	stack []int
	words map[string][]string
}

func (f *vm) execute(tokens []string) error {
	for i := 0; i < len(tokens); {
		if tokens[i] == ":" {
			// Definition: : name ;
			if i+1 >= len(tokens) {
				return errInvalidSyntax
			}
			name := tokens[i+1]
			if isNumber(name) || isBuiltin(name) {
				return errInvalidSyntax
			}
			j := i + 2
			for j < len(tokens) && tokens[j] != ";" {
				j++
			}
			if j >= len(tokens) {
				return errInvalidSyntax // no closing ;
			}
			def := make([]string, j-(i+2))
			copy(def, tokens[i+2:j])
			f.words[name] = def
			i = j + 1
			continue
		}
		if err := f.execOne(tokens[i]); err != nil {
			return err
		}
		i++
	}
	return nil
}

func (f *vm) execOne(tok string) error {
	name := strings.ToLower(tok)
	if def, ok := f.words[name]; ok {
		return f.execute(def)
	}
	if num, err := strconv.Atoi(tok); err == nil {
		f.stack = append(f.stack, num)
		return nil
	}
	return f.builtin(name)
}

func (f *vm) builtin(name string) error {
	switch name {
	case "+":
		return f.arith(func(a, b int) int { return a + b })
	case "-":
		return f.arith(func(a, b int) int { return a - b })
	case "*":
		return f.arith(func(a, b int) int { return a * b })
	case "/":
		if len(f.stack) < 2 {
			return errStackUnderflow
		}
		if f.stack[len(f.stack)-1] == 0 {
			return errDivideByZero
		}
		return f.arith(func(a, b int) int { return a / b })
	case "dup":
		if len(f.stack) < 1 {
			return errStackUnderflow
		}
		top := f.stack[len(f.stack)-1]
		f.stack = append(f.stack, top)
		return nil
	case "drop":
		if len(f.stack) < 1 {
			return errStackUnderflow
		}
		f.stack = f.stack[:len(f.stack)-1]
		return nil
	case "swap":
		if len(f.stack) < 2 {
			return errStackUnderflow
		}
		f.stack[len(f.stack)-1], f.stack[len(f.stack)-2] = f.stack[len(f.stack)-2], f.stack[len(f.stack)-1]
		return nil
	case "over":
		if len(f.stack) < 2 {
			return errStackUnderflow
		}
		second := f.stack[len(f.stack)-2]
		f.stack = append(f.stack, second)
		return nil
	default:
		return errUndefinedWord
	}
}

func (f *vm) arith(op func(a, b int) int) error {
	if len(f.stack) < 2 {
		return errStackUnderflow
	}
	b := f.stack[len(f.stack)-1]
	a := f.stack[len(f.stack)-2]
	f.stack = f.stack[:len(f.stack)-2]
	f.stack = append(f.stack, op(a, b))
	return nil
}

func isBuiltin(name string) bool {
	switch name {
	case "+", "-", "*", "/", "dup", "drop", "swap", "over":
		return true
	}
	return false
}

func isNumber(s string) bool {
	_, err := strconv.Atoi(s)
	return err == nil
}

func tokenize(line string) []string {
	fields := strings.Fields(line)
	for i, f := range fields {
		fields[i] = strings.ToLower(f)
	}
	return fields
}

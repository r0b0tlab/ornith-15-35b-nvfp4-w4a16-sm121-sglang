package bookstore

const basePrice = 800 // price of one book in cents

// discounts for sets of 1..5 distinct books
var discounts = []float64{0, 0.05, 0.10, 0.20, 0.25}

// Cost calculates the minimum cost for a basket of books.
func Cost(books []int) int {
	// count occurrences of each book
	counts := make([]int, 6) // indices 1..5 used
	for _, b := range books {
		counts[b]++
	}

	// greedily build sets
	var sets []int
	remaining := append([]int(nil), counts[1:6]...)

	for totalRemaining(remaining) > 0 {
		// form one set by taking one of each available book
		set := make([]int, 0, 5)
		for i := 0; i < 5; i++ {
			if remaining[i] > 0 {
				remaining[i]--
				set = append(set, i)
			}
		}
		sets = append(sets, len(set))
	}

	// optimize: replace (5,4) pairs with (3,3) pairs because 3+3 is cheaper than 5+4
	for {
		five := 0
		four := 0
		for _, s := range sets {
			switch s {
			case 5:
				five++
			case 4:
				four++
			}
		}
		if five > 0 && four > 0 {
			// remove one 5 and one 4, add two 3s
			newSets := make([]int, 0, len(sets))
			doneFive := false
			doneFour := false
			for _, s := range sets {
				switch s {
				case 5:
					if !doneFive {
						doneFive = true
						continue
					}
					newSets = append(newSets, s)
				case 4:
					if !doneFour {
						doneFour = true
						continue
					}
					newSets = append(newSets, s)
				default:
					newSets = append(newSets, s)
				}
			}
			newSets = append(newSets, 3, 3)
			sets = newSets
		} else {
			break
		}
	}

	// compute total cost
	total := 0
	for _, s := range sets {
		discount := discounts[s]
		// s books with the given discount
		pricePerBook := float64(basePrice) * (1 - discount)
		total += int(float64(s) * pricePerBook)
	}

	return total
}

func totalRemaining(books []int) int {
	total := 0
	for _, b := range books {
		total += b
	}
	return total
}

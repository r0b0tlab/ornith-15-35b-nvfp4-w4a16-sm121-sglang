package pov

type Tree struct {
	value    string
	children []*Tree
}

// New creates and returns a new Tree with the given root value and children.
func New(value string, children ...*Tree) *Tree {
	return &Tree{value: value, children: children}
}

// Value returns the value at the root of a tree.
func (tr *Tree) Value() string {
	return tr.value
}

// Children returns a slice containing the children of a tree.
// There is no need to sort the elements in the result slice,
// they can be in any orders.
func (tr *Tree) Children() []*Tree {
	return tr.children
}

// String describes a tree in a compact S-expression format.
// This helps to make test outputs more readable.
// Feel free to adapt this method as you see fit.
func (tr *Tree) String() string {
	if tr == nil {
		return "nil"
	}
	result := tr.Value()
	if len(tr.Children()) == 0 {
		return result
	}
	for _, ch := range tr.Children() {
		result += " " + ch.String()
	}
	return "(" + result + ")"
}

// FromPov returns the pov from the node specified in the argument.
func (tr *Tree) FromPov(from string) *Tree {
	path := tr.pathFromRoot(from)
	if path == nil {
		return nil
	}

	// Build the new tree bottom-up along the path from root to 'from'.
	// Each node on the path gets the next node down as its only child,
	// and its original children (except that next node) become additional children.
	var newRoot *Tree
	for i := len(path) - 1; i >= 0; i-- {
		node := path[i]
		var newChildren []*Tree
		for _, child := range node.children {
			if child == path[i+1] {
				newChildren = append(newChildren, newRoot)
				break
			}
			newChildren = append(newChildren, child)
		}
		newRoot = &Tree{value: node.value, children: newChildren}
	}
	return newRoot
}

// pathFromRoot returns the slice of nodes from the root down to the node
// with the given value, or nil if not found.
func (tr *Tree) pathFromRoot(value string) []*Tree {
	path := make([]*Tree, 0)
	if !tr.findPath(value, &path) {
		return nil
	}
	return path
}

// findPath performs a DFS to find the path from this node to the target.
func (tr *Tree) findPath(value string, path *[]*Tree) bool {
	*path = append(*path, tr)
	if tr.value == value {
		return true
	}
	for _, child := range tr.children {
		if child.findPath(value, path) {
			return true
		}
	}
	*path = (*path)[:len(*path)-1]
	return false
}

// PathTo returns the shortest path between two nodes in the tree.
func (tr *Tree) PathTo(from, to string) []string {
	fromNode := tr.findNode(from)
	if fromNode == nil {
		return nil
	}
	toNode := tr.findNode(to)
	if toNode == nil {
		return nil
	}

	// Find the path from root to 'from' and 'to', then compute LCA.
	fromPath := fromNode.pathFromRoot(from)
	toPath := toNode.pathFromRoot(to)

	// Find the lowest common ancestor by comparing the two paths.
	i := 0
	for i < len(fromPath) && i < len(toPath) && fromPath[i] == toPath[i] {
		i++
	}
	lca := fromPath[i-1]

	// Path from 'from' up to LCA.
	result := []string{}
	for j := len(fromPath) - 1; j >= i; j-- {
		result = append(result, fromPath[j].value)
	}
	// Path from LCA down to 'to'.
	for j := i; j < len(toPath); j++ {
		result = append(result, toPath[j].value)
	}
	return result
}

// findNode returns a pointer to the node with the given value, or nil if not found.
func (tr *Tree) findNode(value string) *Tree {
	if tr == nil {
		return nil
	}
	if tr.value == value {
		return tr
	}
	for _, child := range tr.children {
		found := child.findNode(value)
		if found != nil {
			return found
		}
	}
	return nil
}

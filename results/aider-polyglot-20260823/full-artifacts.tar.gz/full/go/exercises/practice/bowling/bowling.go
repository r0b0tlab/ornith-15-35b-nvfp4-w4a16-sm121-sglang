package bowling

import "errors"

// Define the Game type here.
type Game struct {
	rolls  []int
	rollIdx int
}

func NewGame() *Game {
	return &Game{
		rolls:  make([]int, 0),
		rollIdx: 0,
	}
}

func (g *Game) Roll(pins int) error {
	if pins < 0 || pins > 10 {
		return errors.New("pins must be between 0 and 10")
	}

	if g.isGameComplete() {
		return errors.New("game is complete")
	}

	currentFrame, err := g.currentFrame()
	if err != nil {
		return err
	}

	if currentFrame == 9 && g.rolls[g.rollIdx] == 10 && g.rolls[g.rollIdx+1] >= 10 {
		return errors.New("invalid")
	}

	if currentFrame == 9 && g.rolls[g.rollIdx]+g.rolls[g.rollIdx+1] > 10 {
		return errors.New("invalid")
	}

	g.rolls[g.rollIdx] = pins
	g.rollIdx++

	return nil
}

func (g *Game) Score() (int, error) {
	if !g.isGameComplete() {
		return 0, errors.New("game is not complete")
	}

	score := 0
	rollIdx := 0

	for frame := 0; frame < 10; frame++ {
		if g.rolls[rollIdx] == 10 {
			score += 10 + g.rolls[rollIdx+1] + g.rolls[rollIdx+2]
			rollIdx++
		} else if g.rolls[rollIdx+1] == 10 {
			score += 10 + g.rolls[rollIdx+2]
			rollIdx += 2
		} else {
			score += g.rolls[rollIdx] + g.rolls[rollIdx+1]
			rollIdx += 2
		}
	}

	return score, nil
}

func (g *Game) currentFrame() (int, error) {
	rollIdx := 0
	frame := 0

	for frame < 9 {
		if g.rolls[rollIdx] == 10 {
			frame++
			rollIdx++
		} else {
			rollIdx += 2
			frame++
		}
	}

	return frame, nil
}

func (g *Game) isTenthFrameComplete() bool {
	if g.rolls[g.rollIdx-1] == 10 {
		return g.rollIdx >= 11
	}
	return g.rollIdx >= 12
}

func (g *Game) isTenthFrameInvalid() bool {
	return false
}

func (g *Game) isGameComplete() bool {
	if g.rollIdx == 0 {
		return false
	}

	if g.rolls[0] == 10 {
		return g.rollIdx == 12
	}
	return g.rollIdx == 11
}

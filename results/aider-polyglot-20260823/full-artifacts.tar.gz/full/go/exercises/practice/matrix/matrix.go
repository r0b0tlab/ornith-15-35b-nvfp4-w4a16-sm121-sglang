package matrix

import (
	"errors"
	"strconv"
	"strings"
)

// Define the Matrix type here.
type Matrix struct {
	data [][]int
}

func New(s string) (*Matrix, error) {
	lines := strings.Split(s, "\n")
	rows := make([][]int, len(lines))
	numCols := -1

	for i, line := range lines {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		fields := strings.Fields(line)
		if numCols == -1 {
			numCols = len(fields)
		} else if len(fields) != numCols {
			return nil, errors.New("rows have different lengths")
		}

		row := make([]int, len(fields))
		for j, field := range fields {
			num, err := strconv.Atoi(field)
			if err != nil {
				return nil, err
			}
			row[j] = num
		}
		rows[i] = row
	}

	return &Matrix{data: rows}, nil
}

// Cols and Rows must return the results without affecting the matrix.
func (m *Matrix) Cols() [][]int {
	if m == nil || len(m.data) == 0 {
		return [][]int{}
	}
	numRows := len(m.data)
	numCols := len(m.data[0])
	cols := make([][]int, numCols)
	for j := 0; j < numCols; j++ {
		cols[j] = make([]int, numRows)
		for i := 0; i < numRows; i++ {
			cols[j][i] = m.data[i][j]
		}
	}
	return cols
}

func (m *Matrix) Rows() [][]int {
	if m == nil || len(m.data) == 0 {
		return [][]int{}
	}
	numRows := len(m.data)
	numCols := len(m.data[0])
	rows := make([][]int, numRows)
	for i := 0; i < numRows; i++ {
		rows[i] = make([]int, numCols)
		for j := 0; j < numCols; j++ {
			rows[i][j] = m.data[i][j]
		}
	}
	return rows
}

func (m *Matrix) Set(row, col, val int) bool {
	if m == nil || row < 0 || row >= len(m.data) || col < 0 || col >= len(m.data[0]) {
		return false
	}
	if len(m.data[row]) == 0 {
		return false
	}
	m.data[row][col] = val
	return true
}

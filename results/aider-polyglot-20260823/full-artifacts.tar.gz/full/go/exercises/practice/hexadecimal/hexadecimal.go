package hexadecimal

import (
	"errors"
	"strconv"
)

// ParseHex converts a hexadecimal string to its decimal equivalent.
// It returns 0 for invalid input.
func ParseHex(in string) int64 {
	if len(in) == 0 {
		return 0
	}

	var result int64 = 0
	for _, ch := range in {
		var digit int64
		switch {
		case ch >= '0' && ch <= '9':
			digit = int64(ch - '0')
		case ch >= 'a' && ch <= 'f':
			digit = int64(ch-'a') + 10
		case ch >= 'A' && ch <= 'F':
			digit = int64(ch-'A') + 10
		default:
			return 0
		}
		result = result*16 + digit
	}
	return result
}

// HandleErrors validates a hexadecimal string and returns an error if invalid.
func HandleErrors(in string) error {
	if len(in) == 0 {
		return errors.New("empty hex string")
	}
	for _, ch := range in {
		if (ch >= '0' && ch <= '9') ||
			(ch >= 'a' && ch <= 'f') ||
			(ch >= 'A' && ch <= 'F') {
			continue
		}
		return errors.New("invalid hexadecimal character")
	}
	return nil
}

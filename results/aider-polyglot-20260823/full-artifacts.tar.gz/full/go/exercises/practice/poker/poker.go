package poker

import (
	"errors"
	"fmt"
	"sort"
	"strings"
	"unicode/utf8"
)

// Card represents a single poker card
type Card struct {
	Rank int
	Suit string
}

// Hand represents a poker hand (5 cards)
type Hand struct {
	Cards []Card
	Raw   string
}

// Rank values
var rankValues = map[string]int{
	"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
	"J": 11, "Q": 12, "K": 13, "A": 14,
}

// BestHand returns the best hand(s) from the list
func BestHand(hands []string) ([]string, error) {
	if len(hands) == 0 {
		return nil, errors.New("no hands provided")
	}

	scores := make([]handScore, len(hands))
	for i, hand := range hands {
		cards, err := parseHand(hand)
		if err != nil {
			return nil, err
		}
		scores[i] = scoreHand(cards, hand)
	}

	// Find the best score
	best := scores[0]
	for _, s := range scores {
		if compareScores(s, best) > 0 {
			best = s
		}
	}

	// Collect all hands that match the best score
	var result []string
	for i, s := range scores {
		if compareScores(s, best) == 0 {
			result = append(result, hands[i])
		}
	}
	return result, nil
}

// handScore represents a scored hand for comparison
type handScore struct {
	score    int
	tiebreak []int
	rawHand  string
}

// parseHand parses a hand string into a slice of Cards
func parseHand(hand string) ([]Card, error) {
	cards := strings.Split(hand, " ")
	if len(cards) != 5 {
		return nil, errors.New("invalid hand: must have 5 cards")
	}
	result := make([]Card, 5)
	for i, c := range cards {
		if len(c) < 2 {
			return nil, fmt.Errorf("invalid card: %s", c)
		}
		// Get the last rune (suit) properly handling multi-byte UTF-8
		runeLen := utf8.RuneInStr(c)
		if runeLen < 2 {
			return nil, fmt.Errorf("invalid card: %s", c)
		}
		lastRune := c[len(c)-lastRune:]
		rankStr := c[:len(c)-lastRune]
		rank, ok := rankValues[rankStr]
		if !ok {
			return nil, fmt.Errorf("invalid rank: %s", rankStr)
		}
		result[i] = Card{Rank: rank, Suit: lastRune}
	}
	return result, nil
}

// scoreHand computes the score for a hand
func scoreHand(cards []Card, raw string) handScore {
	// Build rank counts
	rankCounts := map[int]int{}
	for _, c := range cards {
		rankCounts[c.Rank]++
	}

	// Check for flush
	isFlush := true
	for i := 1; i < len(cards); i++ {
		if cards[i].Suit != cards[0].Suit {
			isFlush = false
			break
		}
	}

	// Sorted ranks
	sortedRanks := make([]int, len(cards))
	for i, c := range cards {
		sortedRanks[i] = c.Rank
	}
	sort.Ints(sortedRanks)

	// Check for straight (normal and wheel)
	isStraight := false
	unique := uniqueInts(sortedRanks)
	if len(unique) == 5 {
		if sortedRanks[4]-sortedRanks[0] == 4 {
			isStraight = true
		}
		// Ace-low straight (wheel): A, 2, 3, 4, 5
		if sortedRanks[0] == 14 && sortedRanks[1] == 2 && sortedRanks[2] == 3 && sortedRanks[3] == 4 && sortedRanks[4] == 5 {
			isStraight = true
		}
	}

	// Group ranks by count for tiebreaking
	type rankCount struct {
		rank  int
		count int
	}
	groups := make([]rankCount, 0)
	for rank, count := range rankCounts {
		groups = append(groups, rankCount{rank, count})
	}
	// Sort by count desc, then rank desc
	sort.Slice(groups, func(i, j int) bool {
		if groups[i].count != groups[j].count {
			return groups[i].count > groups[j].count
		}
		return groups[i].rank > groups[j].rank
	})

	// Build tiebreakers based on hand type
	var tiebreak []int
	var category int

	switch {
	case isStraight && isFlush:
		category = 8
		if sortedRanks[0] == 14 && sortedRanks[1] == 2 {
			tiebreak = []int{5}
		} else {
			tiebreak = []int{sortedRanks[4]}
		}
	case len(groups) > 0 && groups[0].count == 4:
		category = 6
		tiebreak = []int{groups[0].rank, groups[1].rank}
	case len(groups) > 0 && groups[0].count == 3 && len(groups) > 1 && groups[1].count == 2:
		category = 5
		tiebreak = []int{groups[0].rank, groups[1].rank}
	case isFlush:
		category = 7
		tiebreak = []int{sortedRanks[4], sortedRanks[3], sortedRanks[2], sortedRanks[1], sortedRanks[0]}
	case isStraight:
		category = 4
		if sortedRanks[0] == 14 && sortedRanks[1] == 2 {
			tiebreak = []int{5}
		} else {
			tiebreak = []int{sortedRanks[4]}
		}
	case len(groups) > 0 && groups[0].count == 3:
		category = 3
		tiebreak = []int{groups[0].rank, groups[1].rank, groups[2].rank}
	case len(groups) > 0 && groups[0].count == 2 && len(groups) > 1 && groups[1].count == 2:
		category = 2
		tiebreak = []int{groups[0].rank, groups[1].rank, groups[2].rank}
	case len(groups) > 0 && groups[0].count == 2:
		category = 1
		tiebreak = []int{groups[0].rank, groups[1].rank, groups[2].rank}
	default:
		category = 0
		tiebreak = []int{sortedRanks[4], sortedRanks[3], sortedRanks[2], sortedRanks[1], sortedRanks[0]}
	}

	return handScore{
		score:    category,
		tiebreak: tiebreak,
		rawHand:  raw,
	}
}

// compareScores compares two hand scores
// Returns 1 if a > b, -1 if a < b, 0 if equal
func compareScores(a, b handScore) int {
	if a.score != b.score {
		if a.score > b.score {
			return 1
		}
		return -1
	}
	for i := 0; i < len(a.tiebreak) && i < len(b.tiebreak); i++ {
		if a.tiebreak[i] != b.tiebreak[i] {
			if a.tiebreak[i] > b.tiebreak[i] {
				return 1
			}
			return -1
		}
	}
	return 0
}

// uniqueInts returns the unique sorted ints
func uniqueInts(sorted []int) []int {
	if len(sorted) == 0 {
		return sorted
	}
	result := []int{sorted[0]}
	for i := 1; i < len(sorted); i++ {
		if sorted[i] != sorted[i-1] {
			result = append(result, sorted[i])
		}
	}
	return result
}

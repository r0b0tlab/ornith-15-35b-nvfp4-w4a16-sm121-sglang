package bottlesong

import (
	"fmt"
)

// Recite generates the "Ten Green Bottles" song starting from startBottles
// and takes down takeDown bottles. It returns the lyrics as a slice of strings.
func Recite(startBottles, takeDown int) []string {
	// Map of numbers to words for the current count of bottles
	words := map[int]string{
		0:  "no",
		1:  "one",
		2:  "two",
		3:  "three",
		4:  "four",
		5:  "five",
		6:  "six",
		7:  "seven",
		8:  "eight",
		9:  "nine",
		10: "ten",
	}

	var result []string

	for i := 0; i < takeDown; i++ {
		current := startBottles - i

		// First line of the verse
		result = append(result, fmt.Sprintf("%s green bottles hanging on the wall,", words[current]))
		// Second line (same as first)
		result = append(result, fmt.Sprintf("%s green bottles hanging on the wall,", words[current]))
		// Third line
		result = append(result, "And if one green bottle should accidentally fall,")

		// Fourth line - the number of bottles after taking one down
		next := current - 1
		if next == 0 {
			result = append(result, "There'll be no green bottles hanging on the wall.")
		} else {
			result = append(result, fmt.Sprintf("There'll be %s green bottle%s hanging on the wall.", words[next], pluralize(next)))
		}

		// Add a blank line between verses (but not after the last verse)
		if i < takeDown-1 {
			result = append(result, "")
		}
	}

	return result
}

// pluralize returns "s" for plural, empty string for singular
func pluralize(n int) string {
	if n == 1 {
		return ""
	}
	return "s"
}

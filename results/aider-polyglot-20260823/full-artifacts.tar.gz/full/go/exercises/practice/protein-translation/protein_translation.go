package protein

import "errors"

var (
	ErrStop        = errors.New("stop codon")
	ErrInvalidCodon = errors.New("invalid codon")
	errIncompleteRNA = errors.New("incomplete RNA sequence")
)

var codonProteins = map[string]string{
	"AUG": "Methionine",
	"UUU": "Phenylalanine",
	"UUC": "Phenylalanine",
	"UUA": "Leucine",
	"UUG": "Leucine",
	"UCU": "Serine",
	"UCC": "Serine",
	"UCA": "Serine",
	"UCG": "Serine",
	"UAU": "Tyrosine",
	"UAC": "Tyrosine",
	"UGU": "Cysteine",
	"UGC": "Cysteine",
	"UGG": "Tryptophan",
	"UAA": "STOP",
	"UAG": "STOP",
	"UGA": "STOP",
}

func FromCodon(codon string) (string, error) {
	protein, ok := codonProteins[codon]
	if !ok {
		return "", ErrInvalidCodon
	}
	return protein, nil
}

func FromRNA(rna string) ([]string, error) {
	var proteins []string

	for i := 0; i+3 <= len(rna); i += 3 {
		codon := rna[i : i+3]
		protein, err := FromCodon(codon)
		if err != nil {
			return nil, err
		}
		if protein == "STOP" {
			break
		}
		proteins = append(proteins, protein)
	}

	if len(rna)%3 != 0 {
		return nil, errIncompleteRNA
	}

	return proteins, nil
}

package ledger

import (
	"errors"
	"sort"
	"strconv"
	"strings"
)

type Entry struct {
	Date        string // "Y-m-d"
	Description string
	Change      int // in cents
}

func FormatLedger(currency string, locale string, entries []Entry) (string, error) {
	// Validate currency
	switch currency {
	case "EUR", "USD":
		// valid
	default:
		return "", errors.New("invalid currency")
	}

	// Determine locale headers and formatting
	var header string
	enLocale := locale == "en-US"

	if locale == "en-US" {
		header = "Date" + strings.Repeat(" ", 10-len("Date")) +
			"| Description" + strings.Repeat(" ", 25-len("Description")) +
			"| Change" + "\n"
	} else if locale == "nl-NL" {
		header = "Datum" + strings.Repeat(" ", 10-len("Datum")) +
			"| Omschrijving" + strings.Repeat(" ", 25-len("Omschrijving")) +
			"| Verandering" + "\n"
	} else {
		return "", errors.New("invalid locale")
	}

	// Sort entries by date, then description, then change
	entriesCopy := make([]Entry, len(entries))
	copy(entriesCopy, entries)
	sort.SliceStable(entriesCopy, func(i, j int) bool {
		if entriesCopy[i].Date != entriesCopy[j].Date {
			return entriesCopy[i].Date < entriesCopy[j].Date
		}
		if entriesCopy[i].Description != entriesCopy[j].Description {
			return entriesCopy[i].Description < entriesCopy[j].Description
		}
		return entriesCopy[i].Change < entriesCopy[j].Change
	})

	// Build output
	var sb strings.Builder
	sb.WriteString(header)

	for _, entry := range entriesCopy {
		row, err := formatRow(entry, currency, locale, enLocale)
		if err != nil {
			return "", err
		}
		sb.WriteString(row)
	}

	return sb.String(), nil
}

func formatRow(entry Entry, currency string, locale string, enLocale bool) (string, error) {
	// Validate and format date
	if len(entry.Date) != 10 || entry.Date[4] != '-' || entry.Date[7] != '-' {
		return "", errors.New("invalid date format")
	}

	var date string
	if enLocale {
		date = entry.Date[5:7] + "/" + entry.Date[8:10] + "/" + entry.Date[0:4]
	} else {
		date = entry.Date[8:10] + "-" + entry.Date[5:7] + "-" + entry.Date[0:4]
	}

	// Format description (max 25 chars)
	description := entry.Description
	if len(description) > 25 {
		description = description[:22] + "..."
	} else {
		description = description + strings.Repeat(" ", 25-len(description))
	}

	// Format change
	change, err := formatChange(entry.Change, currency, locale, enLocale)
	if err != nil {
		return "", err
	}

	return date + strings.Repeat(" ", 10-len(date)) +
		"| " + description + " | " +
		strings.Repeat(" ", 13-len(change)) + change + "\n", nil
}

func formatChange(change int, currency string, locale string, enLocale bool) (string, error) {
	negative := change < 0
	cents := change
	if cents < 0 {
		cents = -cents
	}

	centsStr := strconv.Itoa(cents)
	switch len(centsStr) {
	case 1:
		centsStr = "00" + centsStr
	case 2:
		centsStr = "0" + centsStr
	}

	// Add thousands separators
	rest := centsStr
	if len(rest) > 3 {
		var parts []string
		for len(rest) > 3 {
			parts = append(parts, rest[len(rest)-3:])
			rest = rest[:len(rest)-3]
		}
		if len(rest) > 0 {
			parts = append(parts, rest)
		}
		for i := len(parts) - 1; i >= 0; i-- {
			centsStr = parts[i] + centsStr
		}
		centsStr = parts[0] + centsStr[len(parts[0]):]
	}

	var changeStr string
	if enLocale {
		currencySymbol := ""
		if currency == "EUR" {
			currencySymbol = "€"
		} else if currency == "USD" {
			currencySymbol = "$"
		} else {
			return "", errors.New("invalid currency")
		}
		if negative {
			changeStr += "("
		}
		changeStr += currencySymbol
		changeStr += strings.Replace(centsStr, "", ",", -1)
		changeStr += "."
		changeStr += centsStr[len(centsStr)-2:]
		if negative {
			changeStr += ")"
		} else {
			changeStr += " "
		}
	} else {
		currencySymbol := ""
		if currency == "EUR" {
			currencySymbol = "€"
		} else if currency == "USD" {
			currencySymbol = "$"
		} else {
			return "", errors.New("invalid currency")
		}
		changeStr += currencySymbol
		changeStr += " "
		changeStr += strings.Replace(centsStr, "", ",", -1)
		changeStr += "."
		changeStr += centsStr[len(centsStr)-2:]
		changeStr += centsStr[len(centsStr)-2:]
		if negative {
			changeStr += "-"
		} else {
			changeStr += " "
		}
	}

	return changeStr, nil
}

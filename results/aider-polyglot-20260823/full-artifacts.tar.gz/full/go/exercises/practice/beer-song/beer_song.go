package beer

import (
	"fmt"
	"strings"
)

// Verse generates a single verse of the beer song.
func Verse(n int) (string, error) {
	switch n {
	case 0:
		return "No more bottles of beer on the wall, no more bottles of beer.\nGo to the store and buy some more, 99 bottles of beer on the wall.", nil
	case 1:
		return "1 bottle of beer on the wall, 1 bottle of beer.\nTake it down and pass it around, no more bottles of beer on the wall.", nil
	case 2:
		return "2 bottles of beer on the wall, 2 bottles of beer.\nTake one down and pass it around, 1 bottle of beer on the wall.", nil
	default:
		return fmt.Sprintf("%d bottles of beer on the wall, %d bottles of beer.\nTake one down and pass it around, %d bottles of beer on the wall.", n, n, n-1), nil
	}
}

// Verses generates verses from start to stop, inclusive.
func Verses(start, stop int) (string, error) {
	var verses []string
	for i := start; i <= stop; i++ {
		verse, err := Verse(i)
		if err != nil {
			return "", err
		}
		verses = append(verses, verse)
	}
	return strings.Join(verses, "\n\n"), nil
}

// Song generates the entire beer song.
func Song() string {
	verses, err := Verses(99, 0)
	if err != nil {
		return ""
	}
	return verses
}


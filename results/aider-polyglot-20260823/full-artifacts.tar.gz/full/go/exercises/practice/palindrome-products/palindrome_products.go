package palindrome

import (
	"errors"
	"strconv"
)

// Define Product type here.
type Product struct {
	Product         int
	Factorizations  [][2]int
}

func Products(fmin, fmax int) (Product, Product, error) {
	if fmin > fmax {
		return Product{}, Product{}, errors.New("fmin must be less than or equal to fmax")
	}

	smallest := Product{Product: -1}
	largest := Product{Product: -1}

	for i := fmin; i <= fmax; i++ {
		for j := i; j <= fmax; j++ {
			product := i * j
			if isPalindrome(product) {
				if smallest.Product == -1 || product < smallest.Product {
					smallest = Product{Product: product, Factorizations: [][2]int{{i, j}}}
				} else if product == smallest.Product {
					smallest.Factorizations = append(smallest.Factorizations, [][2]int{{i, j}}[0])
				}

				if largest.Product == -1 || product > largest.Product {
					largest = Product{Product: product, Factorizations: [][2]int{{i, j}}}
				} else if product == largest.Product {
					largest.Factorizations = append(largest.Factorizations, [][2]int{{i, j}}[0])
				}
			}
		}
	}

	if smallest.Product == -1 {
		return Product{}, Product{}, errors.New("no palindrome products found")
	}

	return smallest, largest, nil
}

func isPalindrome(n int) bool {
	if n < 0 {
		return false
	}
	s := strconv.Itoa(n)
	len := len(s)
	for i := 0; i < len/2; i++ {
		if s[i] != s[len-1-i] {
			return false
		}
	}
	return true
}

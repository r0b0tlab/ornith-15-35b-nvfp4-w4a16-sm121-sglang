package cryptosquare

import (
	"math"
	"strings"
	"unicode"
)

func Encode(pt string) string {
	// Normalize: remove spaces and punctuation, down-case
	var normalized strings.Builder
	for _, r := range pt {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			normalized.WriteRune(unicode.ToLower(r))
		}
	}
	text := normalized.String()

	// Handle empty message
	if len(text) == 0 {
		return ""
	}

	// Determine rectangle size: c columns, r rows
	// c >= r, c - r <= 1, r * c >= length
	c := int(math.Ceil(math.Sqrt(float64(len(text)))))
	r := len(text) / c
	if r*c < len(text) {
		r++
	}

	// Pad text to fill the rectangle
	for len(text) < r*c {
		text += " "
	}

	// Read down columns, create chunks
	var chunks []string
	for col := 0; col < c; col++ {
		chunk := ""
		for row := 0; row < r; row++ {
			chunk += string(text[row*c+col])
		}
		chunks = append(chunks, chunk)
	}

	return strings.Join(chunks, " ")
}

package alphametics

import (
	"fmt"
	"strings"
)

// Solve attempts to solve an alphametics puzzle.
func Solve(puzzle string) (map[string]int, error) {
	// Split the puzzle into the left and right sides of the == operator.
	parts := strings.Split(puzzle, "==")
	if len(parts) != 2 {
		return nil, fmt.Errorf("invalid puzzle format: expected one == operator")
	}

	leftParts := strings.Split(parts[0], "+")
	rightPart := parts[1]

	// Collect all words.
	var words []string
	for _, p := range leftParts {
		p = strings.TrimSpace(p)
		if p != "" {
			words = append(words, p)
		}
	}
	rightPart = strings.TrimSpace(rightPart)
	if rightPart != "" {
		words = append(words, rightPart)
	}

	// Extract unique letters.
	letters := map[byte]bool{}
	for _, word := range words {
		for i := 0; i < len(word); i++ {
			if word[i] >= 'A' && word[i] <= 'Z' {
				letters[word[i]] = true
			}
		}
	}

	// Leading letters cannot be zero.
	leadingLetters := map[byte]bool{}
	for _, word := range words {
		if len(word) > 1 {
			leadingLetters[word[0]] = true
		}
	}

	// Build a slice of unique letters to iterate over.
	letterList := make([]byte, 0, len(letters))
	for l := range letters {
		letterList = append(letterList, l)
	}

	// If there are more than 10 unique letters, no solution is possible.
	if len(letterList) > 10 {
		return nil, fmt.Errorf("too many unique letters: %d", len(letterList))
	}

	// Try all permutations of digits for the letters.
	return solve(words, letterList, leadingLetters, 0, map[byte]byte{}, make([]bool, 10))
}

// solve recursively assigns digits to letters.
func solve(words []string, letterList []byte, leadingLetters map[byte]bool, idx int, assignment map[byte]byte, used []bool) (map[string]int, error) {
	if idx == len(letterList) {
		return checkSolution(words, letterList, assignment)
	}

	letter := letterList[idx]
	for d := 0; d <= 9; d++ {
		if used[d] {
			continue
		}
		if d == 0 && leadingLetters[letter] {
			continue
		}

		used[d] = true
		assignment[letter] = byte(d)

		result, err := solve(words, letterList, leadingLetters, idx+1, assignment, used)
		if result != nil {
			return result, nil
		}

		// Undo the assignment.
		delete(assignment, letter)
		used[d] = false
	}

	return nil, nil
}

// checkSolution verifies if the current assignment forms a valid solution.
func checkSolution(words []string, letterList []byte, assignment map[byte]byte) (map[string]int, error) {
	// Compute the numeric value of each word.
	nums := make([]int, len(words))
	for i, word := range words {
		num := 0
		for i := 0; i < len(word); i++ {
			num = num*10 + int(assignment[word[i]])
		}
		nums[i] = num
	}

	// Sum the left side (all words except the last).
	sum := 0
	for i := 0; i < len(nums)-1; i++ {
		sum += nums[i]
	}

	// Check if the sum equals the right side.
	if sum != nums[len(nums)-1] {
		return nil, nil
	}

	// Build the result map.
	result := map[string]int{}
	for _, word := range words {
		for i := 0; i < len(word); i++ {
			result[string(word[i])] = int(assignment[word[i]])
		}
	}

	return result, nil
}

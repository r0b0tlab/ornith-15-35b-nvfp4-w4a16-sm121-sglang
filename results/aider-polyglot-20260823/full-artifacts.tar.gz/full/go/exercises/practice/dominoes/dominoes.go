package dominoes

// Define the Domino type here.

type Domino [2]int

func MakeChain(input []Domino) (chain []Domino, ok bool) {
	if len(input) == 0 {
		return []Domino{}, true
	}

	if used := make([]bool, len(input)); !chainHelper(input, used, nil, -1) {
		return nil, false
	} else {
		return chain, true
	}
}

func chainHelper(input []Domino, used []bool, chain []Domino, last int) bool {
	if len(chain) == len(input) {
		if len(chain) > 0 && chain[0][0] != chain[len(chain)-1][1] {
			return false
		}
		return true
	}

	for i := 0; i < len(input); i++ {
		if used[i] {
			continue
		}

		used[i] = true

		if len(chain) == 0 || input[i][0] == last {
			newChain := append(chain, input[i])
			if chainHelper(input, used, newChain, input[i][1]) {
				return true
			}
		}

		if input[i][1] != input[i][0] {
			if len(chain) == 0 || input[i][1] == last {
				newChain := append(chain, Domino{input[i][1], input[i][0]})
				if chainHelper(input, used, newChain, input[i][0]) {
					return true
				}
			}
		}

		used[i] = false
	}

	return false
}

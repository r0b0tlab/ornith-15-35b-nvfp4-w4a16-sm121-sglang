package kindergarten

import (
	"fmt"
	"strings"
)

// Garden represents a kindergarten garden with plants assigned to children.
type Garden struct {
	rows     []string
	children []string
}

// Default list of children in alphabetical order.
var defaultChildren = []string{
	"Alice", "Bob", "Charlie", "David",
	"Eve", "Fred", "Ginny", "Harriet",
	"Ileana", "Joseph", "Kincaid", "Larry",
}

// plantMap maps a single diagram character to its plant name.
var plantMap = map[byte]string{
	'G': "grass",
	'C': "clover",
	'R': "radishes",
	'V': "violets",
}

// NewGarden parses the diagram and assigns plants to children.
func NewGarden(diagram string, children []string) (*Garden, error) {
	// Validate input: must contain exactly two rows.
	rows := strings.Split(strings.Trim(diagram, "\n"), "\n")
	if len(rows) != 2 {
		return nil, fmt.Errorf("expected exactly 2 rows, got %d", len(rows))
	}

	// Each row must have even length (pairs of cups per child).
	rowLen := len(rows[0])
	if rowLen%2 != 0 {
		return nil, fmt.Errorf("row length %d is not even", rowLen)
	}
	if len(rows[1]) != rowLen {
		return nil, fmt.Errorf("rows have different lengths")
	}

	// Validate that all children have unique names.
	seen := map[string]bool{}
	for _, child := range children {
		if seen[child] {
			return nil, fmt.Errorf("duplicate child name: %s", child)
		}
		seen[child] = true
	}

	// If children are not provided, use the default list.
	if len(children) == 0 {
		children = append(children, defaultChildren...)
	}

	// Ensure children are sorted alphabetically as the teacher assigns cups.
	for i := 1; i < len(children); i++ {
		for j := i; j > 0 && children[j-1] > children[j]; j-- {
			children[j-1], children[j] = children[j], children[j-1]
		}
	}

	return &Garden{rows: rows, children: children}, nil
}

// Plants returns the plants assigned to the given child.
func (g *Garden) Plants(child string) ([]string, bool) {
	// Find the child's position in the sorted list.
	idx := -1
	for i, c := range g.children {
		if c == child {
			idx = i
			break
		}
	}
	if idx == -1 {
		return nil, false
	}

	// Each child gets 2 cups per row, starting at position idx*2.
	start := idx * 2
	end := start + 2

	result := make([]string, 0, 4)
	for _, row := range g.rows {
		for i := start; i < end && i < len(row); i++ {
			if plant, ok := plantMap[row[i]]; ok {
				result = append(result, plant)
			}
		}
	}

	return result, true
}

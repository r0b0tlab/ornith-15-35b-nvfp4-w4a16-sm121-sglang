package erratum

type Resource interface {
	Frob()
	Defrob(tag string)
	Close()
}

type resource struct {
	str string
}

func (r *resource) Frob() {
	panic(FrobError{str: "FrobError", defrobTag: r.str})
}

func (r *resource) Defrob(tag string) {
	r.str = ""
}

func (r *resource) Close() {
	r.str = ""
}

type ResourceOpener func() (Resource, error)

type FrobError struct {
	str     string
	defrobTag string
}

type TransientError struct {
	str string
}

func (e *FrobError) Error() string {
	return e.str
}

func (e *TransientError) Error() string {
	return e.str
}

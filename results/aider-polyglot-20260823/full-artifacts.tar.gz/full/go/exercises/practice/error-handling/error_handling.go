package erratum

func Use(opener ResourceOpener, input string) error {
	var res Resource
	var err error

	defer func() {
		if res != nil {
			res.Close()
		}
	}()

	for {
		res, err = opener()
		if err == nil {
			break
		}
		if _, ok := err.(*TransientError); ok {
			continue
		}
		return err
	}

	defer func() {
		if r := recover(); r != nil {
			if frobErr, ok := r.(*FrobError); ok {
				res.Defrob(frobErr.defrobTag)
			}
		}
	}()

	res.Frob(input)

	return err
}

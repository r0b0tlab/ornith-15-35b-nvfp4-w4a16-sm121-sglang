package robot

import "io"

// Step 1 implementations

func Right() {
	step1State.dir = (step1State.dir + 1) % 4
}

func Left() {
	step1State.dir = (step1State.dir + 3) % 4
}

func Advance() {
	switch step1State.dir {
	case N:
		step1State.y++
	case E:
		step1State.x++
	case S:
		step1State.y--
	case W:
		step1State.x--
	}
}

// Step 2

// Action represents an action the robot can take.
type Action int

const (
	// TurnRight turns the robot right.
	TurnRight Action = iota + 1
	// TurnLeft turns the robot left.
	TurnLeft
	// Advance moves the robot forward.
	Advance2
)

func StartRobot(command chan Command, action chan Action) {
	go func() {
		for cmd := range command {
			switch cmd {
			case CommandRight:
				action <- TurnRight
			case CommandLeft:
				action <- TurnLeft
			case CommandAdvance:
				action <- Advance2
			}
		}
	}()
}

// Step 3

// Action3 represents an action the robot can take in step 3.
type Action3 int

const (
	// TurnRight3 turns the robot right.
	TurnRight3 Action3 = iota + 1
	// TurnLeft3 turns the robot left.
	TurnLeft3
	// Advance3 moves the robot forward.
	Advance3
)

func StartRobot3(name, script string, action chan Action3, log chan string) {
	go func() {
		for _, c := range script {
			switch c {
			case 'R':
				action <- TurnRight3
			case 'L':
				action <- TurnLeft3
			case 'A':
				action <- Advance3
			}
		}
	}()
}

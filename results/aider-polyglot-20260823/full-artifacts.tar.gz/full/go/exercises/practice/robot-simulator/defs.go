package robot

import "io"

// Define R1, R2, R3 Robot types here.

// Step 1

// Define N, E, S, W here.
type Dir int

func Right()
func Left()
func Advance()

// Step 2

// Define Action, Step2Robot types here.

// Step 3

// Define Action3, Step3Robot types here.

func StartRobot3(name, script string, action chan Action3, log chan string)
func Room3(extent Rect, robots []Step3Robot, action chan Action3, rep chan []Step3Robot, log chan string)
